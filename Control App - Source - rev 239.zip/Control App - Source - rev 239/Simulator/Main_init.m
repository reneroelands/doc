% This is the main init script for the XSS simulator
% Editor:       HKup/Wildschutj

%--------------------------------------------------------------------
% General stuff
%--------------------------------------------------------------------
clear all;
clc;
close all;

%--------------------------------------------------------------------
% Show menu for model configuration modes
%--------------------------------------------------------------------
disp('Simulator Model Configuration...');

MnChoice='PIL';

run ('..\Controller\Model_init.m');
% run ('..\Controller\Model_open.m');

Main.SimulatorPath = pwd;               % Store model path for logo
Main.SimulatorName = 'XSS_Simulator';   % Define Simulink model name

open([Main.SimulatorName,'.mdl']);      % Load Simulator model

%--------------------------------------------------------------------
% Temporary definitions - must be removed
%--------------------------------------------------------------------
% warning('Temporary definitions in Main_init.m must be removed')
% 
% % Sbc.Tun.StepperSclng = 1;
% % 
% DummyFilt.a1 = 1;
% DummyFilt.a2 = 1;
% DummyFilt.b0 = 1;
% DummyFilt.b1 = 1;
% DummyFilt.b2 = 1;
% % 
% Sbc.Tun.Ctrl.Filt1 = DummyFilt;
% Sbc.Tun.Ctrl.Filt2 = DummyFilt;
% Sbc.Tun.Ctrl.IL = 1;
% Sbc.Tun.Ctrl.PL = 1;
% Sbc.Tun.Ctrl.DL = 1;
% Sbc.Tun.Ctrl.Ki = 1;
% Sbc.Tun.Ctrl.Kp = 1;
% Sbc.Tun.Ctrl.Kd1 = 1;
% Sbc.Tun.Ctrl.Kd2 = 1;
% Sbc.Tun.Ctrl.Kd3 = 1;
