﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

using System.Globalization;

using TwinCAT.Ads;
using TCatSysManagerLib;

namespace ADS_XSS_Test_Interface
{
    public partial class Form1 : Form
    {
        private TcAdsSymbolInfoLoader symbolLoader;
        private TcAdsClient m_client;
        private ITcAdsSymbol currentSymbol = null;

        List<double> listTime = new List<double>();
        List<double> listCommandID = new List<double>();
        List<double> listAxisID = new List<double>();
        List<double> listParam1 = new List<double>();
        List<double> listParam2 = new List<double>();
        List<double> listParam3 = new List<double>();
        List<double> listParam4 = new List<double>();

        double time = 0;
        int lineCnt = 0;

        private bool ReadAccepted()
        {
            int arrHandle = m_client.CreateVariableHandle("Object1 (MIGRATION_BECKHOFF).TcModuleOutput.Models_CommandInterfaceModule_Status_Merger_AcceptedTimer_CmdAccepted");
            bool value = false;
            value = (bool) m_client.ReadAny(arrHandle, value.GetType());

            if (value) return true;
            else return false;
        }

        private void PulseCmdValid()
        {
            int validHandle = m_client.CreateVariableHandle("Object1 (MIGRATION_BECKHOFF).TcModuleInput.HostInterface_ServerHost_Com_ComHcCmdCmdValid");
            m_client.WriteAny(validHandle, 1.0);

            Thread.Sleep(10);

            m_client.WriteAny(validHandle, 0.0);
        }

        private void SendCommand(double[] CMD)
        {
            while (ReadAccepted()) Thread.Sleep(1); // Wait for accepted to go low

            int arrHandle = m_client.CreateVariableHandle("Object1 (MIGRATION_BECKHOFF).TcModuleInput.HostInterface_ServerHost_Com_ComHcCmdCmdVector");
            m_client.WriteAny(arrHandle, CMD);

            PulseCmdValid();
        }

        private TreeNode CreateNewNode(TcAdsSymbolInfo symbol)
        {
            TreeNode node = new TreeNode(symbol.Name);
            node.Tag = symbol;
            TcAdsSymbolInfo subSymbol = symbol.FirstSubSymbol;
            while (subSymbol != null)
            {
                node.Nodes.Add(CreateNewNode(subSymbol));
                subSymbol = subSymbol.NextSymbol;
            }
            return node;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Btn_Connect_Click(object sender, EventArgs e)
        {
            m_client = new TcAdsClient();
            m_client.Connect(350);
            symbolLoader = m_client.CreateSymbolInfoLoader();

        }

        private void Btn_Load_Click(object sender, EventArgs e)
        {
            treeViewSymbols.Nodes.Clear();
            try
            {
                TcAdsSymbolInfo symbol = symbolLoader.GetFirstSymbol(true);
                while (symbol != null)
                {
                    treeViewSymbols.Nodes.Add(CreateNewNode(symbol));
                    symbol = symbol.NextSymbol;
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void Btn_SendCMD_Click(object sender, EventArgs e)
        {
            double number;
            double[] vector = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };

            vector[0] = (double)UD_CMDID.Value;

            vector[1] = (double)UD_AxisID.Value;

            if (Double.TryParse(TB_Param1.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out number))
            {
                vector[2] = number;
                Console.WriteLine("'{0}' --> {1}", TB_Param1.Text, number);
            }
            else
                Console.WriteLine("Unable to parse '{0}'.", TB_Param1.Text);

            if (Double.TryParse(TB_Param2.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out number))
            {
                vector[3] = number;
                Console.WriteLine("'{0}' --> {1}", TB_Param2.Text, number);
            }
            else
                Console.WriteLine("Unable to parse '{0}'.", TB_Param2.Text);

            if (Double.TryParse(TB_Param3.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out number))
            {
                vector[4] = number;
                Console.WriteLine("'{0}' --> {1}", TB_Param3.Text, number);
            }
            else
                Console.WriteLine("Unable to parse '{0}'.", TB_Param3.Text);

            if (Double.TryParse(TB_Param4.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out number))
            {
                vector[5] = number;
                Console.WriteLine("'{0}' --> {1}", TB_Param3.Text, number);
            }
            else
                Console.WriteLine("Unable to parse '{0}'.", TB_Param4.Text);

            SendCommand(vector);
        }

        private void Btn_Reset_Click(object sender, EventArgs e)
        {
            SendCommand(new double[] { 1.0, 0.0, 0.0, 0.0, 0.0, 0.0 });
        }

        private double ReadDouble(string varName)
        {
            AdsStream dataStream = new AdsStream(8);
            AdsBinaryReader binReader = new AdsBinaryReader(dataStream);

            int iHandle = m_client.CreateVariableHandle(varName);

            m_client.Read(iHandle, dataStream);

            double value = binReader.ReadDouble();

            return value;
        }

        private Int32 ReadInt32(string varName)
        {
            AdsStream dataStream = new AdsStream(8);
            AdsBinaryReader binReader = new AdsBinaryReader(dataStream);

            int iHandle = m_client.CreateVariableHandle(varName);

            m_client.Read(iHandle, dataStream);

            Int32 value = binReader.ReadInt32();

            return value;
        }

        private void BtnLoadCommands_Click(object sender, EventArgs e)
        {
                        
            using (var reader = new StreamReader(@textBoxSelect.Text))
            {

                richTextBoxSequence.Clear();

                richTextBoxSequence.AppendText("Time \t CmdID \t AxID \t p1 \t p2 \t p3 \t p4");
                richTextBoxSequence.AppendText(Environment.NewLine);

                time = 0;
                lineCnt = 1;

                listTime.Clear();
                listCommandID.Clear();
                listAxisID.Clear();
                listParam1.Clear();
                listParam2.Clear();
                listParam3.Clear();
                listParam4.Clear();

                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    var values = line.Split('\t');

                    double sTime = Convert.ToDouble(values[0], new CultureInfo("en-US"));
                    double sCommandID = Convert.ToDouble(values[1], new CultureInfo("en-US"));
                    double sAxisID = Convert.ToDouble(values[2], new CultureInfo("en-US"));
                    double sParam1 = Convert.ToDouble(values[3], new CultureInfo("en-US"));
                    double sParam2 = Convert.ToDouble(values[4], new CultureInfo("en-US"));
                    double sParam3 = Convert.ToDouble(values[5], new CultureInfo("en-US"));
                    double sParam4 = Convert.ToDouble(values[6], new CultureInfo("en-US"));

                    StringBuilder sb = new StringBuilder();

                    sb.Append(String.Format("{0:#0.###}", sTime));
                    sb.Append("\t");
                    sb.Append(String.Format("{0:#0.###}", sCommandID));
                    sb.Append("\t");
                    sb.Append(String.Format("{0:#0.###}", sAxisID));
                    sb.Append("\t");
                    sb.Append(String.Format("{0:#0.###}", sParam1));
                    sb.Append("\t");
                    sb.Append(String.Format("{0:#0.###}", sParam2));
                    sb.Append("\t");
                    sb.Append(String.Format("{0:#0.###}", sParam3));
                    sb.Append("\t");
                    sb.Append(String.Format("{0:#0.###}", sParam4));

                    richTextBoxSequence.AppendText(sb.ToString());
                    richTextBoxSequence.AppendText(Environment.NewLine);                   

                    listTime.Add(sTime);
                    listCommandID.Add(sCommandID);
                    listAxisID.Add(sAxisID);
                    listParam1.Add(sParam1);
                    listParam2.Add(sParam2);
                    listParam3.Add(sParam3);
                    listParam4.Add(sParam4);
                }
            }
        }

        private void BtnStartSequence_Click(object sender, EventArgs e)
        {
            time = 0;
            lineCnt = 1;
            TmrSequence.Enabled = true;
        }

        private void BtnStopSequence_Click(object sender, EventArgs e)
        {
            TmrSequence.Enabled = false;
        }

        private void TmrSequence_Tick(object sender, EventArgs e)
        {
            if (listTime.Count > 0 && listTime[0] <= time)
            {
                // Send command
                double[] vector = { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0 };
                vector[0] = (double) listCommandID[0];
                vector[1] = (double) listAxisID[0];
                vector[2] = (double) listParam1[0];
                vector[3] = (double) listParam2[0];
                vector[4] = (double) listParam3[0];
                vector[5] = (double) listParam4[0];

                SendCommand(vector);

                // Remove command
                listTime.RemoveAt(0);
                listCommandID.RemoveAt(0);
                listAxisID.RemoveAt(0);
                listParam1.RemoveAt(0);
                listParam2.RemoveAt(0);
                listParam3.RemoveAt(0);
                listParam4.RemoveAt(0);

                //highlight line
                int endIndex = richTextBoxSequence.Lines[lineCnt].Length;
                int firstCharOfLine = richTextBoxSequence.GetFirstCharIndexFromLine(lineCnt);
                richTextBoxSequence.Select(firstCharOfLine, endIndex);
                richTextBoxSequence.SelectionBackColor = Color.Aqua;
                richTextBoxSequence.Select(0, 0);
                lineCnt++;

                if (CBPause.Checked)
                {
                    TmrSequence.Enabled = false;
                }
            }


            time += (double) TmrSequence.Interval / 1000.0;
        }

        private void BtnNext_Click(object sender, EventArgs e)
        {
            TmrSequence.Enabled = true;
        }

        private void BtnSelect_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                textBoxSelect.Text = openFileDialog.FileName;
            }
        }

    }
}