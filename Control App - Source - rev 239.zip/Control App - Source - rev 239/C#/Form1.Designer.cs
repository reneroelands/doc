﻿namespace ADS_XSS_Test_Interface
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.treeViewSymbols = new System.Windows.Forms.TreeView();
            this.Btn_Load = new System.Windows.Forms.Button();
            this.Btn_Connect = new System.Windows.Forms.Button();
            this.Btn_SendCMD = new System.Windows.Forms.Button();
            this.TB_Param1 = new System.Windows.Forms.TextBox();
            this.UD_CMDID = new System.Windows.Forms.NumericUpDown();
            this.UD_AxisID = new System.Windows.Forms.NumericUpDown();
            this.TB_Param4 = new System.Windows.Forms.TextBox();
            this.TB_Param3 = new System.Windows.Forms.TextBox();
            this.TB_Param2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Label_AxisID = new System.Windows.Forms.Label();
            this.Label_Param1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Btn_Reset = new System.Windows.Forms.Button();
            this.BtnLoadSequence = new System.Windows.Forms.Button();
            this.TmrSequence = new System.Windows.Forms.Timer(this.components);
            this.BtnStartSequence = new System.Windows.Forms.Button();
            this.BtnStopSequence = new System.Windows.Forms.Button();
            this.richTextBoxSequence = new System.Windows.Forms.RichTextBox();
            this.CBPause = new System.Windows.Forms.CheckBox();
            this.BtnNext = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.BtnSelect = new System.Windows.Forms.Button();
            this.textBoxSelect = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.UD_CMDID)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.UD_AxisID)).BeginInit();
            this.SuspendLayout();
            // 
            // treeViewSymbols
            // 
            this.treeViewSymbols.Location = new System.Drawing.Point(141, 12);
            this.treeViewSymbols.Name = "treeViewSymbols";
            this.treeViewSymbols.Size = new System.Drawing.Size(299, 736);
            this.treeViewSymbols.TabIndex = 0;
            // 
            // Btn_Load
            // 
            this.Btn_Load.Location = new System.Drawing.Point(141, 754);
            this.Btn_Load.Name = "Btn_Load";
            this.Btn_Load.Size = new System.Drawing.Size(75, 23);
            this.Btn_Load.TabIndex = 1;
            this.Btn_Load.Text = "Load";
            this.Btn_Load.UseVisualStyleBackColor = true;
            this.Btn_Load.Click += new System.EventHandler(this.Btn_Load_Click);
            // 
            // Btn_Connect
            // 
            this.Btn_Connect.Location = new System.Drawing.Point(12, 12);
            this.Btn_Connect.Name = "Btn_Connect";
            this.Btn_Connect.Size = new System.Drawing.Size(108, 23);
            this.Btn_Connect.TabIndex = 2;
            this.Btn_Connect.Text = "Connect";
            this.Btn_Connect.UseVisualStyleBackColor = true;
            this.Btn_Connect.Click += new System.EventHandler(this.Btn_Connect_Click);
            // 
            // Btn_SendCMD
            // 
            this.Btn_SendCMD.Location = new System.Drawing.Point(15, 243);
            this.Btn_SendCMD.Name = "Btn_SendCMD";
            this.Btn_SendCMD.Size = new System.Drawing.Size(108, 23);
            this.Btn_SendCMD.TabIndex = 6;
            this.Btn_SendCMD.Text = "Send Command";
            this.Btn_SendCMD.UseVisualStyleBackColor = true;
            this.Btn_SendCMD.Click += new System.EventHandler(this.Btn_SendCMD_Click);
            // 
            // TB_Param1
            // 
            this.TB_Param1.Location = new System.Drawing.Point(15, 139);
            this.TB_Param1.Name = "TB_Param1";
            this.TB_Param1.Size = new System.Drawing.Size(42, 20);
            this.TB_Param1.TabIndex = 12;
            this.TB_Param1.Text = "60";
            // 
            // UD_CMDID
            // 
            this.UD_CMDID.Location = new System.Drawing.Point(15, 87);
            this.UD_CMDID.Name = "UD_CMDID";
            this.UD_CMDID.Size = new System.Drawing.Size(32, 20);
            this.UD_CMDID.TabIndex = 10;
            this.UD_CMDID.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // UD_AxisID
            // 
            this.UD_AxisID.Location = new System.Drawing.Point(15, 113);
            this.UD_AxisID.Name = "UD_AxisID";
            this.UD_AxisID.Size = new System.Drawing.Size(32, 20);
            this.UD_AxisID.TabIndex = 11;
            // 
            // TB_Param4
            // 
            this.TB_Param4.Location = new System.Drawing.Point(15, 217);
            this.TB_Param4.Name = "TB_Param4";
            this.TB_Param4.Size = new System.Drawing.Size(42, 20);
            this.TB_Param4.TabIndex = 15;
            this.TB_Param4.Text = "100.0";
            // 
            // TB_Param3
            // 
            this.TB_Param3.Location = new System.Drawing.Point(15, 191);
            this.TB_Param3.Name = "TB_Param3";
            this.TB_Param3.Size = new System.Drawing.Size(42, 20);
            this.TB_Param3.TabIndex = 14;
            this.TB_Param3.Text = "100.0";
            // 
            // TB_Param2
            // 
            this.TB_Param2.Location = new System.Drawing.Point(15, 165);
            this.TB_Param2.Name = "TB_Param2";
            this.TB_Param2.Size = new System.Drawing.Size(42, 20);
            this.TB_Param2.TabIndex = 13;
            this.TB_Param2.Text = "100.0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(64, 94);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 13);
            this.label1.TabIndex = 13;
            this.label1.Text = "CMD ID";
            // 
            // Label_AxisID
            // 
            this.Label_AxisID.AutoSize = true;
            this.Label_AxisID.Location = new System.Drawing.Point(63, 120);
            this.Label_AxisID.Name = "Label_AxisID";
            this.Label_AxisID.Size = new System.Drawing.Size(72, 13);
            this.Label_AxisID.TabIndex = 14;
            this.Label_AxisID.Text = "Label_Axis ID";
            // 
            // Label_Param1
            // 
            this.Label_Param1.AutoSize = true;
            this.Label_Param1.Location = new System.Drawing.Point(63, 146);
            this.Label_Param1.Name = "Label_Param1";
            this.Label_Param1.Size = new System.Drawing.Size(46, 13);
            this.Label_Param1.TabIndex = 15;
            this.Label_Param1.Text = "Param 1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(63, 172);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 16;
            this.label4.Text = "Param 2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(63, 198);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 17;
            this.label5.Text = "Param 3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(63, 224);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(46, 13);
            this.label6.TabIndex = 18;
            this.label6.Text = "Param 4";
            // 
            // Btn_Reset
            // 
            this.Btn_Reset.Location = new System.Drawing.Point(12, 51);
            this.Btn_Reset.Name = "Btn_Reset";
            this.Btn_Reset.Size = new System.Drawing.Size(108, 23);
            this.Btn_Reset.TabIndex = 19;
            this.Btn_Reset.Text = "Reset";
            this.Btn_Reset.UseVisualStyleBackColor = true;
            this.Btn_Reset.Click += new System.EventHandler(this.Btn_Reset_Click);
            // 
            // BtnLoadSequence
            // 
            this.BtnLoadSequence.Location = new System.Drawing.Point(930, 67);
            this.BtnLoadSequence.Name = "BtnLoadSequence";
            this.BtnLoadSequence.Size = new System.Drawing.Size(98, 23);
            this.BtnLoadSequence.TabIndex = 26;
            this.BtnLoadSequence.Text = "Load Sequence";
            this.BtnLoadSequence.UseVisualStyleBackColor = true;
            this.BtnLoadSequence.Click += new System.EventHandler(this.BtnLoadCommands_Click);
            // 
            // TmrSequence
            // 
            this.TmrSequence.Tick += new System.EventHandler(this.TmrSequence_Tick);
            // 
            // BtnStartSequence
            // 
            this.BtnStartSequence.Location = new System.Drawing.Point(931, 96);
            this.BtnStartSequence.Name = "BtnStartSequence";
            this.BtnStartSequence.Size = new System.Drawing.Size(98, 23);
            this.BtnStartSequence.TabIndex = 27;
            this.BtnStartSequence.Text = "Start Sequence";
            this.BtnStartSequence.UseVisualStyleBackColor = true;
            this.BtnStartSequence.Click += new System.EventHandler(this.BtnStartSequence_Click);
            // 
            // BtnStopSequence
            // 
            this.BtnStopSequence.Location = new System.Drawing.Point(930, 125);
            this.BtnStopSequence.Name = "BtnStopSequence";
            this.BtnStopSequence.Size = new System.Drawing.Size(99, 23);
            this.BtnStopSequence.TabIndex = 28;
            this.BtnStopSequence.Text = "Stop Sequence";
            this.BtnStopSequence.UseVisualStyleBackColor = true;
            this.BtnStopSequence.Click += new System.EventHandler(this.BtnStopSequence_Click);
            // 
            // richTextBoxSequence
            // 
            this.richTextBoxSequence.Location = new System.Drawing.Point(446, 11);
            this.richTextBoxSequence.Name = "richTextBoxSequence";
            this.richTextBoxSequence.Size = new System.Drawing.Size(479, 737);
            this.richTextBoxSequence.TabIndex = 29;
            this.richTextBoxSequence.Text = "";
            // 
            // CBPause
            // 
            this.CBPause.AutoSize = true;
            this.CBPause.Location = new System.Drawing.Point(931, 154);
            this.CBPause.Name = "CBPause";
            this.CBPause.Size = new System.Drawing.Size(108, 17);
            this.CBPause.TabIndex = 30;
            this.CBPause.Text = "Pause every step";
            this.CBPause.UseVisualStyleBackColor = true;
            // 
            // BtnNext
            // 
            this.BtnNext.Location = new System.Drawing.Point(930, 177);
            this.BtnNext.Name = "BtnNext";
            this.BtnNext.Size = new System.Drawing.Size(98, 23);
            this.BtnNext.TabIndex = 31;
            this.BtnNext.Text = "Next";
            this.BtnNext.UseVisualStyleBackColor = true;
            this.BtnNext.Click += new System.EventHandler(this.BtnNext_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog1";
            this.openFileDialog.InitialDirectory = "C:\\Users\\wildschutj\\Documents\\svn\\XSS_Migration\\source\\trunk\\Control App\\Controll" +
    "er\\Supporting Scripts\\Com";
            // 
            // BtnSelect
            // 
            this.BtnSelect.Location = new System.Drawing.Point(931, 12);
            this.BtnSelect.Name = "BtnSelect";
            this.BtnSelect.Size = new System.Drawing.Size(98, 23);
            this.BtnSelect.TabIndex = 32;
            this.BtnSelect.Text = "Select File";
            this.BtnSelect.UseVisualStyleBackColor = true;
            this.BtnSelect.Click += new System.EventHandler(this.BtnSelect_Click);
            // 
            // textBoxSelect
            // 
            this.textBoxSelect.Location = new System.Drawing.Point(930, 41);
            this.textBoxSelect.Name = "textBoxSelect";
            this.textBoxSelect.Size = new System.Drawing.Size(214, 20);
            this.textBoxSelect.TabIndex = 33;
            this.textBoxSelect.Text = "C:\\Users\\wildschutj\\Documents\\svn\\XSS_Migration\\source\\trunk\\Control App\\Controll" +
    "er\\Supporting Scripts\\Com\\TstCmdBeltControl.csv";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1208, 789);
            this.Controls.Add(this.textBoxSelect);
            this.Controls.Add(this.BtnSelect);
            this.Controls.Add(this.BtnNext);
            this.Controls.Add(this.CBPause);
            this.Controls.Add(this.richTextBoxSequence);
            this.Controls.Add(this.BtnStopSequence);
            this.Controls.Add(this.BtnStartSequence);
            this.Controls.Add(this.BtnLoadSequence);
            this.Controls.Add(this.Btn_Reset);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Label_Param1);
            this.Controls.Add(this.Label_AxisID);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TB_Param2);
            this.Controls.Add(this.TB_Param3);
            this.Controls.Add(this.TB_Param4);
            this.Controls.Add(this.UD_AxisID);
            this.Controls.Add(this.UD_CMDID);
            this.Controls.Add(this.TB_Param1);
            this.Controls.Add(this.Btn_SendCMD);
            this.Controls.Add(this.Btn_Connect);
            this.Controls.Add(this.Btn_Load);
            this.Controls.Add(this.treeViewSymbols);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.UD_CMDID)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.UD_AxisID)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TreeView treeViewSymbols;
        private System.Windows.Forms.Button Btn_Load;
        private System.Windows.Forms.Button Btn_Connect;
        private System.Windows.Forms.Button Btn_SendCMD;
        private System.Windows.Forms.TextBox TB_Param1;
        private System.Windows.Forms.NumericUpDown UD_CMDID;
        private System.Windows.Forms.NumericUpDown UD_AxisID;
        private System.Windows.Forms.TextBox TB_Param4;
        private System.Windows.Forms.TextBox TB_Param3;
        private System.Windows.Forms.TextBox TB_Param2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Label_AxisID;
        private System.Windows.Forms.Label Label_Param1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Btn_Reset;
        protected System.Windows.Forms.Button BtnLoadSequence;
        private System.Windows.Forms.Timer TmrSequence;
        private System.Windows.Forms.Button BtnStartSequence;
        private System.Windows.Forms.Button BtnStopSequence;
        private System.Windows.Forms.RichTextBox richTextBoxSequence;
        private System.Windows.Forms.CheckBox CBPause;
        private System.Windows.Forms.Button BtnNext;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Button BtnSelect;
        private System.Windows.Forms.TextBox textBoxSelect;
    }
}

