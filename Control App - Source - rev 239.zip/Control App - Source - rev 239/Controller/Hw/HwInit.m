% -------------------------------------------------------------------------
% For now only connections to simulator.
% -------------------------------------------------------------------------

load_system( [ModelPath '\Hw\Lib_Hw.mdl'] )
set_param('Lib_Hw','Lock','off')

if strcmp(MnChoice, 'SIL')
     %No need to connect anything
end

if strcmp(MnChoice, 'PIL')
    % Prefixes used in TC environment
    pfixIn = 'TIRC^TcCOM Objects^Object1 (XSS_Simulator)^TcModuleInput^SimulatedOutputTerminals_';
    pfixOut = 'TIRC^TcCOM Objects^Object1 (XSS_Simulator)^TcModuleOutput^SimulatedInputTerminals_';

    %% From Terminals
    set_param('Lib_Hw/HIL/FromTerminals/SbcDevStsStatusDriveEnable',        'LinkToNode', [pfixOut 'SbcDevStsStatusDriveEnable']);
    set_param('Lib_Hw/HIL/FromTerminals/SbcDevStsStatusTerminalEL2521',     'LinkToNode', [pfixOut 'SbcDevStsStatusTerminalEL2521']);
    set_param('Lib_Hw/HIL/FromTerminals/SbcDevStsCounterValue',             'LinkToNode', [pfixOut 'SbcDevStsCounterValue']);

    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsStatus1',                 'LinkToNode', [pfixOut 'TrigDevStsStatus1']);
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsCounterValue1',           'LinkToNode', [pfixOut 'TrigDevStsCounterValue1']);
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsState1',                  'LinkToNode', [pfixOut 'TrigDevStsState1']);
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsStatus2',                 'LinkToNode', [pfixOut 'TrigDevStsStatus2']);
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsCounterValue2',           'LinkToNode', [pfixOut 'TrigDevStsCounterValue2']);
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsState2',                  'LinkToNode', [pfixOut 'TrigDevStsState3']);
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsStatus3',                 'LinkToNode', [pfixOut 'TrigDevStsStatus3']);
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsCounterValue3',           'LinkToNode', [pfixOut 'TrigDevStsCounterValue3']);
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsState3',                  'LinkToNode', [pfixOut 'TrigDevStsState4']);
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsStatus4',                 'LinkToNode', [pfixOut 'TrigDevStsStatus4']);
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsCounterValue4',           'LinkToNode', [pfixOut 'TrigDevStsCounterValue4']);
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsState4',                  'LinkToNode', [pfixOut 'TrigDevStsState4']);
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsStatus5',                 'LinkToNode', [pfixOut 'TrigDevStsStatus5']);
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsCounterValue5',           'LinkToNode', [pfixOut 'TrigDevStsCounterValue5']);
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsState5',                  'LinkToNode', [pfixOut 'TrigDevStsState5']);
    
    
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsStatusTerminalEL2024_1',          'LinkToNode', [pfixOut 'SortDevStsStatusTerminalEL2024_1']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsStatusTerminalEL2024_2',          'LinkToNode', [pfixOut 'SortDevStsStatusTerminalEL2024_2']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsStatusTerminalEL1018_1',          'LinkToNode', [pfixOut 'SortDevStsStatusTerminalEL1018_1']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsStatusTerminalEL1018_2',          'LinkToNode', [pfixOut 'SortDevStsStatusTerminalEL1018_2']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsStatusTerminalEL6002',            'LinkToNode', [pfixOut 'SortDevStsStatusTerminalEL6002']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsStatusTerminalEL9505',            'LinkToNode', [pfixOut 'SortDevStsStatusTerminalEL9505']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsErrorTerminalEL6002_Overrun',     'LinkToNode', [pfixOut 'SortDevStsErrorTerminalEL6002_Overrun']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsErrorTerminalEL6002_BufferFull',  'LinkToNode', [pfixOut 'SortDevStsErrorTerminalEL6002_BufferFull']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialInitAccepted',              'LinkToNode', [pfixOut 'SortDevStsSerialInitAccepted']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialReceiveRequest',            'LinkToNode', [pfixOut 'SortDevStsSerialReceiveRequest']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialInputLength',               'LinkToNode', [pfixOut 'SortDevStsSerialInputLength']);

    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData0',   'LinkToNode', [pfixOut 'SortDevStsSerialData0']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData1',   'LinkToNode', [pfixOut 'SortDevStsSerialData1']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData2',   'LinkToNode', [pfixOut 'SortDevStsSerialData2']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData3',   'LinkToNode', [pfixOut 'SortDevStsSerialData3']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData4',   'LinkToNode', [pfixOut 'SortDevStsSerialData4']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData5',   'LinkToNode', [pfixOut 'SortDevStsSerialData5']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData6',   'LinkToNode', [pfixOut 'SortDevStsSerialData6']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData7',   'LinkToNode', [pfixOut 'SortDevStsSerialData7']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData8',   'LinkToNode', [pfixOut 'SortDevStsSerialData8']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData9',   'LinkToNode', [pfixOut 'SortDevStsSerialData9']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData10',  'LinkToNode', [pfixOut 'SortDevStsSerialData10']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData11',  'LinkToNode', [pfixOut 'SortDevStsSerialData11']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData12',  'LinkToNode', [pfixOut 'SortDevStsSerialData12']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData13',  'LinkToNode', [pfixOut 'SortDevStsSerialData13']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData14',  'LinkToNode', [pfixOut 'SortDevStsSerialData14']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData15',  'LinkToNode', [pfixOut 'SortDevStsSerialData15']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData16',  'LinkToNode', [pfixOut 'SortDevStsSerialData16']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData17',  'LinkToNode', [pfixOut 'SortDevStsSerialData17']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData18',  'LinkToNode', [pfixOut 'SortDevStsSerialData18']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData19',  'LinkToNode', [pfixOut 'SortDevStsSerialData19']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData20',  'LinkToNode', [pfixOut 'SortDevStsSerialData20']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData21',  'LinkToNode', [pfixOut 'SortDevStsSerialData21']);

    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate1', 'LinkToNode', [pfixOut 'SortDevStsGate1']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate2', 'LinkToNode', [pfixOut 'SortDevStsGate2']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate3', 'LinkToNode', [pfixOut 'SortDevStsGate3']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate4', 'LinkToNode', [pfixOut 'SortDevStsGate4']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate5', 'LinkToNode', [pfixOut 'SortDevStsGate5']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate6', 'LinkToNode', [pfixOut 'SortDevStsGate6']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate7', 'LinkToNode', [pfixOut 'SortDevStsGate7']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate8', 'LinkToNode', [pfixOut 'SortDevStsGate8']);

    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB1', 'LinkToNode', [pfixOut 'SortDevStsFB1']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB2', 'LinkToNode', [pfixOut 'SortDevStsFB2']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB3', 'LinkToNode', [pfixOut 'SortDevStsFB3']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB4', 'LinkToNode', [pfixOut 'SortDevStsFB4']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB5', 'LinkToNode', [pfixOut 'SortDevStsFB5']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB6', 'LinkToNode', [pfixOut 'SortDevStsFB6']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB7', 'LinkToNode', [pfixOut 'SortDevStsFB7']);
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB8', 'LinkToNode', [pfixOut 'SortDevStsFB8']);

    set_param('Lib_Hw/HIL/FromTerminals/SteerDevStsStatusEL2521',       'LinkToNode', [pfixOut 'SteerDevStsStatusEL2521']);
    set_param('Lib_Hw/HIL/FromTerminals/SteerDevStsStatusSensor',       'LinkToNode', [pfixOut 'SteerDevStsStatusSensor']);
    set_param('Lib_Hw/HIL/FromTerminals/SteerDevStsErrorSensor',        'LinkToNode', [pfixOut 'SteerDevStsErrorSensor']);
    set_param('Lib_Hw/HIL/FromTerminals/SteerDevStsBeltEdgePosition',   'LinkToNode', [pfixOut 'SteerDevStsBeltEdgePosition']);
    set_param('Lib_Hw/HIL/FromTerminals/SteerDevStsCounterValue',       'LinkToNode', [pfixOut 'SteerDevStsCounterValue']);
    
    set_param('Lib_Hw/HIL/FromTerminals/IOSystemGasOn',              'LinkToNode', [pfixOut 'IOSystemGasOn']);
    set_param('Lib_Hw/HIL/FromTerminals/IOWeissVacuumOK',            'LinkToNode', [pfixOut 'IOWeissVacuumOK ']);
    set_param('Lib_Hw/HIL/FromTerminals/IOXRayUpPos',                'LinkToNode', [pfixOut 'IOXRayUpPos']);
    set_param('Lib_Hw/HIL/FromTerminals/IOBSAUp',                    'LinkToNode', [pfixOut 'IOBSAUp']);
    set_param('Lib_Hw/HIL/FromTerminals/IOBSADown',                  'LinkToNode', [pfixOut 'IOBSADown']);
    set_param('Lib_Hw/HIL/FromTerminals/IOFlowMeterLow',             'LinkToNode', [pfixOut 'IOFlowMeterLow']);
    set_param('Lib_Hw/HIL/FromTerminals/IOSortVacuumOn',             'LinkToNode', [pfixOut 'IOSortVacuumOn']);
    set_param('Lib_Hw/HIL/FromTerminals/IOSortUnitPresent',          'LinkToNode', [pfixOut 'IOSortUnitPresent']);
    set_param('Lib_Hw/HIL/FromTerminals/IOWeldDetect',               'LinkToNode', [pfixOut 'IOWeldDetect']);
    set_param('Lib_Hw/HIL/FromTerminals/IOBSAHome',                  'LinkToNode', [pfixOut 'IOBSAHome']);
    set_param('Lib_Hw/HIL/FromTerminals/IOEmergenecyStopPressed_NOT','LinkToNode', [pfixOut 'IOEmergenecyStopPressed_NOT']);
    set_param('Lib_Hw/HIL/FromTerminals/IOTrayPresent',              'LinkToNode', [pfixOut 'IOTrayPresent']);
    set_param('Lib_Hw/HIL/FromTerminals/IOKeyPresent',               'LinkToNode', [pfixOut 'IOKeyPresent']);
    set_param('Lib_Hw/HIL/FromTerminals/IOFilterActuatorActive',     'LinkToNode', [pfixOut 'IOFilterActuatorActive']);
    set_param('Lib_Hw/HIL/FromTerminals/IOFilterActuatorInactive',   'LinkToNode', [pfixOut 'IOFilterActuatorInactive']);
    set_param('Lib_Hw/HIL/FromTerminals/IOSortVacuumLevel',          'LinkToNode', [pfixOut 'IOSortVacuumLevel']);
    set_param('Lib_Hw/HIL/FromTerminals/IOWeldDetectAI',             'LinkToNode', [pfixOut 'IOWeldDetectAI']);
    set_param('Lib_Hw/HIL/FromTerminals/IOMassFlow1',                'LinkToNode', [pfixOut 'IOMassFlow1']);
    set_param('Lib_Hw/HIL/FromTerminals/IOMassFlow2',                'LinkToNode', [pfixOut 'IOMassFlow2']);
    
    set_param('Lib_Hw/HIL/FromTerminals/IOErrorTerminalMassFlow',  'LinkToNode', [pfixOut 'IOErrorTerminalMassFlow']);
    set_param('Lib_Hw/HIL/FromTerminals/IOErrorTerminalSortVacuum',  'LinkToNode', [pfixOut 'IOErrorTerminalSortVacuum']);
    set_param('Lib_Hw/HIL/FromTerminals/IOErrorTerminalEL9110',  'LinkToNode', [pfixOut 'IOErrorTerminalEL9110']);
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL1018_1',  'LinkToNode', [pfixOut 'IOStatusTerminalEL1018_1']);
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL1018_2',  'LinkToNode', [pfixOut 'IOStatusTerminalEL1018_2']);
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL3102',  'LinkToNode', [pfixOut 'IOStatusTerminalEL3102']);
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL2024_1',  'LinkToNode', [pfixOut 'IOStatusTerminalEL2024_1']);
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL2024_2',  'LinkToNode', [pfixOut 'IOStatusTerminalEL2024_2']);
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL9110',    'LinkToNode', [pfixOut 'IOStatusTerminalEL9110']);
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL2024_3', 'LinkToNode', [pfixOut 'IOStatusTerminalEL2024_3']);
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL2024_4', 'LinkToNode', [pfixOut 'IOStatusTerminalEL2024_4']);
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL4011', 'LinkToNode', [pfixOut 'IOStatusTerminalEL4011']);
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL2612_1', 'LinkToNode', [pfixOut 'IOStatusTerminalEL2612_1']);
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL2612_2', 'LinkToNode', [pfixOut 'IOStatusTerminalEL2612_2']);    

    %% To Terminals
    set_param('Lib_Hw/HIL/ToTerminals/SbcDevCmdFrequencyValue',     'LinkToNode', [pfixIn 'SbcDevCmdFrequencyValue']);
    set_param('Lib_Hw/HIL/ToTerminals/SbcDevCmdDriveEnable_NOT',    'LinkToNode', [pfixIn 'SbcDevCmdDriveEnable_NOT']);
    set_param('Lib_Hw/HIL/ToTerminals/SbcDevCmdReset',              'LinkToNode', [pfixIn 'SbcDevCmdReset']);

    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdReset1',             'LinkToNode', [pfixIn 'TrigDevCmdReset1']);
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBaseFrequency1',     'LinkToNode', [pfixIn 'TrigDevCmdBaseFrequency1']);
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdFrequencyValue1',    'LinkToNode', [pfixIn 'TrigDevCmdFrequencyValue1']);
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBFWrite1',           'LinkToNode', [pfixIn 'TrigDevCmdBFWrite1']);
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBaseFrequency2',     'LinkToNode', [pfixIn 'TrigDevCmdBaseFrequency2']);
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdFrequencyValue2',    'LinkToNode', [pfixIn 'TrigDevCmdFrequencyValue2']);
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBFWrite2',           'LinkToNode', [pfixIn 'TrigDevCmdBFWrite2']);
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBaseFrequency3',     'LinkToNode', [pfixIn 'TrigDevCmdBaseFrequency3']);
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdFrequencyValue3',    'LinkToNode', [pfixIn 'TrigDevCmdFrequencyValue3']);
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBFWrite3',           'LinkToNode', [pfixIn 'TrigDevCmdBFWrite3']);
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBaseFrequency4',     'LinkToNode', [pfixIn 'TrigDevCmdBaseFrequency4']);
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdFrequencyValue4',    'LinkToNode', [pfixIn 'TrigDevCmdFrequencyValue4']);
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBFWrite4',           'LinkToNode', [pfixIn 'TrigDevCmdBFWrite4']);
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBaseFrequency5',     'LinkToNode', [pfixIn 'TrigDevCmdBaseFrequency5']);
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdFrequencyValue5',    'LinkToNode', [pfixIn 'TrigDevCmdFrequencyValue5']);
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBFWrite5',           'LinkToNode', [pfixIn 'TrigDevCmdBFWrite5']);
    
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation1', 'LinkToNode', [pfixIn 'SortNozzleActivation1']);
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation2', 'LinkToNode', [pfixIn 'SortNozzleActivation2']);
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation3', 'LinkToNode', [pfixIn 'SortNozzleActivation3']);
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation4', 'LinkToNode', [pfixIn 'SortNozzleActivation4']);
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation5', 'LinkToNode', [pfixIn 'SortNozzleActivation5']);
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation6', 'LinkToNode', [pfixIn 'SortNozzleActivation6']);
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation7', 'LinkToNode', [pfixIn 'SortNozzleActivation7']);
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation8', 'LinkToNode', [pfixIn 'SortNozzleActivation8']);

    set_param('Lib_Hw/HIL/ToTerminals/SortDevCmdGateMuteLed',           'LinkToNode', [pfixIn 'SortDevCmdGateMuteLed']);
    set_param('Lib_Hw/HIL/ToTerminals/SortDevCmdSerialInitRequest',     'LinkToNode', [pfixIn 'SortDevCmdSerialInitRequest']);
    set_param('Lib_Hw/HIL/ToTerminals/SortDevCmdSerialReceiveAccepted', 'LinkToNode', [pfixIn 'SortDevCmdSerialReceiveAccepted']);

    set_param('Lib_Hw/HIL/ToTerminals/SteerDevCmdDriveEnable_NOT',  'LinkToNode', [pfixIn 'SteerDevCmdDriveEnable_NOT']);
    set_param('Lib_Hw/HIL/ToTerminals/SteerDevCmdFrequencyValue',   'LinkToNode', [pfixIn 'SteerDevCmdFrequencyValue']);
    set_param('Lib_Hw/HIL/ToTerminals/SteerDevCmdReset',            'LinkToNode', [pfixIn 'SteerDevCmdReset']);

    set_param('Lib_Hw/HIL/ToTerminals/IOSetBSAUp',                      'LinkToNode', [pfixIn 'IOSetBSAUp']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetBSADown',                    'LinkToNode', [pfixIn 'IOSetBSADown']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetVacuumGeneratorTrayHndlr',   'LinkToNode', [pfixIn 'IOSetVacuumGeneratorTrayHndlr']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetSystemGas',                  'LinkToNode', [pfixIn 'IOSetSystemGas']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetXRayCameraUp',               'LinkToNode', [pfixIn 'IOSetXRayCameraUp']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetXRayCameraDown',             'LinkToNode', [pfixIn 'IOSetXRayCameraDown']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetFeeder',                     'LinkToNode', [pfixIn 'IOSetFeeder']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetHopper',                     'LinkToNode', [pfixIn 'IOSetHopper']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetLightInspectionCamera',      'LinkToNode', [pfixIn 'IOSetLightInspectionCamera']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetVacuumPump',                 'LinkToNode', [pfixIn 'IOSetVacuumPump']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetCyclonGas',                  'LinkToNode', [pfixIn 'IOSetCyclonGas']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetSignalLight',                'LinkToNode', [pfixIn 'IOSetSignalLight']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetEmergencyStop_1',            'LinkToNode', [pfixIn 'IOSetEmergencyStop_1']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetEmergencyStop_2',            'LinkToNode', [pfixIn 'IOSetEmergencyStop_2']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetReturnCleanGasOn',           'LinkToNode', [pfixIn 'IOSetReturnCleanGasOn']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetFilterActuatorActive',       'LinkToNode', [pfixIn 'IOSetFilterActuatorActive']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetFilterActuatorInactive',     'LinkToNode', [pfixIn 'IOSetFilterActuatorInactive']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetVacuumPressureSetpoint',     'LinkToNode', [pfixIn 'IOSetVacuumPressureSetpoint']);
    set_param('Lib_Hw/HIL/ToTerminals/IOSetLineVacuumOn',               'LinkToNode', [pfixIn 'IOSetLineVacuumOn']);
end
if strcmp(MnChoice, 'HIL')
    
    % *************** To terminals/ST *************** %
    
    % Seedbelt Control
    set_param('Lib_Hw/HIL/ToTerminals/SbcDevCmdFrequencyValue',     'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 14 (EL2521-0025)^PTO Control^Frequency value');
    set_param('Lib_Hw/HIL/ToTerminals/SbcDevCmdDriveEnable_NOT',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 23 (EL2124)^Channel 1^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SbcDevCmdReset',              'LinkToNode', '');
    
    % Triggering
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdReset1',             'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering1.Reset');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBaseFrequency1',     'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering1.BF');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdFrequencyValue1',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 17 (EL2522)^PTO Control Channel 1^Frequency value');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBFWrite1',           'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering1.BFWrite');
    
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdReset2',             'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering2.Reset');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBaseFrequency2',     'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering2.BF');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdFrequencyValue2',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 17 (EL2522)^PTO Control Channel 2^Frequency value');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBFWrite2',           'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering2.BFWrite');
    
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdReset3',             'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering3.Reset');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBaseFrequency3',     'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering3.BF');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdFrequencyValue3',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 18 (EL2522)^PTO Control Channel 1^Frequency value');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBFWrite3',           'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering3.BFWrite');
    
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdReset4',             'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering4.Reset');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBaseFrequency4',     'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering4.BF');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdFrequencyValue4',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 18 (EL2522)^PTO Control Channel 2^Frequency value');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBFWrite4',           'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering4.BFWrite');
    
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdReset5',             'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering5.Reset');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBaseFrequency5',     'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering5.BF');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdFrequencyValue5',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 16 (EL2521)^PTO Control^Frequency value');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBFWrite5',           'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering5.BFWrite');
        
    % Sort/Serial
    set_param('Lib_Hw/HIL/ToTerminals/SortDevCmdSerialInitRequest',     'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM RxPDO-Map Outputs Channel 1^Ctrl^Init request');
    set_param('Lib_Hw/HIL/ToTerminals/SortDevCmdSerialReceiveAccepted', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM RxPDO-Map Outputs Channel 1^Ctrl^Receive accepted');
    
    set_param('Lib_Hw/HIL/ToTerminals/SortDevCmdGateMuteLed',           'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 10 (EL2024)^Channel 3^Output');
    
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation1', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 25 (EK1100)^Term 26 (EL2024)^Channel 1^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation2', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 25 (EK1100)^Term 26 (EL2024)^Channel 2^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation3', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 25 (EK1100)^Term 26 (EL2024)^Channel 3^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation4', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 25 (EK1100)^Term 26 (EL2024)^Channel 4^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation5', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 25 (EK1100)^Term 27 (EL2024)^Channel 1^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation6', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 25 (EK1100)^Term 27 (EL2024)^Channel 2^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation7', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 25 (EK1100)^Term 27 (EL2024)^Channel 3^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation8', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 25 (EK1100)^Term 27 (EL2024)^Channel 4^Output');

    % Steering
    set_param('Lib_Hw/HIL/ToTerminals/SteerDevCmdDriveEnable_NOT',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 23 (EL2124)^Channel 2^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SteerDevCmdFrequencyValue',   'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 15 (EL2521-0025)^PTO Control^Frequency value');
    set_param('Lib_Hw/HIL/ToTerminals/SteerDevCmdReset',            'LinkToNode', '');

    % InOutputs
    set_param('Lib_Hw/HIL/ToTerminals/IOSetBSAUp',                      'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 9 (EL2024)^Channel 3^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetBSADown',                    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 9 (EL2024)^Channel 4^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetVacuumGeneratorTrayHndlr',   'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 13 (EL2024)^Channel 2^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetSystemGas',                  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 13 (EL2024)^Channel 3^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetXRayCameraUp',               'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 9 (EL2024)^Channel 1^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetXRayCameraDown',             'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 9 (EL2024)^Channel 2^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetFeeder',                     'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 20 (EL2612)^Channel 2^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetHopper',                     'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 20 (EL2612)^Channel 1^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetLightInspectionCamera',      'LinkToNode', '');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetVacuumPump',                 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 12 (EL2024)^Channel 1^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetCyclonGas',                  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 13 (EL2024)^Channel 1^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetSignalLight',                'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 10 (EL2024)^Channel 1^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetEmergencyStop_1',            'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 21 (EL2612)^Channel 1^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetEmergencyStop_2',            'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 21 (EL2612)^Channel 2^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetReturnCleanGasOn',           'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 13 (EL2024)^Channel 4^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetFilterActuatorActive',       'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 12 (EL2024)^Channel 2^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetFilterActuatorInactive',     'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 12 (EL2024)^Channel 3^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetVacuumPressureSetpoint',     'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 19 (EL4011)^AO Outputs^Analog output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetLineVacuumOn',               'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 10 (EL2024)^Channel 2^Output');
    
    % **************** From terminals/ST *************** %
    % Seedbelt Control
    set_param('Lib_Hw/HIL/FromTerminals/SbcDevStsStatusDriveEnable',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 23 (EL2124)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/SbcDevStsCounterValue',         'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 14 (EL2521-0025)^ENC Status compact^Counter value');
    set_param('Lib_Hw/HIL/FromTerminals/SbcDevStsStatusTerminalEL2521', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 14 (EL2521-0025)^InfoData^State');
    
    % Triggering
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsStatus1',         'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 17 (EL2522)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsCounterValue1',   'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 17 (EL2522)^ENC Status Channel 1^Counter value');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsState1',          'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Outputs^Triggering1.StateOut');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsStatus2',         'LinkToNode', '');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsCounterValue2',   'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 17 (EL2522)^ENC Status Channel 2^Counter value');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsState2',          'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Outputs^Triggering2.StateOut');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsStatus3',         'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 18 (EL2522)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsCounterValue3',   'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 18 (EL2522)^ENC Status Channel 1^Counter value');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsState3',          'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Outputs^Triggering3.StateOut');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsStatus4',         'LinkToNode', '');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsCounterValue4',   'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 18 (EL2522)^ENC Status Channel 2^Counter value');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsState4',          'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Outputs^Triggering4.StateOut');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsStatus5',         'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 16 (EL2521)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsCounterValue5',   'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 16 (EL2521)^ENC Status^Counter value');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsState5',          'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Outputs^Triggering5.StateOut');
    
    % Sort/Serial    
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsStatusTerminalEL2024_1',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 25 (EK1100)^Term 26 (EL2024)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsStatusTerminalEL2024_2',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 25 (EK1100)^Term 27 (EL2024)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsStatusTerminalEL1018_1',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 5 (EL1018)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsStatusTerminalEL1018_2',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 6 (EL1018)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsStatusTerminalEL6002',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Status^Overrun error');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsStatusTerminalEL9505',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 22 (EL9505)^InfoData^State');
        
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsErrorTerminalEL6002_Overrun',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Status^Overrun error');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsErrorTerminalEL6002_BufferFull', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Status^Buffer full');
    
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialInitAccepted',      'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Status^Init accepted');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialReceiveRequest',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Status^Receive request');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialInputLength',       'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Status^Input length');
    
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData0',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 0');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData1',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 1');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData2',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 2');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData3',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 3');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData4',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 4');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData5',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 5');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData6',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 6');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData7',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 7');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData8',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 8');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData9',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 9');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData10',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 10');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData11',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 11');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData12',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 12');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData13',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 13');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData14',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 14');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData15',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 15');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData16',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 16');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData17',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 17');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData18',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 18');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData19',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 19');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData20',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 20');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsSerialData21',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 24 (EL6002)^COM TxPDO-Map Inputs Channel 1^Data In 21');
    
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate1',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 6 (EL1018)^Channel 1^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate2',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 6 (EL1018)^Channel 2^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate3',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 6 (EL1018)^Channel 3^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate4',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 6 (EL1018)^Channel 4^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate5',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 6 (EL1018)^Channel 5^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate6',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 6 (EL1018)^Channel 6^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate7',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 6 (EL1018)^Channel 7^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate8',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 6 (EL1018)^Channel 8^Input');
    
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB1', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 5 (EL1018)^Channel 1^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB2', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 5 (EL1018)^Channel 2^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB3', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 5 (EL1018)^Channel 3^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB4', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 5 (EL1018)^Channel 4^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB5', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 5 (EL1018)^Channel 5^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB6', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 5 (EL1018)^Channel 6^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB7', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 5 (EL1018)^Channel 7^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsFB8', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 5 (EL1018)^Channel 8^Input');
    
    % Steering
    set_param('Lib_Hw/HIL/FromTerminals/SteerDevStsStatusEL2521', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 7 (EL3102)^Channel 1^Status');
    set_param('Lib_Hw/HIL/FromTerminals/SteerDevStsStatusSensor', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 7 (EL3102)^Channel 1^Status');
    set_param('Lib_Hw/HIL/FromTerminals/SteerDevStsErrorSensor',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 7 (EL3102)^Channel 1^Status');
    
    set_param('Lib_Hw/HIL/FromTerminals/SteerDevStsBeltEdgePosition',   'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 7 (EL3102)^Channel 1^Value');
    set_param('Lib_Hw/HIL/FromTerminals/SteerDevStsCounterValue',       'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 15 (EL2521-0025)^ENC Status compact^Counter value');
    
    % InOutputs
    set_param('Lib_Hw/HIL/FromTerminals/IOSystemGasOn',              'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 3 (EL1018)^Channel 5^Input');
    set_param('Lib_Hw/HIL/FromTerminals/IOWeissVacuumOK',            'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 3 (EL1018)^Channel 6^Input');
    set_param('Lib_Hw/HIL/FromTerminals/IOXRayUpPos',                'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 4 (EL1018)^Channel 5^Input');
    set_param('Lib_Hw/HIL/FromTerminals/IOBSAUp',                    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 4 (EL1018)^Channel 6^Input');
    set_param('Lib_Hw/HIL/FromTerminals/IOBSADown',                  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 4 (EL1018)^Channel 1^Input');
    set_param('Lib_Hw/HIL/FromTerminals/IOFlowMeterLow',             'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 3 (EL1018)^Channel 1^Input');
    set_param('Lib_Hw/HIL/FromTerminals/IOSortVacuumOn',             'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 3 (EL1018)^Channel 2^Input');
    set_param('Lib_Hw/HIL/FromTerminals/IOSortUnitPresent',          'LinkToNode', '');
    set_param('Lib_Hw/HIL/FromTerminals/IOWeldDetect',               'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 3 (EL1018)^Channel 3^Input');
    set_param('Lib_Hw/HIL/FromTerminals/IOBSAHome',                  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 3 (EL1018)^Channel 4^Input');
    set_param('Lib_Hw/HIL/FromTerminals/IOEmergenecyStopPressed_NOT','LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 3 (EL1018)^Channel 7^Input');
    set_param('Lib_Hw/HIL/FromTerminals/IOTrayPresent',              'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 3 (EL1018)^Channel 8^Input');
    set_param('Lib_Hw/HIL/FromTerminals/IOKeyPresent',               'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 4 (EL1018)^Channel 2^Input');
    set_param('Lib_Hw/HIL/FromTerminals/IOFilterActuatorActive',     'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 4 (EL1018)^Channel 3^Input');
    set_param('Lib_Hw/HIL/FromTerminals/IOFilterActuatorInactive',   'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 4 (EL1018)^Channel 4^Input');
    set_param('Lib_Hw/HIL/FromTerminals/IOSortVacuumLevel',          'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 8 (EL3102)^AI Standard Channel 2^Value');
    set_param('Lib_Hw/HIL/FromTerminals/IOWeldDetectAI',             'LinkToNode', '');
    set_param('Lib_Hw/HIL/FromTerminals/IOMassFlow1',                 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 8 (EL3102)^AI Standard Channel 1^Value');
    set_param('Lib_Hw/HIL/FromTerminals/IOMassFlow2',                 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 7 (EL3102)^Channel 2^Value');
    
    set_param('Lib_Hw/HIL/FromTerminals/IOErrorTerminalMassFlow',   'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 8 (EL3102)^AI Standard Channel 1^Status^Error');
    set_param('Lib_Hw/HIL/FromTerminals/IOErrorTerminalSortVacuum', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 8 (EL3102)^AI Standard Channel 2^Status^Error');
    set_param('Lib_Hw/HIL/FromTerminals/IOErrorTerminalEL9110',     'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 11 (EL9110)^PowerOK^Input');
    
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL1018_1',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 3 (EL1018)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL1018_2',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 4 (EL1018)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL3102',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 8 (EL3102)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL2024_1',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 9 (EL2024)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL2024_2',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 10 (EL2024)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL9110',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 11 (EL9110)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL2024_3',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 12 (EL2024)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL2024_4',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 13 (EL2024)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL4011',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 19 (EL4011)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL2612_1',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 20 (EL2612)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL2612_2',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 21 (EL2612)^InfoData^State');
end

if strcmp(MnChoice, 'TEST')
    warning('Risk: not sure if mapping of terminals is done correctly. Settings from last integration at Bayer were not committed to SVN...')

    % *************** To terminals/ST *************** %
    % Seedbelt Control
    set_param('Lib_Hw/HIL/ToTerminals/SbcDevCmdFrequencyValue',     'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 8 (EL2521-0025)^PTO Control^Frequency value');
    set_param('Lib_Hw/HIL/ToTerminals/SbcDevCmdDriveEnable_NOT',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 11 (EL2124)^Channel 1^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SbcDevCmdReset',              'LinkToNode', '');
    
    % Triggering
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdReset1',             'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering1.Reset');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBaseFrequency1',     'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering1.BF');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdFrequencyValue1',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 7 (EL2522)^PTO Control Channel 1^Frequency value');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBFWrite1',           'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering1.BFWrite');
    
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdReset2',             'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering2.Reset');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBaseFrequency2',     'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering2.BF');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdFrequencyValue2',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 7 (EL2522)^PTO Control Channel 2^Frequency value');
    set_param('Lib_Hw/HIL/ToTerminals/TrigDevCmdBFWrite2',           'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Inputs^Triggering2.BFWrite');
    

    % Sorting
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation1', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 4 (EL2024)^Channel 1^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation2', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 4 (EL2024)^Channel 2^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation3', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 4 (EL2024)^Channel 3^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation4', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 4 (EL2024)^Channel 4^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation5', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 5 (EL2024)^Channel 1^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation6', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 5 (EL2024)^Channel 2^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation7', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 5 (EL2024)^Channel 3^Output');
    set_param('Lib_Hw/HIL/ToTerminals/SortNozzleActivation8', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 5 (EL2024)^Channel 4^Output');
    
    % In/Outputs
    set_param('Lib_Hw/HIL/ToTerminals/IOSetFeeder',                     'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 9 (EL2612)^Channel 1^Output');
    set_param('Lib_Hw/HIL/ToTerminals/IOSetHopper',                     'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 9 (EL2612)^Channel 2^Output');
    
    % **************** From terminals/ST *************** %
    % Seedbelt Control
    set_param('Lib_Hw/HIL/FromTerminals/SbcDevStsStatusDriveEnable',    'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 10 (EL2124)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/SbcDevStsCounterValue',         'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 8 (EL2521-0025)^ENC Status compact^Counter value');
    set_param('Lib_Hw/HIL/FromTerminals/SbcDevStsStatusTerminalEL2521', 'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 8 (EL2521-0025)^InfoData^State');
    
    % Triggering
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsStatus1',         'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 17 (EL2522)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsCounterValue1',   'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 7 (EL2522)^ENC Status Channel 1^Counter value');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsState1',          'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Outputs^Triggering1.StateOut');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsStatus2',         'LinkToNode', ''); % Same as trigger device 1 so no need to check on this
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsCounterValue2',   'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 7 (EL2522)^ENC Status Channel 2^Counter value');
    set_param('Lib_Hw/HIL/FromTerminals/TrigDevStsState2',          'LinkToNode', 'TIPC^LowLevelControl^LowLevelControl Instance^PlcTask Outputs^Triggering2.StateOut');
    
    % Sorting    
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate1',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 2 (EL1018)^Channel 1^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate2',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 2 (EL1018)^Channel 2^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate3',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 2 (EL1018)^Channel 3^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate4',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 2 (EL1018)^Channel 4^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate5',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 2 (EL1018)^Channel 5^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate6',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 2 (EL1018)^Channel 6^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate7',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 2 (EL1018)^Channel 7^Input');
    set_param('Lib_Hw/HIL/FromTerminals/SortDevStsGate8',  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 2 (EL1018)^Channel 8^Input');
   
    % In/Outputs -> Status
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL1018_1',     'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 2 (EL1018)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL2024_1',     'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 4 (EL2024)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL2024_2',     'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 5 (EL2024)^InfoData^State');
    set_param('Lib_Hw/HIL/FromTerminals/IOStatusTerminalEL9110',       'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 3 (EL9110)^InfoData^State');
    
        % Workaround: There is not input on EMO so we connect it to the power OK of the EL9110, this will go '0' when thw poer is turned of due to EMO
    set_param('Lib_Hw/HIL/FromTerminals/IOEmergenecyStopPressed_NOT',   'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 10 (EL9505)^Status Uo^Power OK');
    
        % The key is hardwwired on the DEM1, we connect it to something
        % else that's always TRUE.
    set_param('Lib_Hw/HIL/FromTerminals/IOKeyPresent',                  'LinkToNode', 'TIID^Device 2 (EtherCAT)^Term 1 (EK1100)^Term 3 (EL9110)^PowerOK^Input');
end


warning('Changes were directly applied to Lib_Hw.mdl to map signals to the correct EtherCAT terminals. Typically it is not required to change the library unless functional changes are made');