%Trig init
Trig.Name = 'Trig'; %required! Has to be the same as object name.
Trig.Const.Model.Version.Major    = 1;  %maybe try to integrate SVN directory revision number here??
Trig.Const.Model.Version.Minor    = 0;
disp(sprintf('Trig Constants Preload. Version %d.%d', Trig.Const.Model.Version.Major, Trig.Const.Model.Version.Minor))

Trig.Const.UnitID = 2;

%-------------------------------------------------------------------------
% Sampletime
%-------------------------------------------------------------------------
Trig.Const.Ts      = Ts;    % Samplefrequency for CameraTrigger

%-------------------------------------------------------------------------
% Traject Commands
%-------------------------------------------------------------------------
Trig.Const.Mlc.TrjCmd.NoCommand             = 0;            % No Trigmand
Trig.Const.Mlc.TrjCmd.Reset                 = 1;            % Reset all axes to initial state
Trig.Const.Mlc.TrjCmd.SetTriggerParams      = 20;           % SetTriggerParams(AxisID PosInterval Delay 0 0)
Trig.Const.Mlc.TrjCmd.StartTriggering       = 21;           % Start triggering
Trig.Const.Mlc.TrjCmd.StopTriggering        = 22;           % Stop triggering
Trig.Const.Mlc.TrjCmd.ResetTriggerCounter   = 23;           % Reset triggercounters

%-----------------------------------------------------------------------
% SLC Mode Commands.
%-----------------------------------------------------------------------
Trig.Const.Slc.ModeCmd.TOFF                 = 1;            % Trigger off
Trig.Const.Slc.ModeCmd.TON                  = 2;            % Trigger enabled
Trig.Const.Slc.ModeCmd.TRESET               = 3;            % Trigger reset

%-----------------------------------------------------------------------
% Status Feedback
%-----------------------------------------------------------------------

Trig.Const.Mlc.Sts.Idle             = 1;    % Idle
Trig.Const.Mlc.Sts.Triggering       = 2;    % Triggering
Trig.Const.Mlc.Sts.Resetting        = 3;    % Resetting

%-----------------------------------------------------------------------
% Module ErrorID's
%-----------------------------------------------------------------------
Trig.Const.Err.Base             = Trig.Const.UnitID * 100;
Trig.Const.Err.NoError          = 0;
Trig.Const.Err.NotAccepted      = 1;
Trig.Const.Err.ParamOORange     = 2;     
Trig.Const.Err.CoEWrite         = 3;
Trig_Const.Err.Terminal_Trigger = 4;

