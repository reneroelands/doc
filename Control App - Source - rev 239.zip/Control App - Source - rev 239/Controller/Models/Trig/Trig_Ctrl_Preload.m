%%---------------------------------------------------------------------------------------------------------------
% CCM, Center for Concepts in Mechatronics
%---------------------------------------------------------------------------------------------------------------
% Trig : Encoder based frame grabber triggering.
%
% Initializes control tuning parameters
%
% Seed belt control defines a stepper control based on frequency setpoint.
% This control is suited for accurate velocity control.
% It can not be used for position control. This would lead to "servo-like" settling in absolute steps.
% 
% RPul,HKup,  2009-02-20     : Version XSSCC1
% ENuij,      2009-12-01     : Rewritten in new SAXCS template.
%
%---------------------------------------------------------------------------------------------------------------

disp(sprintf('Trig Control Preload.'))

%-----------------------------------------------------------------------
% Tuning parameters
%-----------------------------------------------------------------------

Trig.Tun.PosIntervalDef_mm   = 13.4e-3;                 % DefaultPosition interval  [mm]
Trig.Tun.DelayDef_s          = 0.0e-6;                  % Default trigger delay     [s]
Trig.Tun.ModuloDef           = 0;                       % Modulo                    [-] 
                                                        % Modulo=0 disables modulo function   
                                                        
Trig.Tun.MinPD   = 1000;
Trig.Tun.MaxPD   = 30000;
Trig.Tun.MinBF   = 101;
Trig.Tun.MaxBF   = 500000;
%-----------------------------------------------------------------------
% Scaling
%-----------------------------------------------------------------------

Trig.Tun.GearRatio           = 1/1;                     % Gear ratio  [-]
Trig.Tun.BeltPulleyRatio     = 30e-3/2;                 % Radius DriveRoll [m/rad]  
Trig.Tun.TotalRatio          = Trig.Tun.GearRatio * Trig.Tun.BeltPulleyRatio; %[m/rad]

Trig.Tun.NEncLines           = 5000;                    % lines/rev encoder
Trig.Tun.Ncounts             = Trig.Tun.NEncLines*4;    % Quadrature counter resolution

Trig.Tun.NbitsInterpolate    = 7;                       % Optional, number of bits interpolation -> 2^N fold
                                                        % 0 = No interpolation
% This number disables the interpolation for low speeds. 
% In that case the quadrature values are used directly.
Trig.Tun.Interpol_speed      =  320000;                 % RW if T-period > Interpol_speed go to quadrature mode
                                                        % T-period is number of 80 MHz counts for each encoderperiod
                                                        % Example frot 0.05Hz
                                                        % ->Interpol_speed=80e6/5000/0.05=320000 (Nencoder = 5000)
                                        
Trig.Tun.interp_freq        = 2.2e6;                    % Interpolation frequency (Hz), Max 2.2MHz
                                                        % Camera trigger pulsewidth in FPGA  clk counts
                                                        % MHAJ: Trig.Tun.trig_pulsewidth    = 1.8e-6/12.5e-9; 
Trig.Tun.trig_pulsewidth    = 4000;                     % 0..20bit

Trig.Tun.Sens_Sclng          = 2*pi*Trig.Tun.TotalRatio/(Trig.Tun.NEncLines*2^Trig.Tun.NbitsInterpolate);   % m/count

Trig.Tun.Snaphot_scaling_factor = 640 * 5;
