disp('Trig Simulation Preload')

% Stability of frequency oscillator
Trig.Sim.FreqJitter.Amplitude = 0.0;  % frequency modulation of 1px
Trig.Sim.FreqJitter.Frequency = 2*pi*0.2;
