%Com init
Com.Name = 'Com'; %required! Has to be the same as object name.

Com.Const.Model.Version.Major    = 1;  %maybe try to integrate SVN directory revision number here??
Com.Const.Model.Version.Minor    = 0;
disp(sprintf('Com Constants Preload. Version %d.%d', Com.Const.Model.Version.Major, Com.Const.Model.Version.Minor))


Com.Hc.Cmd.NoCommand           = 0;    % No Command
Com.Hc.Cmd.Reset           = 1;    % No Command
Com.Hc.Cmd.PullErrorFIFO       = 11;   % Pull error FIFO (get next error in FIFO)

Com.Err.Base  = 0;  % Corresponding to UnitID 0 in Error Code

Com.Err.NoError     = Com.Err.Base + 0;
Com.Err.NotAccepted = Com.Err.Base + 1;


