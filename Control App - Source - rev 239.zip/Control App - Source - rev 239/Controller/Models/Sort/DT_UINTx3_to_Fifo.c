/* DT_UINTx3_to_Fifo.c - non-inlined S-function to convert UINT32(3) to serialfifoptr */

#define         S_FUNCTION_LEVEL        2
#undef          S_FUNCTION_NAME
#define         S_FUNCTION_NAME         DT_UINTx3_to_Fifo

#include        <stddef.h>
#include        <stdlib.h>
#include        "simstruc.h"
#include        "Cmd_Routines.h"

#ifdef          MATLAB_MEX_FILE
#include        "mex.h"
#endif

#ifndef         MATLAB_MEX_FILE
//#include        <windows.h>
#endif

/* Input Arguments */
#define NR_ARGS                 (0)

#define NR_I_WORKS              (0)
#define NR_P_WORKS              (0)
#define FIFO_P_IND              (0)

#define NR_R_WORKS              (0)

#define NR_IN_PORTS             (1)     /* max no of ports */
#define NR_OUT_PORTS            (1)     /* max no of ports */

#define IN_PORT_DATA            (0)
#define OUT_PORT_FIFO           (0)

static char_T msg[256];

static void mdlInitializeSizes(SimStruct *S)
{
    int i;
    DTypeId id = SS_UINT32;
#ifdef          MATLAB_MEX_FILE
//    serialfifoptr fifozero;
#endif

    ssSetNumSFcnParams(S, NR_ARGS);
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        ssPrintf(msg,"Wrong number of input arguments passed.\n%d arguments are expected\n", NR_ARGS);
        ssSetErrorStatus(S,"Wrong number of input arguments passed.");
        return;
    }

    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

    // port 0 is the fifo data
#ifdef          MATLAB_MEX_FILE
    // First create the custom data type for a fifo pointer
    // The Register call defines the signal as a unique type for Simulink
    id = ssRegisterDataType( S, "serialfifoptr" );
    if(id == INVALID_DTYPE_ID)
        return;
    ssSetDataTypeSize(S, id, 12 );

    if( ssGetDataTypeZero( S, id ) == NULL )
    {
        serialfifoptr fifozero;
        fifozero.ptrlow = 0;
        fifozero.ptrhigh = 0;
        fifozero.token = 0;
        ssSetDataTypeZero( S, id, &fifozero );
    }
    // Neither of these functions can be called from the target side.
#endif

    if( !ssSetNumInputPorts(S, NR_IN_PORTS) )return;
    if( !ssSetNumOutputPorts(S, NR_OUT_PORTS) )return;

    //-------------------  PortNr,                 Width, Type,      Contiguous, DirectFF
    SetInputPortConfig( S, IN_PORT_DATA,               3, SS_UINT32, 1, 1);

    //--------------------  PortNr,                Width, Type
    SetOutputPortConfig( S, OUT_PORT_FIFO,              1,     id);

    ssSetNumSampleTimes(S, 1);

    ssSetNumRWork(S, NR_R_WORKS );
    ssSetNumIWork(S, NR_I_WORKS );
    ssSetNumPWork(S, NR_P_WORKS );

    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);

    for( i = 0 ; i < NR_ARGS ; i++ )
    {
        ssSetSFcnParamTunable(S,i,0);  /* None of the parameters are tunable */
    }

    ssSetSimStateCompliance(S, DISALLOW_SIM_STATE);

    ssSetOptions(S, SS_OPTION_DISALLOW_CONSTANT_SAMPLE_TIME | SS_OPTION_EXCEPTION_FREE_CODE |
                    SS_OPTION_NONSTANDARD_PORT_WIDTHS );
}

static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetModelReferenceSampleTimeInheritanceRule(S, USE_DEFAULT_FOR_DISCRETE_INHERITANCE);
    ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, 0.0);
}

#define MDL_START
static void mdlStart(SimStruct *S)
{
//     serialfifoptr *OPtr = ssGetOutputPortSignal(S,OUT_PORT_SERIAL_OUT);
// #ifdef _WIN64
//     OPtr->ptrlow  = (uint32_T)( (uint64_T)fifomem & 0xffffffff );
//     OPtr->ptrhigh = (uint32_T)( ((uint64_T)fifomem >> 32) & 0xffffffff );
// #else
//     OPtr->ptrlow  = (uint32_T)fifomem;
//     OPtr->ptrhigh = 0;
// #endif
//     OPtr->token = (int)'FiFo';
}

static void mdlOutputs(SimStruct *S, int_T tid)
{
    uint32_T      *IPtrData = ssGetInputPortSignal(S,IN_PORT_DATA);
    serialfifoptr *OPtrFifo = ssGetOutputPortSignal(S,OUT_PORT_FIFO);

    OPtrFifo->ptrlow  = (uint32_T)( IPtrData[0] );
    OPtrFifo->ptrhigh = (uint32_T)( IPtrData[1] );
    OPtrFifo->token   = (int)     ( IPtrData[2] );
}

static void mdlTerminate(SimStruct *S)
{
}

// #define MDL_RTW
// static void mdlRTW(SimStruct *S) {
//     int lid = (int)mxGetN( ID_ARG ) + 1;
//     char *id;
//     id = malloc(lid);
//     mxGetString( ID_ARG, id, lid );
//     /* We write the settings values to the RTW file, and reconstruct the
//      * IOArgs based on the run time output and input values */
//     ssWriteRTWParamSettings(S, 2, SSWRITE_VALUE_DTYPE_VECT, "settings",
//                             ssGetIWork(S), ssGetNumIWork(S),
//                             DTINFO(SS_INT32, 0),
//                             SSWRITE_VALUE_QSTR, "id", id);
//     free(id);
// }

#ifdef MATLAB_MEX_FILE  /* Is this file being compiled as a MEX-file? */
#include "simulink.c"   /* Mex glue */
#else
#include "cg_sfun.h"    /* Code generation glue */
#endif
