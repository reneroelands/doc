/* $Revision: 1.0$ $Date: 2010/04/27 09:18:20 $ */
/* DRS_Sorter De Ruiter Seeds Sorter module 
*/

#define         S_FUNCTION_LEVEL        2
#undef          S_FUNCTION_NAME
#define         S_FUNCTION_NAME         DRS_SorterSimulation

#define DEBUG

#include        <stddef.h>
#include        <stdlib.h>
#include        "simstruc.h"
#include        "Cmd_Routines.h"

#ifdef          MATLAB_MEX_FILE
#include        "mex.h"
#endif

#ifndef         MATLAB_MEX_FILE
#include        <windows.h>
#endif

//----------------------------------------
// -- BEGIN --
// Copy here the in/output definition to the C testprogram
// -- BEGIN --
//----------------------------------------

#define NR_IN_PORTS                 	6
#define IN_PORT_SimMode					0
#define IN_PORT_TriggerCounter      	1
#define IN_PORT_BeltLength_mm    		2
#define IN_PORT_TriggerDistance_mm    	3
#define IN_PORT_TimeToGate_ms    		4
#define IN_PORT_BeltVelocity     		5

#define NR_OUT_PORTS                4
#define OUT_PORT_GateActive			0
#define OUT_PORT_SerialFifo       	1
#define OUT_PORT_Debug1            	2
#define OUT_PORT_Debug2            	3

//-- Parameters section
#define NUMBER_OF_ARGS          (0)

#define SAMPLE_TIME_0        INHERITED_SAMPLE_TIME

//-- Local variables
#define NO_R_WORKS              (0)

#define NO_I_WORKS              (1)
#define OUTFIFO_I_IND           (0)

#define NO_P_WORKS              (5)
#define TRIGGERARRAY_P_IND      (0)
#define TPOINTERREAD_P_IND      (1)
#define TPOINTERWRITE_P_IND     (2)
#define LASTTRIGGERADD_P_IND    (3)
#define CURRENTTS_P_IND         (4)

#define MAXNROFSEEDS			5000
#define MAXUINT32 				4294967295
#define STD_FIFO_SIZE   (2048)


/* Function: mdlInitializeSizes ===============================================
 * Abstract:
 *   Setup sizes of the various vectors.
 */
static void mdlInitializeSizes(SimStruct *S)
{
    DTypeId id = SS_UINT32;
    ssSetNumSFcnParams(S, NUMBER_OF_ARGS);  /* Number of expected parameters */
 #if defined(MATLAB_MEX_FILE)
	if (ssGetNumSFcnParams(S) == ssGetSFcnParamsCount(S)) {
	  if (ssGetErrorStatus(S) != NULL) {
	    return;
	  }
	 } else {
	   return; /* Parameter mismatch will be reported by Simulink */
	 }
 #endif

    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

#ifdef          MATLAB_MEX_FILE
    // First create the custom data type for a fifo pointer
    // The Register call defines the signal as a unique type for Simulink
    id = ssRegisterDataType( S, "serialfifoptr" );
    if(id == INVALID_DTYPE_ID)
        return;
    ssSetDataTypeSize(S, id, 12 );
    if( ssGetDataTypeZero( S, id ) == NULL )
    {
        serialfifoptr fifozero;
        
        fifozero.ptrlow = 0;
        fifozero.ptrhigh = 0;
        fifozero.token = 0;
        ssSetDataTypeZero( S, id, &fifozero );
    }
    // Neither of these functions can be called from the target side.
#endif

	//-- Initialize input port
    ssSetNumInputPorts(S, NR_IN_PORTS);

    //-------------------  PortNr,                 		Width, 		Type,      Contiguous, DirectFF
    SetInputPortConfig( S, IN_PORT_SimMode, 			1,     SS_UINT32,   1,          1);
    SetInputPortConfig( S, IN_PORT_TriggerCounter,	    1,     SS_UINT32,   1,          1);
    SetInputPortConfig( S, IN_PORT_BeltLength_mm,	    1,     SS_DOUBLE,   1,          1);
    SetInputPortConfig( S, IN_PORT_TriggerDistance_mm,  1,     SS_DOUBLE,   1,          1);
    SetInputPortConfig( S, IN_PORT_TimeToGate_ms,	    1,     SS_DOUBLE,   1,          1);
    SetInputPortConfig( S, IN_PORT_BeltVelocity,        1,     SS_DOUBLE,   1,          1);

    //-- Initialize output ports
    ssSetNumOutputPorts(S, NR_OUT_PORTS);

    //--------------------  PortNr,                Width, Type
    SetOutputPortConfig( S, OUT_PORT_GateActive,	8,     SS_BOOLEAN);
    SetOutputPortConfig( S, OUT_PORT_SerialFifo,	1,     id);
    SetOutputPortConfig( S, OUT_PORT_Debug1,        1,     SS_DOUBLE);
    SetOutputPortConfig( S, OUT_PORT_Debug2,        1,     SS_DOUBLE);

    ssSetNumSampleTimes(S, 1);
    ssSetNumRWork(S, NO_R_WORKS);
    ssSetNumIWork(S, NO_I_WORKS);
    ssSetNumPWork(S, NO_P_WORKS);
    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);

    /* Take care when specifying exception free code - see sfuntmpl_doc.c */
    ssSetOptions(S, (SS_OPTION_EXCEPTION_FREE_CODE |
                     SS_OPTION_USE_TLC_WITH_ACCELERATOR 
                    )); //SS_OPTION_WORKS_WITH_CODE_REUSE
}


/* Function: mdlInitializeSampleTimes =========================================
 * Abstract:
 *    Specifiy  the sample time.
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTime(S, 0, SAMPLE_TIME_0);
    ssSetOffsetTime(S, 0, 0.0);
}

//----------------------------------------
// -- BEGIN --
// Copy here the S-Function code to the C testprogram
// -- BEGIN --
//----------------------------------------

#define MDL_START
static void mdlStart(SimStruct *S)
{
    int *fifomem = CreateFifo( S , STD_FIFO_SIZE, OUTFIFO_I_IND);

	uint32_T *TriggerArray = NULL;
    uint32_T *m_TPointerRead = NULL;
    uint32_T *m_TPointerWrite = NULL;
    uint32_T *m_LastTriggerAdd = NULL;
    uint32_T *m_CurrentTS = NULL;
	uint32_T ArrSize = 0;
  
	ArrSize = sizeof(uint32_T) * MAXNROFSEEDS;
    TriggerArray = (uint32_T *)malloc( ArrSize );
    if( TriggerArray == 0 )
    {
        sprintf_s(msg, MSGLEN, "Can't allocate memory for TriggerArray" );
        ssSetErrorStatus(S,msg);
        return;
    }
	memset(TriggerArray, 0, ArrSize);

    ssSetPWorkValue( S, TRIGGERARRAY_P_IND, (uint32_T *)TriggerArray );
	
    m_TPointerRead = (uint32_T *)malloc( sizeof(uint32_T)); *m_TPointerRead = 0;
    m_TPointerWrite = (uint32_T *)malloc( sizeof(uint32_T)); *m_TPointerWrite = 0;
	m_LastTriggerAdd = (uint32_T *)malloc( sizeof(uint32_T)); *m_LastTriggerAdd = 0;
	m_CurrentTS = (uint32_T *)malloc( sizeof(uint32_T)); *m_CurrentTS = 1;

    ssSetPWorkValue( S, TPOINTERREAD_P_IND, (uint32_T *)m_TPointerRead );
    ssSetPWorkValue( S, TPOINTERWRITE_P_IND, (uint32_T *)m_TPointerWrite );
    ssSetPWorkValue( S, LASTTRIGGERADD_P_IND, (uint32_T *)m_LastTriggerAdd );
    ssSetPWorkValue( S, CURRENTTS_P_IND, (uint32_T *)m_CurrentTS );
}

/* Function: mdlOutputs =======================================================
 *
*/
void SimMode1(SimStruct *S, serialfifoptr* Fifo);

static void mdlOutputs(SimStruct *S, int_T tid)
{

	uint32_T *m_TriggerArray = (uint32_T *)ssGetPWorkValue( S, TRIGGERARRAY_P_IND );
    uint32_T *m_RPointer = (uint32_T *)ssGetPWorkValue( S, TPOINTERREAD_P_IND ); 
    uint32_T *m_WPointer = (uint32_T *)ssGetPWorkValue( S, TPOINTERWRITE_P_IND );
    uint32_T *m_CurrentTS = (uint32_T *)ssGetPWorkValue( S, CURRENTTS_P_IND );

    const uint32_T  *I_SimMode        = (const uint32_T*) ssGetInputPortSignal(S,IN_PORT_SimMode);

	int_T *OPtr = (int_T *)ssGetOutputPortSignal(S,OUT_PORT_SerialFifo);
	boolean_T *OGateActive = (boolean_T *)ssGetOutputPortSignal(S,OUT_PORT_GateActive);

    int_T *OutFifo = (int_T *)ssGetIWorkValue( S, OUTFIFO_I_IND );
	real_T *ODebug2 = (real_T *)ssGetOutputPortSignal(S,OUT_PORT_Debug2);
    const uint32_T  *I_TriggerCounter     = (const uint32_T*) ssGetInputPortSignal(S,IN_PORT_TriggerCounter);


	switch(*I_SimMode)
	{
		case 1:
			SimMode1(S, OutFifo);
			break;
	default:
			break;
	}
	
	// check if we have to trigger the gate signal
	// !! TODO. for now only gate signal for lane 1 !!
	if (m_TriggerArray[*m_RPointer] == *m_CurrentTS)
	{	// reset this entry
		m_TriggerArray[*m_RPointer] = 0;
		*m_RPointer = *m_RPointer + 1;
		OGateActive[0] = true;
	} else
	{
		OGateActive[0] = false;
	}
    
    // create a lot triggers for testing purposes
	//if ((*I_TriggerCounter % 100) == 0 )
    //{
	//	OGateActive[0] = true;
    //} else
    //{
	//	OGateActive[0] = false;
    //}
	//-- set the outputs
    OPtr[0] = (int) OutFifo;
    OPtr[1] = (int) FiFoID;
	
	*m_CurrentTS = *m_CurrentTS + 1;
}

void SimMode1(SimStruct *S, serialfifoptr* Fifo)
{
	// generate a vision message every N triggers
	int_T TriggerInterval = 714; // zaad per 5mm met 7 um triggerstep
	int_T TriggerOffset = 1;
	int_T LanePixel = 1;
	int_T Status = 0;
	real_T PValue = 0.65;
	
	#define SERIALMSGLEN	50
	char* Msg[SERIALMSGLEN];

    const uint32_T  *I_TriggerCounter     = (const uint32_T*) ssGetInputPortSignal(S,IN_PORT_TriggerCounter);
    const real_T    *I_BeltLength_mm      = (const real_T*) ssGetInputPortSignal(S,IN_PORT_BeltLength_mm);
    const real_T    *I_TriggerDistance_mm = (const real_T*) ssGetInputPortSignal(S,IN_PORT_TriggerDistance_mm);
    const real_T    *I_TimeToGate_ms      = (const real_T*) ssGetInputPortSignal(S,IN_PORT_TimeToGate_ms);
    const real_T    *I_BeltVelocity       = (const real_T*) ssGetInputPortSignal(S,IN_PORT_BeltVelocity);

	uint32_T *m_TriggerArray = (uint32_T *)ssGetPWorkValue( S, TRIGGERARRAY_P_IND );
    uint32_T *m_RPointer = (uint32_T *)ssGetPWorkValue( S, TPOINTERREAD_P_IND ); 
    uint32_T *m_WPointer = (uint32_T *)ssGetPWorkValue( S, TPOINTERWRITE_P_IND );
    uint32_T *m_LastTriggerAdd = (uint32_T *)ssGetPWorkValue( S, LASTTRIGGERADD_P_IND );
    uint32_T *m_CurrentTS = (uint32_T *)ssGetPWorkValue( S, CURRENTTS_P_IND );

  	real_T *ODebug1 = (real_T *)ssGetOutputPortSignal(S,OUT_PORT_Debug1);
	real_T *ODebug2 = (real_T *)ssGetOutputPortSignal(S,OUT_PORT_Debug2);

	//-- Retrieve the sampletime 
    time_T Ts = ssGetSampleTime(S, 0);
    
    real_T TriggersPerSample = 0;
    uint32_T BeltInTicks = 0;
    real_T TicksToGate = 0;


    *ODebug1 = *I_TriggerCounter;
//    *ODebug2 = 0;
	//-- check is interval is expired and add the message only once
	if ((*I_TriggerCounter % TriggerInterval) == 0 && *I_TriggerCounter > *m_LastTriggerAdd)
	{
        //*ODebug2 = *I_TriggerCounter;
        //PValue = (*I_TriggerCounter % 100) / 100.0;
		sprintf_s((const char *)Msg,SERIALMSGLEN, "1 %d %lu %lf %d\r\n", LanePixel, *I_TriggerCounter-TriggerOffset, PValue, Status);
		StringToFifo(Fifo, Msg);
		
		// Calculate time the seed travels to the gate
		// Calculate gate timestamp 
		TriggersPerSample = (*I_BeltVelocity / (*I_TriggerDistance_mm / 1000.0)) /  Ts;
		BeltInTicks = (*I_BeltLength_mm / *I_TriggerDistance_mm) / TriggersPerSample;

		//-- Convert Ts to ms instead of s
		TicksToGate = (*I_TimeToGate_ms) / Ts; 

		m_TriggerArray[*m_WPointer] = *m_CurrentTS + BeltInTicks + TicksToGate;
		*m_WPointer = ( *m_WPointer + 1 ) % MAXNROFSEEDS;
		*m_LastTriggerAdd = *I_TriggerCounter;
	}
}

/* Function: mdlTerminate =====================================================
 * Abstract:
 *    In this function, you should perform any actions that are necessary
 *    at the termination of a simulation.  For example, if memory was
 *    allocated in mdlStart, this is the place to free it.
 */
static void mdlTerminate(SimStruct *S)
{
    uint32_T* pInteger;

	FreeFifo( S, OUTFIFO_I_IND );

    pInteger = (uint32_T *)ssGetPWorkValue( S, TRIGGERARRAY_P_IND );
    free(pInteger);
    
    pInteger = (uint32_T*)ssGetPWorkValue( S, TPOINTERREAD_P_IND);
    free(pInteger);
    pInteger = (uint32_T*)ssGetPWorkValue( S, TPOINTERWRITE_P_IND);
    free(pInteger);
    pInteger = (uint32_T*)ssGetPWorkValue( S, LASTTRIGGERADD_P_IND);
    free(pInteger);
    pInteger = (uint32_T*)ssGetPWorkValue( S, CURRENTTS_P_IND);
    free(pInteger);
}

#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif


