/* $Revision: 1.0$ $Date: 2010/04/26 09:29:30 $ */
/* DRS_Parser De Ruiter Seeds Parse module between Vision communication and Sorter modules
*/

#define         S_FUNCTION_LEVEL        2
#undef          S_FUNCTION_NAME
#define         S_FUNCTION_NAME         DRS_RS232Test

#define DEBUG

#include        <stddef.h>
#include        <stdlib.h>
#include        "simstruc.h"
#include        "Cmd_Routines.h"

#ifdef          MATLAB_MEX_FILE
#include        "mex.h"
#endif

#ifndef         MATLAB_MEX_FILE
//#include        <windows.h>
#endif


//----------------------------------------
// -- BEGIN --
// Copy here the in/output definition to the C testprogram
// -- BEGIN --
//----------------------------------------

//-- Define In and Outputs
#define NR_IN_PORTS                 1
#define IN_PORT_SERIAL_IN           0

#define NR_OUT_PORTS                1
#define OUT_PORT_TRIGGERCOUNT       0

//-- Parameters section
#define NUMBER_OF_ARGS          (0)

#define SAMPLE_TIME_0        INHERITED_SAMPLE_TIME

//-- Local variables
#define NO_R_WORKS              (0)
#define NO_I_WORKS              (0)


#define MAXMSGLENGTH			50	/* Current msg length is 25. */

static unsigned char TerminatorRecvBuf[10]; 

//----------------------------------------
// -- END --
// Copy here the in/output definition to the C testprogram
// -- END --
//----------------------------------------

static bool CheckCommErr( int_T* IPtr );
static void ClearBuffer( int_T* IPtr );
static int  strPos( int_T* IPtr, const unsigned char* pBuf, int iOffset );

static void mdlInitializeSizes(SimStruct *S)
{
    int i = 0;
    int maxwidth = 0;
    DTypeId id = SS_UINT32;

    ssSetNumSFcnParams(S, NUMBER_OF_ARGS);
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        sprintf_s(msg,MSGLEN,"Wrong number of input arguments passed.\n%d arguments are expected\n",NUMBER_OF_ARGS);
        ssSetErrorStatus(S,msg);
        return;
    }
    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

    //-- Initialize input port
    ssSetNumInputPorts(S, NR_IN_PORTS);

    // port 0 is the fifo data received from a RS232_F block.
#ifdef          MATLAB_MEX_FILE
    // First create the custom data type for a fifo pointer
    // The Register call defines the signal as a unique type for Simulink
    id = ssRegisterDataType( S, "serialfifoptr" );
    if(id == INVALID_DTYPE_ID)
        return;
    // The Alias call tells RTW to insert a typedef into the generated code
//    ssSetDataTypeIdAliasedTo( S, id, /* SS_UINT32 */ 12 );
    ssSetDataTypeSize(S, id, 12 );
    // Neither of these functions can be called from the target side.
#endif

    
    //-------------------  PortNr,                 Width, Type,      Contiguous, DirectFF
    SetInputPortConfig( S, IN_PORT_SERIAL_IN, 		1,     id,         1,          1);

    //-- Initialize output ports
    ssSetNumOutputPorts(S, NR_OUT_PORTS);

    //--------------------  PortNr,                Width, Type
    SetOutputPortConfig( S, OUT_PORT_TRIGGERCOUNT,	1,     SS_UINT32);

    ssSetNumSampleTimes(S, 1);

    ssSetNumRWork(S, NO_R_WORKS);
    ssSetNumIWork(S, NO_I_WORKS);
    ssSetNumPWork(S, 0);

    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);

    for( i = 0 ; i < NUMBER_OF_ARGS ; i++ )
    {
        ssSetSFcnParamTunable(S,i,0);  /* None of the parameters are tunable */
    }

    ssSetOptions(S, SS_OPTION_EXCEPTION_FREE_CODE |
                    SS_OPTION_NONSTANDARD_PORT_WIDTHS ); // |
}

static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTime(S, 0, SAMPLE_TIME_0);
    ssSetOffsetTime(S, 0, 0.0);
}

//----------------------------------------
// -- BEGIN --
// Copy here the S-Function code to the C testprogram
// -- BEGIN --
//----------------------------------------

#define MDL_START
static void mdlStart(SimStruct *S)
{
		TerminatorRecvBuf[0] = (unsigned char) '\r';
		TerminatorRecvBuf[1] = (unsigned char) '\n';
		TerminatorRecvBuf[2] = (unsigned char) '\0';
}

static void mdlOutputs(SimStruct *S, int_T tid)
{
// Read the serial fifo input

    serialfifoptr *IPtr = ssGetInputPortSignal(S,IN_PORT_SERIAL_IN);
    
	// check if a rs232-F block is connected to our inport
    if( IPtr == 0 ) {
        sprintf_s(msg, MSGLEN, "No Fifo connected: NULL ptr (DRS_RS232Test.c)" );
//        ssWarning(S,msg);
        ssSetErrorStatus(S,msg);
        return;  // Do nothing
    }
    if( IPtr->token != FiFoID )
    {
        sprintf_s(msg, MSGLEN, "No Fifo connected: FiFoID wrong (DRS_RS232Test.c)" );
        ssSetErrorStatus(S,msg);
        return; // Do nothing
    }
    
    #ifdef _WIN64
        int_T *Fifo = (int_T *)( (uint64_T)IPtr->ptrlow | ((uint64_T)IPtr->ptrhigh << 32));
    #else
        int_T *Fifo = (int_T *)IPtr->ptrlow;
    #endif

    int_T fifosize      = Fifo[0];
    int_T *rptr         = &Fifo[1];
    int_T *wptr         = &Fifo[2];
    int_T *data         = &Fifo[3];
    
	// retrieve pointers to output ports
    uint32_T         *O_TriggerCount= (uint32_T *)ssGetOutputPortRealSignal(S,OUT_PORT_TRIGGERCOUNT);

	// local helper variables
    unsigned char msgReceivedBuf[MAXMSGLENGTH];
    int_T iDelimPos = 0;
    int_T iScanned = 0;
    int_T fifocount = 0;
    unsigned long i=0;

	// message data
    int_T 		msgType = 0;
    int_T 		msgCamPixel = 0;
    uint32_T 	msgLineCount = 0;
    real_T 		msgPValue = 0;
    int_T 		msgStatus = 0;

	// check if a rs232-F block is connected to our inport
//     if( IPtr[0] == 0 && IPtr[1] == 0 ) {
//         return;  // Do nothing, unless there really is a fifowrite connected
//     }
    printf_s(msg, MSGLEN, "Test" );
    return;
    fifosize = Fifo[0];

	// how many characters are there in the buffer
    fifocount = *wptr - *rptr;
    if( fifocount < 0 )
        fifocount += fifosize;
    
    return;
 //-- Check if there are any RS232 errors (parity, etc...)
    if (CheckCommErr(IPtr))
    {
		ClearBuffer( IPtr );
    } else
    {
        //-- Received some rs232 data with no errors, check if it is complete
        //-- Check on delimiter
        if ((iDelimPos = strPos( IPtr, TerminatorRecvBuf, 0 )) != -1)
        {
			if (iDelimPos == 0)
			{	// only received a delimiter without data, just skip it.
				// skip the message terminator in the receive buffer
				for (i=0; i< strlen((const char *)TerminatorRecvBuf); i++)
				{
					*rptr = (*rptr + 1)%fifosize;
				}
			} else
			{
				//-- We received a complete answer without rs232 faults
				// copy it to the message buffer
				i = 0; // used as index in the msgReceivedBuf buffer
				while (iDelimPos > 0)
				{
					msgReceivedBuf[i++]=data[*rptr];
					*rptr = (*rptr + 1)%fifosize;
					iDelimPos--;
				}

				// terminate the message
				msgReceivedBuf[i] = '\0';
				// skip the message terminator in the receive buffer
				for (i=0; i<(int)strlen((const char *)TerminatorRecvBuf); i++)
				{
					*rptr = (*rptr + 1)%fifosize;
				}
				
	#ifdef DEBUG
	//				sprintf_s(msg,MSGLEN,"Recv=%s\r\n", msgReceivedBuf);
	//				DbgPrintf(S,msg);
	#endif
                        
                //-- Parse the received message
                iScanned = sscanf_s((const char *)msgReceivedBuf, "%d ",&msgType);
				if (iScanned == 1) // process only if completely scanned
				{
					*O_TriggerCount = msgType;
#ifdef DEBUG
        				sprintf_s(msg,MSGLEN,"LaneNr=%d\r\n", msgType);
                		DbgPrintf(S,msg);
#endif

				}
            }
        }
    }
}


#undef MDL_UPDATE  /* Change to #undef to remove function */
#if defined(MDL_UPDATE)
  /* Function: mdlUpdate ======================================================
   * Abstract:
   *    This function is called once for every major integration time step.
   *    Discrete states are typically updated here, but this function is useful
   *    for performing any tasks that should only take place once per
   *    integration step.
   */
  static void mdlUpdate(SimStruct *S, int_T tid)
  {
  }
#endif /* MDL_UPDATE */

static bool CheckCommErr( int_T* IPtr )
{
    int_T *Fifo = (int_T *)IPtr[0];
    int_T *rptr = &Fifo[1];
    int_T *wptr = &Fifo[2];
    int_T *data = &Fifo[3];
    int_T fifosize = Fifo[0];
    int fifocount = 0;
    int iIndex = 0;

    bool fFault = false;

    fifocount = *wptr - *rptr;
    if( fifocount < 0 )
    {
        fifocount += fifosize;
    }
    for( iIndex = 0 ; !fFault && iIndex < fifocount ; iIndex++ )
    {
        int loc = (*rptr + iIndex);
        if( loc >= fifosize )
            loc -= fifosize;

        // The following is only useful for the RS232 read system!
        if( (data[loc] & 0xff00) != 0) // error byte is set
        {
            fFault = true;
        }
    }
    return fFault;
}

static void ClearBuffer( int_T* IPtr )
{
    int_T *Fifo = (int_T *)IPtr[0];
    int_T *rptr = &Fifo[1];
    int_T *wptr = &Fifo[2];

    *rptr = *wptr;
}


//--
//-- Search pBuf string (null terminated) in IPtr fifo.
//-- return -1 = not found. Otherwise index of position found
//--
	static int strPos( int_T* IPtr, const unsigned char* pBuf, int iOffset )
{
    int_T *Fifo = (int_T *)IPtr[0];
    int_T *rptr = &Fifo[1];
    int_T *wptr = &Fifo[2];
    int_T *data = &Fifo[3];
    int_T fifosize = Fifo[0];
    int fifocount = 0;

    int_T iBufSize = strlen((const char *)pBuf);

    bool  fFound = false;
    int   iFoundPos = 0;

    fifocount = *wptr - *rptr;
    if( fifocount < 0 )
    {
        fifocount += fifosize;
    }

    //-- Search algorithm
    for( iFoundPos = iOffset ; !fFound &&
                               iFoundPos <= (fifocount - iBufSize) ; iFoundPos++ )
    {
        bool fPartFound = true;
        int iIndex = 0;

        for (iIndex=0; fPartFound && iIndex < iBufSize; iIndex++)
        {
            int loc = (*rptr + iFoundPos + iIndex);
            if( loc >= fifosize )
                loc -= fifosize;
            // since data in the fifo is always a 32 bit int, we don't have
            // to use the output data types here.

            if( (data[loc] & 0xff) != pBuf[iIndex] )
            {
                fPartFound = false;
            }
            // The following is only useful for the RS232 read system!
            if( (data[loc] & 0xff00) != 0) // error byte is set
            {
                fPartFound = false;
            }
        }
        fFound = fPartFound;
    }
    iFoundPos--; //-- Because the for-loop incremented it also when
                 //-- stopcriteria was reached.

    if (fFound)
    {
        return iFoundPos;
    }
    return -1;
}

static void mdlTerminate(SimStruct *S)
{
}

//----------------------------------------
// -- END --
// Copy here the S-Function code to the C testprogram
// -- END --
//----------------------------------------

#ifdef MATLAB_MEX_FILE  /* Is this file being compiled as a MEX-file? */
#include "simulink.c"   /* Mex glue */
#else
#include "cg_sfun.h"    /* Code generation glue */
#endif
