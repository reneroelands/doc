%Sdu EtherCAT init

disp(sprintf('Sorter EtherCAT Preload'))

clear Sort.Const.Ethercat

%--------------------------------------------------------------------------
% Sort digital outputs
%--------------------------------------------------------------------------
Sort.Const.Ethercat.NozzleCtrl1(1)    = {'Sort1_Nozzle1'};
Sort.Const.Ethercat.NozzleCtrl1(2)    = {'Sort1_Nozzle2'};
Sort.Const.Ethercat.NozzleCtrl1(3)    = {'Sort2_Nozzle1'};
Sort.Const.Ethercat.NozzleCtrl1(4)    = {'Sort2_Nozzle2'};
Sort.Const.Ethercat.NozzleCtrl1(5)    = {'Sort3_Nozzle1'};
Sort.Const.Ethercat.NozzleCtrl1(6)    = {'Sort3_Nozzle2'};
Sort.Const.Ethercat.NozzleCtrl1(7)    = {'Sort4_Nozzle1'};
Sort.Const.Ethercat.NozzleCtrl1(8)    = {'Sort4_Nozzle2'};

Sort.Const.Ethercat.NozzleCtrl2(1)    = {'Sort5_Nozzle1'};
Sort.Const.Ethercat.NozzleCtrl2(2)    = {'Sort5_Nozzle2'};
Sort.Const.Ethercat.NozzleCtrl2(3)    = {'Sort6_Nozzle1'};
Sort.Const.Ethercat.NozzleCtrl2(4)    = {'Sort6_Nozzle2'};
Sort.Const.Ethercat.NozzleCtrl2(5)    = {'Sort7_Nozzle1'};
Sort.Const.Ethercat.NozzleCtrl2(6)    = {'Sort7_Nozzle2'};
Sort.Const.Ethercat.NozzleCtrl2(7)    = {'Sort8_Nozzle1'};
Sort.Const.Ethercat.NozzleCtrl2(8)    = {'Sort8_Nozzle2'};

%--------------------------------------------------------------------------
% Seed detect gates
%--------------------------------------------------------------------------
Sort.Const.Ethercat.Gates(1)      = {'SortDetectGate1'};
Sort.Const.Ethercat.Gates(2)      = {'SortDetectGate2'};
Sort.Const.Ethercat.Gates(3)      = {'SortDetectGate3'};
Sort.Const.Ethercat.Gates(4)      = {'SortDetectGate4'};
Sort.Const.Ethercat.Gates(5)      = {'SortDetectGate5'};
Sort.Const.Ethercat.Gates(6)      = {'SortDetectGate6'};
Sort.Const.Ethercat.Gates(7)      = {'SortDetectGate7'};
Sort.Const.Ethercat.Gates(8)      = {'SortDetectGate8'};

%--------------------------------------------------------------------------
% Nozzle feedback signals
%--------------------------------------------------------------------------
Sort.Const.Ethercat.NozzleFB1(1)   = {'Sort1_Nozzle1_FB'};
Sort.Const.Ethercat.NozzleFB1(2)   = {'Sort1_Nozzle2_FB'};
Sort.Const.Ethercat.NozzleFB1(3)   = {'Sort2_Nozzle1_FB'};
Sort.Const.Ethercat.NozzleFB1(4)   = {'Sort2_Nozzle2_FB'};
Sort.Const.Ethercat.NozzleFB1(5)   = {'Sort3_Nozzle1_FB'};
Sort.Const.Ethercat.NozzleFB1(6)   = {'Sort3_Nozzle2_FB'};
Sort.Const.Ethercat.NozzleFB1(7)   = {'Sort4_Nozzle1_FB'};
Sort.Const.Ethercat.NozzleFB1(8)   = {'Sort4_Nozzle2_FB'};

Sort.Const.Ethercat.NozzleFB2(1)   = {'Sort5_Nozzle1_FB'};
Sort.Const.Ethercat.NozzleFB2(2)   = {'Sort5_Nozzle2_FB'};
Sort.Const.Ethercat.NozzleFB2(3)   = {'Sort6_Nozzle1_FB'};
Sort.Const.Ethercat.NozzleFB2(4)   = {'Sort6_Nozzle2_FB'};
Sort.Const.Ethercat.NozzleFB2(5)   = {'Sort7_Nozzle1_FB'};
Sort.Const.Ethercat.NozzleFB2(6)   = {'Sort7_Nozzle2_FB'};
Sort.Const.Ethercat.NozzleFB2(7)   = {'Sort8_Nozzle1_FB'};
Sort.Const.Ethercat.NozzleFB2(8)   = {'Sort8_Nozzle2_FB'};

%--------------------------------------------------------------------------
% Various digital inputs
%--------------------------------------------------------------------------
Sort.Const.Ethercat.DigIn1(1)      = {'SystemGasOn'};
Sort.Const.Ethercat.DigIn1(2)      = {'WeissVacuumOn'};
Sort.Const.Ethercat.DigIn1(3)      = {'XRay_Up_Pos'};
Sort.Const.Ethercat.DigIn1(4)      = {'BSA_Up_Pos'};
Sort.Const.Ethercat.DigIn1(5)      = {'BSA_Down_Pos'};
Sort.Const.Ethercat.DigIn1(6)      = {'FlowMeter1_Low'};
Sort.Const.Ethercat.DigIn1(7)      = {'FlowMeter2_Low'};
Sort.Const.Ethercat.DigIn1(8)      = {'SortVacuum1_On'};

Sort.Const.Ethercat.DigIn2(1)      = {'SortVacuum2_On'};
Sort.Const.Ethercat.DigIn2(2)      = {'SortUnit1_Present'};
Sort.Const.Ethercat.DigIn2(3)      = {'SortUnit2_Present'};
Sort.Const.Ethercat.DigIn2(4)      = {'WeldDetect1'};
Sort.Const.Ethercat.DigIn2(5)      = {'BSA_Home_Sensor'};
Sort.Const.Ethercat.DigIn2(6)      = {'EMO_OK'};
Sort.Const.Ethercat.DigIn2(7)      = {'Tray_Present'};
Sort.Const.Ethercat.DigIn2(8)      = {'WeldDetect2'};

Sort.Const.Ethercat.DigIn3(1)      = {'XRayFilterPresent'};
Sort.Const.Ethercat.DigIn3(2)      = {'KeyPresent'};
Sort.Const.Ethercat.DigIn3(3)      = {'FilterActuatorActive'};
Sort.Const.Ethercat.DigIn3(4)      = {'FilterActuatorInactive'};

%--------------------------------------------------------------------------
% Analog inputs
%--------------------------------------------------------------------------
Sort.Const.Ethercat.SignalsAIn(1)  = {'SortVacuum1_Level'};
Sort.Const.Ethercat.SignalsAIn(2)  = {'SortVacuum2_Level'};
Sort.Const.Ethercat.SignalsAIn(3)  = {'BeltEdge_Pos'};
Sort.Const.Ethercat.SignalsAIn(4)  = {'WeldDetect_AI'};
Sort.Const.Ethercat.SignalsAIn(5)  = {'MassFlow1'};
Sort.Const.Ethercat.SignalsAIn(6)  = {'MassFlow2'};

%--------------------------------------------------------------------------
% Various digital Outputs
%--------------------------------------------------------------------------
Outputs.Const.Ethercat.DigOut1(1)    = {'SetBeltSteeringUp'};
Outputs.Const.Ethercat.DigOut1(2)    = {'SetBeltSteeringDown'};

% Removed 05-sep-2016
% Outputs.Const.Ethercat.DigOut1(3)  = {'SetIonizer'};

Outputs.Const.Ethercat.DigOut1(3)    = {'SetVacGenTrayHndlr'};
Outputs.Const.Ethercat.DigOut1(4)    = {'SetSystemGas'};
Outputs.Const.Ethercat.DigOut1(5)    = {'SetXRayCameraUp'};
Outputs.Const.Ethercat.DigOut1(6)    = {'SetXRayCameraDown'};
Outputs.Const.Ethercat.DigOut1(7)    = {'SetFeeder'};

Outputs.Const.Ethercat.DigOut2(1)    = {'SetHopper'};
Outputs.Const.Ethercat.DigOut2(2)    = {'SetLightInspCamera'};
Outputs.Const.Ethercat.DigOut2(3)    = {'SetVacuumPump1'};
Outputs.Const.Ethercat.DigOut2(4)    = {'SetVacuumPump2'};
Outputs.Const.Ethercat.DigOut2(5)    = {'SetBlinkLed'};
Outputs.Const.Ethercat.DigOut2(6)    = {'SetCyclonGas'};
Outputs.Const.Ethercat.DigOut2(7)    = {'SetEmergencyStop_1'};
Outputs.Const.Ethercat.DigOut2(8)    = {'SetEmergencyStop_2'};

Outputs.Const.Ethercat.DigOut3(1)    = {'SetReturnCleanGasOn'};
Outputs.Const.Ethercat.DigOut3(2)    = {'SetFilterActuatorActive'};
Outputs.Const.Ethercat.DigOut3(3)    = {'SetFilterActuatorInactive'};
Outputs.Const.Ethercat.DigOut3(4)    = {'SetLineVacuumOn'};
Outputs.Const.Ethercat.DigOut3(5)    = {'SetGateMuteLed'};

Outputs.Const.Ethercat.AnalogOut(1)  = {'SetVacuumPressureSetpoint'};




