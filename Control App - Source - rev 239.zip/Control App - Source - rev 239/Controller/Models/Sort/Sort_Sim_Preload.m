disp('Sort Simulation Preload')

% Timing of pneumatic functions (default = 0.05 s)
Sort.Sim.Nozzle.StartDelay = 0.01;
Sort.Sim.Nozzle.FinishDelay = 0.04;

% All *_cnt below are in camera trigger count units (Trig.Tun.PosIntervalDef_mm)
GateDetectWindow_mm = 1.0;

convert = @(x) round(x/Trig.Tun.PosIntervalDef_mm);

Sort.Sim.Gate.Offset_cnt(1) = convert(Sort.Tun.Lane1.CamToGate_mm);
Sort.Sim.Gate.Offset_cnt(2) = convert(Sort.Tun.Lane2.CamToGate_mm);
Sort.Sim.Gate.Offset_cnt(3) = convert(Sort.Tun.Lane3.CamToGate_mm);
Sort.Sim.Gate.Offset_cnt(4) = convert(Sort.Tun.Lane4.CamToGate_mm);
Sort.Sim.Gate.Offset_cnt(5) = convert(Sort.Tun.Lane5.CamToGate_mm);
Sort.Sim.Gate.Offset_cnt(6) = convert(Sort.Tun.Lane6.CamToGate_mm);
Sort.Sim.Gate.Offset_cnt(7) = convert(Sort.Tun.Lane7.CamToGate_mm);
Sort.Sim.Gate.Offset_cnt(8) = convert(Sort.Tun.Lane8.CamToGate_mm);
Sort.Sim.Gate.Duration_cnt = convert(GateDetectWindow_mm);
Sort.Sim.Gate.FifoSize = 100;

Sort.Sim.Nozzle.Offset_cnt(1) = convert(Sort.Tun.Lane1.CamToGate_mm+Sort.Tun.Lane1.GateToNozzle_mm);
Sort.Sim.Nozzle.Offset_cnt(2) = convert(Sort.Tun.Lane2.CamToGate_mm+Sort.Tun.Lane2.GateToNozzle_mm);
Sort.Sim.Nozzle.Offset_cnt(3) = convert(Sort.Tun.Lane3.CamToGate_mm+Sort.Tun.Lane3.GateToNozzle_mm);
Sort.Sim.Nozzle.Offset_cnt(4) = convert(Sort.Tun.Lane4.CamToGate_mm+Sort.Tun.Lane4.GateToNozzle_mm);
Sort.Sim.Nozzle.Offset_cnt(5) = convert(Sort.Tun.Lane5.CamToGate_mm+Sort.Tun.Lane5.GateToNozzle_mm);
Sort.Sim.Nozzle.Offset_cnt(6) = convert(Sort.Tun.Lane6.CamToGate_mm+Sort.Tun.Lane6.GateToNozzle_mm);
Sort.Sim.Nozzle.Offset_cnt(7) = convert(Sort.Tun.Lane7.CamToGate_mm+Sort.Tun.Lane7.GateToNozzle_mm);
Sort.Sim.Nozzle.Offset_cnt(8) = convert(Sort.Tun.Lane8.CamToGate_mm+Sort.Tun.Lane8.GateToNozzle_mm);
Sort.Sim.Nozzle.PassDuration_cnt = convert(0.2);    % 2*Ts @ 100 mm/s
Sort.Sim.Nozzle.FifoSize = 100;

Sort.Sim.SeedData.FifoSize = 20*200;

Sort.Sim.PValue.Threshold = 0.6;    % Threshold for validation

clear convert
