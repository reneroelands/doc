/* TestSeedData_fifowrite.c - non-inlined S-function to copy simulated 
 * seed data to a serial fifo buffer, for the vision PC simulator */

#define         S_FUNCTION_LEVEL        2
#undef          S_FUNCTION_NAME
#define         S_FUNCTION_NAME         TestSeedData_fifowrite

#include        <stddef.h>
#include        <stdlib.h>
#include        <math.h>
#include        "simstruc.h"
#include        "Cmd_Routines.h"

#ifdef          MATLAB_MEX_FILE
#include        "mex.h"
#endif

#ifndef         MATLAB_MEX_FILE
//#include        <windows.h>
#endif

/* Input Arguments */
#define NR_ARGS                 (1)
#define ARG_FIFO_SIZE           ssGetSFcnParam(S,0)

#define NR_I_WORKS              (0)
#define NR_P_WORKS              (1)
#define FIFO_P_IND              (0)

#define NR_R_WORKS              (0)

#define NR_IN_PORTS             (3)     /* no of in ports */
#define NR_OUT_PORTS            (3)     /* no of out ports */

#define IN_PORT_RESET            0
#define IN_PORT_ENABLE           1
#define IN_PORT_DATA             2
#define OUT_PORT_SERIAL_OUT      0
#define OUT_PORT_FIFO_COUNT      1
#define OUT_PORT_ERROR           2

static char_T msg[256];

static void mdlInitializeSizes(SimStruct *S)
{
    int i;
    int datawidth;
    DTypeId id = SS_UINT32;
#ifdef          MATLAB_MEX_FILE
//    serialfifoptr fifozero;
#endif

    ssSetNumSFcnParams(S, NR_ARGS);
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        ssPrintf("Wrong number of input arguments passed.\n%d arguments are expected\n", NR_ARGS);
        ssSetErrorStatus(S,"Wrong number of input arguments passed.");
        return;
    }

    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

    // port 0 is the fifo data
#ifdef          MATLAB_MEX_FILE
    // First create the custom data type for a fifo pointer
    // The Register call defines the signal as a unique type for Simulink
    id = ssRegisterDataType( S, "serialfifoptr" );
    if(id == INVALID_DTYPE_ID)
        return;
    ssSetDataTypeSize(S, id, 12 );

    if( ssGetDataTypeZero( S, id ) == NULL )
    {
        serialfifoptr fifozero;
        fifozero.ptrlow = 0;
        fifozero.ptrhigh = 0;
        fifozero.token = 0;
        ssSetDataTypeZero( S, id, &fifozero );
    }
    // Neither of these functions can be called from the target side.
#endif

    if( !ssSetNumInputPorts(S, NR_IN_PORTS) )return;
    if( !ssSetNumOutputPorts(S, NR_OUT_PORTS) )return;

    //-------------------  PortNr,                 Width, Type,      Contiguous, DirectFF
    SetInputPortConfig( S, IN_PORT_RESET,   	       1, SS_BOOLEAN,  1, 1);
    SetInputPortConfig( S, IN_PORT_ENABLE,   	       1, SS_BOOLEAN,  1, 1);
    SetInputPortConfig( S, IN_PORT_DATA,               5, SS_DOUBLE,   1, 1);

    //--------------------  PortNr,                Width, Type
    SetOutputPortConfig( S, OUT_PORT_SERIAL_OUT,        1,     id);
    SetOutputPortConfig( S, OUT_PORT_FIFO_COUNT,        1,     SS_UINT32);
    SetOutputPortConfig( S, OUT_PORT_ERROR,             1,     SS_BOOLEAN);

    ssSetNumSampleTimes(S, 1);

    ssSetNumRWork(S, NR_R_WORKS );
    ssSetNumIWork(S, NR_I_WORKS );
    ssSetNumPWork(S, NR_P_WORKS );

    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);

    for( i = 0 ; i < NR_ARGS ; i++ )
    {
        ssSetSFcnParamTunable(S,i,0);  /* None of the parameters are tunable */
    }

    ssSetSimStateCompliance(S, DISALLOW_SIM_STATE);

    ssSetOptions(S, SS_OPTION_DISALLOW_CONSTANT_SAMPLE_TIME | SS_OPTION_EXCEPTION_FREE_CODE |
                    SS_OPTION_NONSTANDARD_PORT_WIDTHS );
}

static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetModelReferenceSampleTimeInheritanceRule(S, USE_DEFAULT_FOR_DISCRETE_INHERITANCE);
    ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, 0.0);
}

#ifdef MATLAB_MEX_FILE
#define MDL_SET_INPUT_PORT_WIDTH
static void mdlSetInputPortWidth( SimStruct *S, int_T port, int_T width )
{
    ssSetInputPortWidth( S, port, width );
}

#define MDL_SET_OUTPUT_PORT_WIDTH
static void mdlSetOutputPortWidth( SimStruct *S, int_T port, int_T width )
{
}
#endif

#define MDL_START
static void mdlStart(SimStruct *S)
{
    int i;
    int fifosize;
    serialfifoptr *OPtr = ssGetOutputPortSignal(S,OUT_PORT_SERIAL_OUT);
    int *fifomem;
//    int type = (int)mxGetPr( TYPE_ARG )[0];
//    int presenceflag = (int)(ssGetNumOutputPorts(S) > 1);
    void **pwork = ssGetPWork(S);

    fifosize = (int)mxGetPr( ARG_FIFO_SIZE )[0];

//    ssSetIWorkValue( S, IWIDTH_I_IND, ssGetInputPortWidth(S, 0));
    fifomem = (int *)malloc( 4*(fifosize + 3) );
    if( fifomem == 0 )
    {
        ssSetErrorStatus(S,"Can't allocate memory for fifo");
        return;
    }

    pwork[FIFO_P_IND]  = fifomem;

    // Clear the FIFO data
    for( i = 0 ; i < fifosize+3 ; i++ )
        fifomem[i] = 0;
    fifomem[0] = fifosize;  // Have to communicate this to fiforead

#ifdef _WIN64
    OPtr->ptrlow  = (uint32_T)( (uint64_T)fifomem & 0xffffffff );
    OPtr->ptrhigh = (uint32_T)( ((uint64_T)fifomem >> 32) & 0xffffffff );
#else
    OPtr->ptrlow  = (uint32_T)fifomem;
    OPtr->ptrhigh = 0;
#endif
    OPtr->token = (int)'FiFo';
}

static void mdlOutputs(SimStruct *S, int_T tid)
{
    void **pwork = ssGetPWork(S);
    int_T *Fifo  = pwork[FIFO_P_IND];

    serialfifoptr *OPtrFifo = ssGetOutputPortSignal(S,OUT_PORT_SERIAL_OUT);
    uint32_T     *OPtrCount = ssGetOutputPortSignal(S,OUT_PORT_FIFO_COUNT);
    boolean_T    *OPtrError = ssGetOutputPortSignal(S,OUT_PORT_ERROR);

    boolean_T *IPtrReset  = ssGetInputPortSignal(S,IN_PORT_RESET);
    boolean_T *IPtrEnable = ssGetInputPortSignal(S,IN_PORT_ENABLE);
    double *IPtrData = ssGetInputPortSignal(S,IN_PORT_DATA);
//    const char *err = NULL;
//     const char *err = fifowrite(pwork[0], pwork[1], &pwork[2],
//                                 ssGetIWork(S));
    /* Ignore the FIFO overflow error */
//    if (err != NULL && strncmp(err, "FIFO", 4) != 0) {
//        ssSetErrorStatus(S, err);
//    }

    int_T fifocount = 0;
    boolean_T fErr = true;
    if (Fifo != NULL)
    {
        fErr = false;
        if (IPtrReset[0])
        {
            Fifo[1] = 0;    // fiforptr
            Fifo[2] = 0;    // fifowptr
        }
        else if (IPtrEnable[0])
        {
            uint_T mtype    = (uint_T)floor(IPtrData[0]+0.5);
            int_T campixel  = (int_T)floor(IPtrData[1]+0.5);
            int_T linecount = (int_T)floor(IPtrData[2]+0.5);
            double pvalue   = IPtrData[3];
            uint_T status   = (uint_T)floor(IPtrData[4]+0.5);
            sprintf(msg, "%u %d %d %0.3f %d\r\n", mtype, campixel, linecount, pvalue, status );
            if (!StringToFifo( OPtrFifo, msg))
            {
                fErr = true;
            }
            time_T t = ssGetT(S);
            int_T fcnt = (Fifo[2] - Fifo[1] + Fifo[0]) % Fifo[0];
//            ssPrintf("VisionPcSim: %0.3f %4u %u %4d %5d %0.3f %d %d\r\n", t, fcnt, mtype, campixel, linecount, pvalue, status, fErr );
        }
        int_T fifosize = Fifo[0];
        int_T fiforptr = Fifo[1];
        int_T fifowptr = Fifo[2];
        fifocount = (fifowptr - fiforptr + fifosize) % fifosize;
    }

    OPtrCount[0] = fifocount;
    OPtrError[0] = fErr;
}

static void mdlTerminate(SimStruct *S)
{
    int_T *Fifo = (int_T *)ssGetPWorkValue( S, FIFO_P_IND );
    if( Fifo != 0 )
        free( Fifo );
}

// #define MDL_RTW
// static void mdlRTW(SimStruct *S) {
//     int lid = (int)mxGetN( ID_ARG ) + 1;
//     char *id;
//     id = malloc(lid);
//     mxGetString( ID_ARG, id, lid );
//     /* We write the settings values to the RTW file, and reconstruct the
//      * IOArgs based on the run time output and input values */
//     ssWriteRTWParamSettings(S, 2, SSWRITE_VALUE_DTYPE_VECT, "settings",
//                             ssGetIWork(S), ssGetNumIWork(S),
//                             DTINFO(SS_INT32, 0),
//                             SSWRITE_VALUE_QSTR, "id", id);
//     free(id);
// }

#ifdef MATLAB_MEX_FILE  /* Is this file being compiled as a MEX-file? */
#include "simulink.c"   /* Mex glue */
#else
#include "cg_sfun.h"    /* Code generation glue */
#endif
