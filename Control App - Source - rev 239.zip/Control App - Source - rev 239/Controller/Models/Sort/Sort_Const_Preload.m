%-------------------------------------------------------------------------
%Sort init
%-------------------------------------------------------------------------
Sort.Name = 'Sort'; %required! Has to be the same as object name.
Sort.Const.Model.Version.Major    = 1;  %maybe try to integrate SVN directory revision number here??
Sort.Const.Model.Version.Minor    = 0;
disp(sprintf('Sort Constants Preload. Version %d.%d', Sort.Const.Model.Version.Major, Sort.Const.Model.Version.Minor))

Sort.Const.UnitID = 3;

%-------------------------------------------------------------------------
% Sampletime
%-------------------------------------------------------------------------
Sort.Const.Ts      = Ts;    % Samplefrequency for CameraSorter

%-----------------------------------------------------------------------
% Mode Commands
%-----------------------------------------------------------------------
Sort.Const.Mlc.ModeCmd.NoCommand            = 0;
Sort.Const.Mlc.ModeCmd.Reset                = 1;
Sort.Const.Mlc.ModeCmd.ENABLE               = 30;   % Sort disabled
Sort.Const.Mlc.ModeCmd.DISABLE              = 31;   % Sort enabled
Sort.Const.Mlc.ModeCmd.SetSortParamsA       = 32;
Sort.Const.Mlc.ModeCmd.SetSortParamsB       = 33;
Sort.Const.Mlc.ModeCmd.SetSortParamsC       = 34;
Sort.Const.Mlc.ModeCmd.SetSortParamsD       = 35;
Sort.Const.Mlc.ModeCmd.SetSortParamsE       = 36;
Sort.Const.Mlc.ModeCmd.SetSortParamsF       = 37;

Sort.Const.Mlc.ModeCmd.SetSortDistanceLane1 = 101;
Sort.Const.Mlc.ModeCmd.SetSortDistanceLane2 = 102;
Sort.Const.Mlc.ModeCmd.SetSortDistanceLane3 = 103;
Sort.Const.Mlc.ModeCmd.SetSortDistanceLane4 = 104;
Sort.Const.Mlc.ModeCmd.SetSortDistanceLane5 = 105;
Sort.Const.Mlc.ModeCmd.SetSortDistanceLane6 = 106;
Sort.Const.Mlc.ModeCmd.SetSortDistanceLane7 = 107;
Sort.Const.Mlc.ModeCmd.SetSortDistanceLane8 = 108;

% Command to set parameters for 
Sort.Const.Mlc.ModeCmd.SetGateDisableParam  = 109;
Sort.Const.Mlc.ModeCmd.SetSort_CG           = 110;

%-----------------------------------------------------------------------
% Status Feedback
%-----------------------------------------------------------------------
Sort.Const.Mlc.Sts.NOK                 = 0;   % NOK. Not used?????
Sort.Const.Mlc.Sts.Disabled            = 1;   % Idle
Sort.Const.Mlc.Sts.Enabled             = 2;   % Sort

%-----------------------------------------------------------------------
% Module ErrorID's
%-----------------------------------------------------------------------
Sort.Const.Err.Base                         = Sort.Const.UnitID * 100;
Sort.Const.Err.NoError                      = 0;
Sort.Const.Err.NotAccepted                  = 1;
Sort.Const.Err.ParamOORange                 = 2;
Sort.Const.Err.EthercatError                = 3;
Sort.Const.Err.EL6002FifoWriteError         = 4;
Sort.Const.Err.Terminal_EL6002              = 5;
Sort.Const.Err.Terminal_EL9505              = 6;
Sort.Const.Err.Terminal_EL2024_1            = 7;
Sort.Const.Err.Terminal_EL2024_2            = 8;
Sort.Const.Err.Terminal_EL1018_1            = 9;
Sort.Const.Err.Terminal_EL1018_2            = 10;