% This file defines the error definitions for the _Sort subsystem
% Warning: !!!DO NOT EDIT!!! - this file is created automatically!
% Created: 29-Apr-2010 12:20:35

% Usage  : choose either of the following options
%   - Copy the following lines into Sort_Const_Preload.m
%   - Include this file into Sort_Const_Preload.m

% Command response Sort to Interpreter
Sort.Const.CmdRsp.rDone                   = 0;
Sort.Const.CmdRsp.rAborted                = 1;
Sort.Const.CmdRsp.rErrCmdNotAccepted      = 2;
Sort.Const.CmdRsp.rErrCmdInterrupted      = 3;
Sort.Const.CmdRsp.rErrCmdTimeout          = 4;
Sort.Const.CmdRsp.rErrEvent               = 5;

% Error bits on Sort rErrEvent
Sort.Const.ErrBits.eEthercatError         = 2^0;
Sort.Const.ErrBits.ePdoSimActive          = 2^1;
Sort.Const.ErrBits.eAmp                   = 2^2;
Sort.Const.ErrBits.eAmpOnTmo              = 2^3;
Sort.Const.ErrBits.eHomeTmo               = 2^4;
Sort.Const.ErrBits.eI2t                   = 2^5;
Sort.Const.ErrBits.eTrack                 = 2^6;
Sort.Const.ErrBits.eVacOnTmo              = 2^7;
Sort.Const.ErrBits.ePrsOnTmo              = 2^8;
Sort.Const.ErrBits.eVacOffTmo             = 2^9;
Sort.Const.ErrBits.ePrsOffTmo             = 2^10;
Sort.Const.ErrBits.eSettleTmo             = 2^11;

