function seeddata = CreateSeedData(count,varargin)
   defaultNumLanes = 8;             % Number of lanes
   defaultLaneWidth = 500;          % Width of single lane [campixels]
   defaultCamWidth = 4096;          % Total image width [campixels]
   defaultPixelSize = 13.4e-6;      % Pixelsize (X and Y, square) [m]
   defaultFirstSeedDistance = 0.2;  % Distance of first seed detected [m]
   defaultDblSeedDistance = 0.002;  % Distance of seed detected as double [m]
   defaultMinSeedDistance = 0.0002; % Minimum distance*) between seeds [m], must be > 2*Ts*BeltSpeed
   defaultMaxSeedDistance = 0.01;   % Maximum distance*) between seeds [m]
   defaultShuffleDistance = 0.05;   % Distance in which sorted order is shuffled [m]
   defaultSeedSpreadW = 50;         % Uniform distribution of seed [campixels]
   defaultSeedSpreadL = 50;         % Uniform distribution of seed [linecounts]
   defaultStatusFailRate = 0.1;     % Percentile of "vision analysis failed"
   % *) Note: Distances are for all lanes together; the average distance on a single
   % lane is hence <defaultNumLanes> times larger; the maximum distance on a
   % single lane is not limited (or limited by the statistics)
   %
   % Uniform distribution is full range value, ditributed -50%..+50%
   
   % seeddata has 7 columns:
   % column 1..5: <messagetype> <campixel> <linecount> <p> <status>
   %              See Vision PC SIS document
   % column 6:    The seed lane number (1..<defaultNumLanes>)
   % column 7:    Again <linecount> but with the uniform distribution
   
   p = inputParser;
   validScalarNum = @(x) isnumeric(x) && isscalar(x);
   validScalarPosNum = @(x) isnumeric(x) && isscalar(x) && (x > 0);
   validScalarPosInt = @(x) isinteger(x) && isscalar(x) && (x > 0);
   addRequired(p,'count',validScalarPosNum);
   addOptional(p,'seed',1,validScalarPosNum);
   addParameter(p,'numlanes',defaultNumLanes,validScalarPosInt);
   addParameter(p,'lanewidth',defaultLaneWidth,validScalarPosInt);
   addParameter(p,'camwidth',defaultCamWidth,validScalarPosInt);
   addParameter(p,'pixelsize',defaultPixelSize,validScalarPosNum);
   addParameter(p,'firstseeddistance',defaultFirstSeedDistance,validScalarNum);
   addParameter(p,'dblseeddistance',defaultDblSeedDistance,validScalarNum);
   addParameter(p,'minseeddistance',defaultMinSeedDistance,validScalarNum);
   addParameter(p,'maxseeddistance',defaultMaxSeedDistance,validScalarPosNum);
   addParameter(p,'shuffledistance',defaultShuffleDistance,validScalarNum);
   addParameter(p,'seedspreadw',defaultSeedSpreadW,validScalarNum);
   addParameter(p,'seedspreadl',defaultSeedSpreadL,validScalarNum);
   addParameter(p,'statusfailrate',defaultStatusFailRate,validScalarNum);

   parse(p,count,varargin{:});
   
   fprintf('Count       = %i\n', p.Results.count)
   fprintf('Seed        = %i\n', p.Results.seed)
   fprintf('NumLanes    = %i\n', p.Results.numlanes)
   fprintf('LaneWidth   = %i\n', p.Results.lanewidth)
   fprintf('CamWidth    = %i\n', p.Results.camwidth)
   fprintf('SeedSpreadW = %0.1f\n', p.Results.seedspreadw)
   fprintf('SeedSpreadL = %0.1f\n', p.Results.seedspreadl)
   fprintf('PixelSize   = %0.6f\n', p.Results.pixelsize)
   fprintf('FirstSeedDistance = %0.6f\n', p.Results.firstseeddistance)
   fprintf('DblSeedDistance = %0.6f\n', p.Results.dblseeddistance)
   fprintf('MinSeedDistance = %0.6f\n', p.Results.minseeddistance)
   fprintf('MaxSeedDistance = %0.6f\n', p.Results.maxseeddistance)
   fprintf('ShuffleDistance = %0.6f\n', p.Results.shuffledistance)
   fprintf('StatusFailRate  = %0.3f\n', p.Results.statusfailrate)
   
   lc = p.Results.firstseeddistance / p.Results.pixelsize;
   count = p.Results.count;
   lanepos = floor((p.Results.camwidth-p.Results.lanewidth*(p.Results.numlanes-1))/2);
   rng(p.Results.seed);
   tempdata = zeros(count, 8);
   for i=1:count
       lanenr = randi(p.Results.numlanes);
       % camerapixel
       cp = round(lanepos + (lanenr-1)*p.Results.lanewidth + (rand()-0.5)*p.Results.seedspreadw);
       % linedistance
       ld = rand()*(p.Results.maxseeddistance - p.Results.minseeddistance) + p.Results.minseeddistance;
       % linecount
       lc = lc + round(ld/p.Results.pixelsize);
       % linecount + random jitter
       lcr = max(0, lc + round((rand()-0.5)*p.Results.seedspreadl));
       if (rand() > p.Results.statusfailrate)
           % p-value
           pv1 = rand();    % p-value for vision PC simulator (generated data)
           pv2 = pv1;       % p-value for validator (modified for double and undetectable seeds)
           st = 0;
       else
           pv1 = 0;
           pv2 = 1;
           st = 2;
       end
       seedidx_dbl = (lc - tempdata(:,3)) < p.Results.dblseeddistance/p.Results.pixelsize ...
           & tempdata(:,7) == lanenr;
       if any(seedidx_dbl)
           pv2 = max(pv2, max(tempdata(seedidx_dbl,6)));
           tempdata(seedidx_dbl, 6) = pv2;
           st = max(1,st); % if st=0 then st=1
           seedidx_ok = tempdata(:,5) == 0 & seedidx_dbl;
           tempdata(seedidx_ok, 5) = 1;
       end
       temprow = [1 cp lc pv1 st pv2 lanenr lcr];
       tempdata(i,:) = temprow;
   end
   
   shuffledist = p.Results.shuffledistance/p.Results.pixelsize;
   seeddata = zeros(count+2, 8);
   seeddata(1,:) = [2 -1 0 0 0 0 0 0];
   for i=1:count
       ki = (tempdata(:,3) - tempdata(1,3)) <= shuffledist;
       cki = sum(ki);
       pki = randi(cki);
       seeddata(i+1,:) = tempdata(pki,:);
       tempdata(pki,:) = [];
   end
   seeddata(count+2,:) = [0 0 0 0 0 0 0 2^30];    % Stop: TriggerCount will never exceed this linenr
end
