%---------------------------------------------------------------------------------------------------------------
% CCM, Center for Concepts in Mechatronics
%---------------------------------------------------------------------------------------------------------------
% Sorter
%
% Initializes tuning parameters
%
%---------------------------------------------------------------------------------------------------------------

disp(sprintf('Sort Tuning Preload --> Demonstrator'))


%-----------------------------------------------------------------------
% Tuning parameters
%-----------------------------------------------------------------------

% Rotation unit, SI units in rad, rad/s, rad/s^2 etc.
CamToGate_Offset_mm               = 159;
GateToNozzle_Offset_mm            = 99;

Sort.Tun.Gate_Debounce            = 3;

CamLanes_Pitch = 500;
CamLanes_Width = 500;
CamLanes_First = 48+250;

% Demonstrator III --> WeldDetect_2 sensor is removed. Generate "gate
% disable" based on WeldDetect_1 sensor
Sort.Tun.GateDisable_to_WeldDistance_mm = 700;
Sort.Tun.GateDisable_Length_mm          = 80;

Sort.Tun.BeltLength_mm            = CamToGate_Offset_mm - 20;  % Needed!!
Sort.Tun.TriggerDistance_mm       = 0.014;   
Sort.Tun.PValueThreshold          = 0.6;       
Sort.Tun.GateWindow_mm            = 6.00;           % now is [mm]
Sort.Tun.FireWindow_mm            = 6.00;           % now is [mm]
Sort.Tun.FireWindowShift_mm       = -1.80;          % shift of firewindow [mm]

% MHAJ 03-OCT-2016
% Sort using the CG data from the vision
% instead of the front seed data from the sensor array
Sort.Tun.Sort_CG                  = 1;

% Distances camera to gate & 1 nozzle
% Camera to Gate 1
Sort.Tun.Lane1.Start              =  CamLanes_First + 0*CamLanes_Pitch - CamLanes_Width/2;
Sort.Tun.Lane1.Stop               =  CamLanes_First + 0*CamLanes_Pitch + CamLanes_Width/2;
Sort.Tun.Lane1.CamToGate_mm       =  CamToGate_Offset_mm + 0;
Sort.Tun.Lane1.GateToNozzle_mm    =  GateToNozzle_Offset_mm + 3*22;

% Camera to Gate 2
Sort.Tun.Lane2.Start              =  CamLanes_First + 1*CamLanes_Pitch - CamLanes_Width/2;   
Sort.Tun.Lane2.Stop               =  CamLanes_First + 1*CamLanes_Pitch + CamLanes_Width/2;   
Sort.Tun.Lane2.CamToGate_mm       =  CamToGate_Offset_mm + 0;
Sort.Tun.Lane2.GateToNozzle_mm    =  GateToNozzle_Offset_mm + 2*22;

% Camera to Gate 3
Sort.Tun.Lane3.Start              =  CamLanes_First + 2*CamLanes_Pitch - CamLanes_Width/2;   
Sort.Tun.Lane3.Stop               =  CamLanes_First + 2*CamLanes_Pitch + CamLanes_Width/2;   
Sort.Tun.Lane3.CamToGate_mm       =  CamToGate_Offset_mm + 0;
Sort.Tun.Lane3.GateToNozzle_mm    =  GateToNozzle_Offset_mm + 1*22;

% Camera to Gate 4
Sort.Tun.Lane4.Start              =  CamLanes_First + 3*CamLanes_Pitch - CamLanes_Width/2;   
Sort.Tun.Lane4.Stop               =  CamLanes_First + 3*CamLanes_Pitch + CamLanes_Width/2;   
Sort.Tun.Lane4.CamToGate_mm       =  CamToGate_Offset_mm + 0;
Sort.Tun.Lane4.GateToNozzle_mm    =  GateToNozzle_Offset_mm + 0*22;

% Camera to Gate 5
Sort.Tun.Lane5.Start              =  CamLanes_First + 4*CamLanes_Pitch - CamLanes_Width/2;   
Sort.Tun.Lane5.Stop               =  CamLanes_First + 4*CamLanes_Pitch + CamLanes_Width/2;   
Sort.Tun.Lane5.CamToGate_mm       =  CamToGate_Offset_mm + 0;
Sort.Tun.Lane5.GateToNozzle_mm    =  GateToNozzle_Offset_mm + 3*22;

% Camera to Gate 6
Sort.Tun.Lane6.Start              =  CamLanes_First + 5*CamLanes_Pitch - CamLanes_Width/2;   
Sort.Tun.Lane6.Stop               =  CamLanes_First + 5*CamLanes_Pitch + CamLanes_Width/2;   
Sort.Tun.Lane6.CamToGate_mm       =  CamToGate_Offset_mm + 0;
Sort.Tun.Lane6.GateToNozzle_mm    =  GateToNozzle_Offset_mm + 2*22;

% Camera to Gate 7
Sort.Tun.Lane7.Start              =  CamLanes_First + 6*CamLanes_Pitch - CamLanes_Width/2;   
Sort.Tun.Lane7.Stop               =  CamLanes_First + 6*CamLanes_Pitch + CamLanes_Width/2;   
Sort.Tun.Lane7.CamToGate_mm       =  CamToGate_Offset_mm + 0;
Sort.Tun.Lane7.GateToNozzle_mm    =  GateToNozzle_Offset_mm + 1*22;

% Camera to Gate 8
Sort.Tun.Lane8.Start              =  CamLanes_First + 7*CamLanes_Pitch - CamLanes_Width/2;   
Sort.Tun.Lane8.Stop               =  CamLanes_First + 7*CamLanes_Pitch + CamLanes_Width/2;   
Sort.Tun.Lane8.CamToGate_mm       =  CamToGate_Offset_mm + 0;                
Sort.Tun.Lane8.GateToNozzle_mm    =  GateToNozzle_Offset_mm + 0*22;
