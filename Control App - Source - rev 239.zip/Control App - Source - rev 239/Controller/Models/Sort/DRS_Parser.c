/* $Revision: 1.0$ $Date: 2010/04/26 09:29:30 $ */
/* DRS_Parser De Ruiter Seeds Parse module between Vision communication and Sorter modules
*/

#define         S_FUNCTION_LEVEL        2
#undef          S_FUNCTION_NAME
#define         S_FUNCTION_NAME         DRS_Parser

#define DEBUG

#include        <stddef.h>
#include        <stdlib.h>
#include        <stdio.h>
#include        "simstruc.h"
#include        "Cmd_Routines.h"

#ifdef          MATLAB_MEX_FILE
#include        "mex.h"
#endif

#ifndef         MATLAB_MEX_FILE
//#include        <windows.h>
#endif

   
//----------------------------------------
// -- BEGIN --
// Copy here the in/output definition to the C testprogram
// -- BEGIN --
//----------------------------------------

//-- Define In and Outputs
#define NR_IN_PORTS                 3
#define IN_PORT_SERIAL_IN           0
#define IN_PORT_LANE_DEFINITION     1
#define IN_PORT_PARSERENABLE		2	

#define NR_OUT_PORTS                13
#define OUT_PORT_TRIGGERCOUNT       0
#define OUT_PORT_PVALUE             1
#define OUT_PORT_STATUS        		2
#define OUT_PORT_VALID1				3
#define OUT_PORT_VALID2				4
#define OUT_PORT_VALID3				5
#define OUT_PORT_VALID4				6
#define OUT_PORT_VALID5				7
#define OUT_PORT_VALID6				8
#define OUT_PORT_VALID7				9
#define OUT_PORT_VALID8				10
#define OUT_PORT_DEBUG				11
#define OUT_PORT_MESSAGE_SIZE       12

//-- Parameters section
#define NUMBER_OF_ARGS          (0)

#define SAMPLE_TIME_0        INHERITED_SAMPLE_TIME

//-- Local variables
#define NO_R_WORKS              (0)
#define NO_I_WORKS              (0)


#define MAXMSGLENGTH			50	/* Current msg length is 25. */

static unsigned char TerminatorRecvBuf[10]; 

//----------------------------------------
// -- END --
// Copy here the in/output definition to the C testprogram
// -- END --
//----------------------------------------

void ClearValidSignals(SimStruct *S);
int_T PixelToLane(int_T Pixel, int_T *LaneDefinition);

static bool CheckCommErr( serialfifoptr* IPtr );
static void ClearBuffer( serialfifoptr* IPtr );
static int  strPos( serialfifoptr* IPtr, const unsigned char* pBuf, int iOffset );

static void mdlInitializeSizes(SimStruct *S)
{
    int i = 0;
    int maxwidth = 0;
    DTypeId id = SS_UINT32;

    ssSetNumSFcnParams(S, NUMBER_OF_ARGS);
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        ssPrintf("Wrong number of input arguments passed.\n%d arguments are expected\n",NUMBER_OF_ARGS);
        ssSetErrorStatus(S,"Wrong number of input arguments passed.");
        return;
    }
    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

    //-- Initialize input port
    ssSetNumInputPorts(S, NR_IN_PORTS);

    // port 0 is the fifo data received from a RS232_F block.

#ifdef          MATLAB_MEX_FILE
    // First create the custom data type for a fifo pointer
    // The Register call defines the signal as a unique type for Simulink
	id = ssRegisterDataType( S, "serialfifoptr" );
    if(id == INVALID_DTYPE_ID)
        return;
    ssSetDataTypeSize(S, id, 12 );
    if( ssGetDataTypeZero( S, id ) == NULL )
    {
        serialfifoptr fifozero;
        
        fifozero.ptrlow = 0;
        fifozero.ptrhigh = 0;
        fifozero.token = 0;
        ssSetDataTypeZero( S, id, &fifozero );
    }
    // Neither of these functions can be called from the target side.
#endif


    //-------------------  PortNr,                 Width, Type,      Contiguous, DirectFF
    SetInputPortConfig( S, IN_PORT_SERIAL_IN, 		1,     id,         1,          1);
    SetInputPortConfig( S, IN_PORT_LANE_DEFINITION, 16,    SS_UINT32,  1,          1);
    SetInputPortConfig( S, IN_PORT_PARSERENABLE,	1,     SS_BOOLEAN, 1,          1);

    //-- Initialize output ports
    ssSetNumOutputPorts(S, NR_OUT_PORTS);

    //--------------------  PortNr,                Width, Type
    SetOutputPortConfig( S, OUT_PORT_TRIGGERCOUNT,	1,     SS_UINT32);
    SetOutputPortConfig( S, OUT_PORT_PVALUE,       	1,     SS_DOUBLE);
    SetOutputPortConfig( S, OUT_PORT_STATUS,   		1,     SS_UINT32);
    SetOutputPortConfig( S, OUT_PORT_VALID1,   		1,     SS_BOOLEAN);
    SetOutputPortConfig( S, OUT_PORT_VALID2,   		1,     SS_BOOLEAN);
    SetOutputPortConfig( S, OUT_PORT_VALID3,   		1,     SS_BOOLEAN);
    SetOutputPortConfig( S, OUT_PORT_VALID4,   		1,     SS_BOOLEAN);
    SetOutputPortConfig( S, OUT_PORT_VALID5,   		1,     SS_BOOLEAN);
    SetOutputPortConfig( S, OUT_PORT_VALID6,   		1,     SS_BOOLEAN);
    SetOutputPortConfig( S, OUT_PORT_VALID7,   		1,     SS_BOOLEAN);
    SetOutputPortConfig( S, OUT_PORT_VALID8,   		1,     SS_BOOLEAN);
    SetOutputPortConfig( S, OUT_PORT_DEBUG,   		1,     SS_DOUBLE);
    SetOutputPortConfig( S, OUT_PORT_MESSAGE_SIZE,	1,     SS_DOUBLE);

    ssSetNumSampleTimes(S, 1);

    ssSetNumRWork(S, NO_R_WORKS);
    ssSetNumIWork(S, NO_I_WORKS);
    ssSetNumPWork(S, 0);

    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);

    for( i = 0 ; i < NUMBER_OF_ARGS ; i++ )
    {
        ssSetSFcnParamTunable(S,i,0);  /* None of the parameters are tunable */
    }

    ssSetOptions(S, SS_OPTION_EXCEPTION_FREE_CODE |
                    SS_OPTION_NONSTANDARD_PORT_WIDTHS ); // |
}

static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTime(S, 0, SAMPLE_TIME_0);
    ssSetOffsetTime(S, 0, 0.0);
}

//----------------------------------------
// -- BEGIN --
// Copy here the S-Function code to the C testprogram
// -- BEGIN --
//----------------------------------------

#define MDL_START
static void mdlStart(SimStruct *S)
{
		TerminatorRecvBuf[0] = (unsigned char) '\r';
		TerminatorRecvBuf[1] = (unsigned char) '\n';
// 		TerminatorRecvBuf[2] = (unsigned char) '\0';
}

static void mdlOutputs(SimStruct *S, int_T tid)
{
	// retrieve the serial data from the inputport
    serialfifoptr *IPtr = (serialfifoptr *)ssGetInputPortSignal(S,0);

	// retrieve the lane definition from the inputport
    int_T  *I_LaneDefinition  = (int_T*) ssGetInputPortSignal(S,IN_PORT_LANE_DEFINITION);

	// retrieve the enable signal
	boolean_T  *I_ParseEnable  = (boolean_T*) ssGetInputPortSignal(S,IN_PORT_PARSERENABLE);

	// retrieve pointers to output ports
    uint32_T         *O_TriggerCount= (uint32_T *)ssGetOutputPortRealSignal(S,OUT_PORT_TRIGGERCOUNT);
    real_T           *O_PValue		= (real_T *)ssGetOutputPortRealSignal(S,OUT_PORT_PVALUE);
    int_T            *O_Status		= (int_T *)ssGetOutputPortRealSignal(S,OUT_PORT_STATUS);
    boolean_T        *O_Valid1		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID1);
    boolean_T        *O_Valid2		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID2);
    boolean_T        *O_Valid3		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID3);
    boolean_T        *O_Valid4		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID4);
    boolean_T        *O_Valid5		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID5);
    boolean_T        *O_Valid6		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID6);
    boolean_T        *O_Valid7		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID7);
    boolean_T        *O_Valid8		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID8);
    real_T           *O_Debug		= (real_T *)ssGetOutputPortRealSignal(S,OUT_PORT_DEBUG);
    real_T           *O_Message_Size= (real_T *)ssGetOutputPortRealSignal(S,OUT_PORT_MESSAGE_SIZE);

	// local helper variables
    unsigned char msgReceivedBuf[MAXMSGLENGTH];
    int_T iDelimPos = 0;
    int_T iScanned = 0;
    int_T fifocount = 0;
    unsigned long i=0;

	// message data
    int_T 		msgType = 0;
    int_T 		msgCamPixel = 0;
    uint32_T 	msgLineCount = 0;
    real_T 		msgPValue = 0;
    int_T 		msgStatus = 0;
    
    *O_Message_Size =  -1;

	// by default set no valid signal on the out ports
	ClearValidSignals(S);

	// check if a rs232-Fifo block is connected to our inport
    if( IPtr == 0 ) {
        ssSetErrorStatus(S, "No Fifo connected: NULL ptr (DRS_Parser.c)");
        return;  // Do nothing
    }
    if( IPtr->token != FiFoID )
    {
        ssSetErrorStatus(S, "No Fifo connected: FiFoID wrong (DRS_Parser.c)");
        return; // Do nothing
    }


#ifdef _WIN64
    int_T *Fifo = (int_T *)( (uint64_T)IPtr->ptrlow | ((uint64_T)IPtr->ptrhigh << 32));
#else
    int_T *Fifo = (int_T *)IPtr->ptrlow;
#endif
    int_T fifosize = Fifo[0];
    int_T *rptr = &Fifo[1];
    int_T *wptr = &Fifo[2];
    int_T *data = &Fifo[3];
    
    //----------------------------------------
	// reset the rs232 buffer if we have a disabled signal
    //----------------------------------------
	if (*I_ParseEnable == false)
	{
		*rptr = *wptr;
        *O_TriggerCount = 0;
		return;
	}
	// how many characters are there in the buffer
    fifocount = *wptr - *rptr;
    if( fifocount < 0 )
        fifocount += fifosize;

 //-- Check if there are any RS232 errors (parity, etc...)
	if (CheckCommErr(IPtr))
    {
		ClearBuffer( IPtr );
        ssWarning(S, "RS232 error detected. (DRS_Parser.c)");
    } 
    else
    {
        if ((iDelimPos = strPos( IPtr, TerminatorRecvBuf, 0 )) != -1)       // Delimter found in data. Start processing.
        {   
			if (iDelimPos == 0)
			{	// only received a delimiter without data, just skip it.
				// skip the message terminator in the receive buffer
                ssWarning(S, "Received delimeter without data. (DRS_Parser.c)");
				for (i=0; i< strlen((const char *)TerminatorRecvBuf); i++)
				{
					*rptr = (*rptr + 1)%fifosize;
				}
			} 
            else
			{
				//-- We received a complete answer without rs232 faults
				// copy it to the message buffer
				i = 0; // used as index in the msgReceivedBuf buffer
				while (iDelimPos > 0)
				{
					msgReceivedBuf[i++]=data[*rptr];
					*rptr = (*rptr + 1)%fifosize;
					iDelimPos--;
				}

				// terminate the message
				msgReceivedBuf[i] = '\0';
                *O_Message_Size   = i;
                
				// skip the message terminator in the receive buffer
				for (i=0; i<(int)strlen((const char *)TerminatorRecvBuf); i++)
				{
					*rptr = (*rptr + 1)%fifosize;
				}
                
                // Now the *rptr should be at the end of the message data.
                
                //-- Parse the received message
                iScanned = sscanf((const char *)msgReceivedBuf, "%d %d %lu %lf %d", &msgType, &msgCamPixel, &msgLineCount, &msgPValue, &msgStatus);
                
                // only process message type 1 commands
                if (msgType == 1)
                {
                    // calculate lane
                    int iLaneNr = PixelToLane(msgCamPixel, (int *)I_LaneDefinition);
                    time_T t = ssGetT(S);
                    switch(iLaneNr)
                    {
                    case 1:
                        *O_Valid1 = true;
                        break;
                    case 2:
                        *O_Valid2 = true;
                        break;
                    case 3:
                        *O_Valid3 = true;
                        break;
                    case 4:
                        *O_Valid4 = true;
                        break;
                    case 5:
                        *O_Valid5 = true;
                        break;
                    case 6:
                        *O_Valid6 = true;
                        break;
                    case 7:
                        *O_Valid7 = true;
                        break;
                    case 8:
                        *O_Valid8 = true;
                        break;
                    }
                    
                    *O_TriggerCount = msgLineCount;
                    *O_PValue = msgPValue;
                    *O_Status = msgStatus;
                    
                    *O_Debug = *O_Debug + 1;
                }
            }
        }
        else
        {
            // wait another update to see get more data and wait for delimiter
        }
    }   

    return;

// For some unknown reason code below was not working. 
/*    
        //-- Received some rs232 data with no errors, check if it is complete
        //-- Check on delimiter
        if ((iDelimPos = strPos( IPtr, TerminatorRecvBuf, 0 )) != -1)
        {
            *O_Debug = 1;

			if (iDelimPos == 0)
			{	// only received a delimiter without data, just skip it.
				// skip the message terminator in the receive buffer
				for (i=0; i< strlen((const char *)TerminatorRecvBuf); i++)
				{
					*rptr = (*rptr + 1)%fifosize;
				}
			} else
			{
				//-- We received a complete answer without rs232 faults
				// copy it to the message buffer
				i = 0; // used as index in the msgReceivedBuf buffer
				while (iDelimPos > 0)
				{
					msgReceivedBuf[i++]=data[*rptr];
					*rptr = (*rptr + 1)%fifosize;
					iDelimPos--;
				}

				// terminate the message
				msgReceivedBuf[i] = '\0';
				// skip the message terminator in the receive buffer
				for (i=0; i<(int)strlen((const char *)TerminatorRecvBuf); i++)
				{
					*rptr = (*rptr + 1)%fifosize;
				}
				
	#ifdef DEBUG
//					sprintf_s(msg,MSGLEN,"Recv=%s\r\n", msgReceivedBuf);
//					DbgPrintf(S,msg);
	#endif
                        
                //-- Parse the received message
                iScanned = sscanf_s((const char *)msgReceivedBuf, "%d %d %lu %lf %d",&msgType, &msgCamPixel, &msgLineCount, &msgPValue, &msgStatus);
				if (iScanned == 5) // process only if completely scanned
				{
					// only process message type 1 commands
					if (msgType == 1)
					{
						// calculate lane
						switch(PixelToLane(msgCamPixel, (int *)I_LaneDefinition))
						{
						case 1:
							*O_Valid1 = true;
							break;
						case 2:
							*O_Valid2 = true;
							break;
						case 3:
							*O_Valid3 = true;
							break;
						case 4:
							*O_Valid4 = true;
							break;
						case 5:
							*O_Valid5 = true;
							break;
						case 6:
							*O_Valid6 = true;
							break;
						case 7:
							*O_Valid7 = true;
							break;
						case 8:
							*O_Valid8 = true;
							break;
						}
#ifdef DEBUG
//        				sprintf_s(msg,MSGLEN,"LaneNr=%d,C=%lu,P=%lf,S=%d\r\n", PixelToLane(msgCamPixel, I_LaneDefinition), msgLineCount, msgPValue, msgStatus);
//                		DbgPrintf(S,msg);
#endif

						*O_TriggerCount = msgLineCount;
						*O_PValue = msgPValue;
						*O_Status = msgStatus;

					}
				}
            }
        }
    }
    */
}


#undef MDL_UPDATE  /* Change to #undef to remove function */
#if defined(MDL_UPDATE)
  /* Function: mdlUpdate ======================================================
   * Abstract:
   *    This function is called once for every major integration time step.
   *    Discrete states are typically updated here, but this function is useful
   *    for performing any tasks that should only take place once per
   *    integration step.
   */
  static void mdlUpdate(SimStruct *S, int_T tid)
  {
  }
#endif /* MDL_UPDATE */

static bool CheckCommErr( serialfifoptr* IPtr )
{
#ifdef _WIN64
    int_T *Fifo = (int_T *)( (uint64_T)IPtr->ptrlow | ((uint64_T)IPtr->ptrhigh << 32));
#else
    int_T *Fifo = (int_T *)IPtr->ptrlow;
#endif

    int_T *rptr = &Fifo[1];
    int_T *wptr = &Fifo[2];
    int_T *data = &Fifo[3];
    int_T fifosize = Fifo[0];
    int fifocount = 0;
    int iIndex = 0;

    bool fFault = false;

    fifocount = *wptr - *rptr;
    if( fifocount < 0 )
    {
        fifocount += fifosize;
    }
    for( iIndex = 0 ; !fFault && iIndex < fifocount ; iIndex++ )
    {
        int loc = (*rptr + iIndex);
        if( loc >= fifosize )
            loc -= fifosize;

        // The following is only useful for the RS232 read system!
        if( (data[loc] & 0xff00) != 0) // error byte is set
        {
            fFault = true;
        }
    }
    return fFault;
}

static void ClearBuffer( serialfifoptr* IPtr )
{
#ifdef _WIN64
    int_T *Fifo = (int_T *)( (uint64_T)IPtr->ptrlow | ((uint64_T)IPtr->ptrhigh << 32));
#else
    int_T *Fifo = (int_T *)IPtr->ptrlow;
#endif
    int_T *rptr = &Fifo[1];
    int_T *wptr = &Fifo[2];

    *rptr = *wptr;
}


//--
//-- Search pBuf string (null terminated) in IPtr fifo.
//-- return -1 = not found. Otherwise index of position found
//--
static int strPos( serialfifoptr* IPtr, const unsigned char* pBuf, int iOffset )
{
#ifdef _WIN64
    int_T *Fifo = (int_T *)( (uint64_T)IPtr->ptrlow | ((uint64_T)IPtr->ptrhigh << 32));
#else
    int_T *Fifo = (int_T *)IPtr->ptrlow;
#endif
    int_T *rptr = &Fifo[1];
    int_T *wptr = &Fifo[2];
    int_T *data = &Fifo[3];
    int_T fifosize = Fifo[0];
    int fifocount = 0;

    int_T iBufSize = strlen((const char *)pBuf);

    bool  fFound = false;
    int   iFoundPos = 0;

    fifocount = *wptr - *rptr;
    if( fifocount < 0 )
    {
        fifocount += fifosize;
    }

    //-- Search algorithm
    for( iFoundPos = iOffset ; !fFound &&
                               iFoundPos <= (fifocount - iBufSize) ; iFoundPos++ )
    {
        bool fPartFound = true;
        int iIndex = 0;

        for (iIndex=0; fPartFound && iIndex < iBufSize; iIndex++)
        {
            int loc = (*rptr + iFoundPos + iIndex);
            if( loc >= fifosize )
                loc -= fifosize;
            // since data in the fifo is always a 32 bit int, we don't have
            // to use the output data types here.

            if( (data[loc] & 0xff) != pBuf[iIndex] )
            {
                fPartFound = false;
            }
            // The following is only useful for the RS232 read system!
            if( (data[loc] & 0xff00) != 0) // error byte is set
            {
                fPartFound = false;
            }
        }
        fFound = fPartFound;
    }
    iFoundPos--; //-- Because the for-loop incremented it also when
                 //-- stopcriteria was reached.

    if (fFound)
    {
        return iFoundPos;
    }
    return -1;
}

static void mdlTerminate(SimStruct *S)
{
}

static void ClearValidSignals(SimStruct *S)
{
    boolean_T        *O_Valid1		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID1);
    boolean_T        *O_Valid2		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID2);
    boolean_T        *O_Valid3		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID3);
    boolean_T        *O_Valid4		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID4);
    boolean_T        *O_Valid5		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID5);
    boolean_T        *O_Valid6		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID6);
    boolean_T        *O_Valid7		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID7);
    boolean_T        *O_Valid8		= (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_VALID8);
	
	*O_Valid1 = false;
	*O_Valid2 = false;
	*O_Valid3 = false;
	*O_Valid4 = false;
	*O_Valid5 = false;
	*O_Valid6 = false;
	*O_Valid7 = false;
	*O_Valid8 = false;
}

static int_T PixelToLane(int_T Pixel, int_T *LaneDefinition)
{
    int_T i = 0;
    int_T LaneNr = 0;
    
    for (i=0; i<8 && LaneNr == 0; i++)
    {
        if ( Pixel >= LaneDefinition[i*2] && Pixel <= LaneDefinition[(i*2)+1] )
        {
            LaneNr = i + 1;
        }
    }
    return LaneNr;
}
//----------------------------------------
// -- END --
// Copy here the S-Function code to the C testprogram
// -- END --
//----------------------------------------

#ifdef MATLAB_MEX_FILE  /* Is this file being compiled as a MEX-file? */
#include "simulink.c"   /* Mex glue */
#else
#include "cg_sfun.h"    /* Code generation glue */
#endif
