/* EL6002_fiforead.c - non-inlined S-function to perform the write
 * side of an EL6002 terminal */

#define         S_FUNCTION_LEVEL        2
#undef          S_FUNCTION_NAME
#define         S_FUNCTION_NAME         EL6002_fiforead_ToLabview

#include        <stddef.h>
#include        <stdlib.h>
#include        "simstruc.h"
#include        "Cmd_Routines.h"

#ifdef          MATLAB_MEX_FILE
#include        "mex.h"
#endif

#ifndef         MATLAB_MEX_FILE
//#include        <windows.h>
#endif

/* Input Arguments */
#define NR_ARGS                 (1)
#define ARG_DATA_WIDTH          ssGetSFcnParam(S,0)

#define CTR_BYTES_READ          (0)

#define NR_I_WORKS              (1)
#define NR_P_WORKS              (0)
#define NR_R_WORKS              (0)

#define NR_IN_PORTS             (2)     /* max no of ports */
#define NR_OUT_PORTS            (2)     /* max no of ports */

#define IN_PORT_SERIAL_IN        0
#define IN_PORT_HOLD             1
#define OUT_PORT_COUNT           0
#define OUT_PORT_DATA            1

//void fiforead(const void *iPorts[], void *oPorts[], int *settings);

static char_T msg[256];

static void mdlInitializeSizes(SimStruct *S)
{
    int i;
    int datawidth;

    DTypeId id = SS_UINT32;

    ssSetNumSFcnParams(S, NR_ARGS);
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        ssPrintf("Wrong number of input arguments passed.\n%d arguments are expected\n", NR_ARGS);
        ssSetErrorStatus(S,"Wrong number of input arguments passed.");
        return;
    }
    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

    datawidth = (int)mxGetPr( ARG_DATA_WIDTH )[0];
    
    // port 0 is the fifo data
#ifdef          MATLAB_MEX_FILE
    // First create the custom data type for a fifo pointer
    // The Register call defines the signal as a unique type for Simulink
    id = ssRegisterDataType( S, "serialfifoptr" );
    if(id == INVALID_DTYPE_ID)
        return;
    ssSetDataTypeSize(S, id, 12 );
    if( ssGetDataTypeZero( S, id ) == NULL )
    {
        serialfifoptr fifozero;

        fifozero.ptrlow = 0;
        fifozero.ptrhigh = 0;
        fifozero.token = 0;
        ssSetDataTypeZero( S, id, &fifozero );
    }
    // Neither of these functions can be called from the target side.
#endif

    if( !ssSetNumInputPorts(S, NR_IN_PORTS) )return;
    if( !ssSetNumOutputPorts(S, NR_OUT_PORTS) )return;

    //-------------------  PortNr,                 Width, Type,      Contiguous, DirectFF
    SetInputPortConfig( S, IN_PORT_SERIAL_IN, 		1,     id,         1,          1);
    SetInputPortConfig( S, IN_PORT_HOLD,     		1,     SS_BOOLEAN, 1,          1);

    //--------------------  PortNr,                Width, Type
    SetOutputPortConfig( S, OUT_PORT_COUNT, 	       1, SS_UINT16);
    SetOutputPortConfig( S, OUT_PORT_DATA,	   datawidth, SS_UINT8);

    ssSetNumSampleTimes(S, 1);

    ssSetNumRWork(S, NR_R_WORKS);
    ssSetNumIWork(S, NR_I_WORKS);
    ssSetNumPWork(S, NR_P_WORKS);

    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);

    for( i = 0 ; i < NR_ARGS ; i++ )
    {
        ssSetSFcnParamTunable(S,i,0);  /* None of the parameters are tunable */
    }

    ssSetSimStateCompliance( S, HAS_NO_SIM_STATE );

    ssSetOptions(S, SS_OPTION_DISALLOW_CONSTANT_SAMPLE_TIME | SS_OPTION_EXCEPTION_FREE_CODE |
                    SS_OPTION_NONSTANDARD_PORT_WIDTHS );
}

static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetModelReferenceSampleTimeInheritanceRule(S, USE_DEFAULT_FOR_DISCRETE_INHERITANCE);
    ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, 0.0);
}

#define MDL_START
static void mdlStart(SimStruct *S)
{
//    int *settings = ssGetIWork(S);
//    void **ioPtrs = ssGetPWork(S);
}

static void mdlOutputs(SimStruct *S, int_T tid) 
{
    // This block uses the output signal as persistent storage between
    // calls for the pointer to the fifo.
//    void **ioPtrs = ssGetPWork(S);
    int datawidth = (int)mxGetPr( ARG_DATA_WIDTH )[0];
    
// Read the serial fifo input
    serialfifoptr *IPtr = ssGetInputPortSignal(S,IN_PORT_SERIAL_IN);
    boolean_T     *IPtrHold = ssGetInputPortSignal(S,IN_PORT_HOLD);
    
    uint16_T  *OPtrCount = ssGetOutputPortSignal(S,OUT_PORT_COUNT);
    uint8_T  *OPtrData = ssGetOutputPortSignal(S,OUT_PORT_DATA);
    
    uint16_T mBytesRead  = ssGetIWorkValue( S, CTR_BYTES_READ );
    
	// check if a rs232-F block is connected to our inport
    if( IPtr == 0 ) {
        ssSetErrorStatus(S,"No Fifo connected: NULL ptr (DRS_RS232Test.c)");
        return;  // Do nothing
    }
    if( IPtr->token != FiFoID )
    {
        ssSetErrorStatus(S,"No Fifo connected: FiFoID wrong (DRS_RS232Test.c)");
        return; // Do nothing
    }
        
    int_T bytesread = mBytesRead;
    if (IPtrHold[0] == false) {        
        #ifdef _WIN64
            int_T *Fifo = (int_T *)( (uint64_T)IPtr->ptrlow | ((uint64_T)IPtr->ptrhigh << 32));
        #else
            int_T *Fifo = (int_T *)IPtr->ptrlow;
        #endif
            
        int_T fifosize      = Fifo[0];
        int_T *rptr         = &Fifo[1];
        int_T *wptr         = &Fifo[2];
        int_T *data         = &Fifo[3];
        
        int_T fifocount = *wptr - *rptr;
        if( fifocount < 0 )
        {
            fifocount += fifosize;
        }

        bytesread = min(datawidth, fifocount);
        for (int i = 0; i < bytesread; i++) {
            OPtrData[i] = data[*rptr];
            *rptr = (*rptr + 1) % fifosize;
            printf("[FIFO Read to labview: \r\n Byteread: %d]", bytesread);
        }
        ssSetIWorkValue( S, CTR_BYTES_READ, bytesread );
    }
    OPtrCount[0] = bytesread;
}

static void mdlTerminate(SimStruct *S)
{
}

// #define MDL_RTW
// static void mdlRTW(SimStruct *S) {
//     /* We write the settings values to the RTW file, and reconstruct the
//      * IOArgs based on the run time output and input values */
//     ssWriteRTWParamSettings(S, 1, SSWRITE_VALUE_DTYPE_VECT, "settings",
//                             ssGetIWork(S), ssGetNumIWork(S),
//                             DTINFO(SS_INT32, 0));
// 
// }

#ifdef MATLAB_MEX_FILE  /* Is this file being compiled as a MEX-file? */
#include "simulink.c"   /* Mex glue */
#else
#include "cg_sfun.h"    /* Code generation glue */
#endif
