/* $Revision: 1.0$ $Date: 2010/04/27 09:18:20 $ */
/* DRS_Sorter De Ruiter Seeds Sorter module 
*/

#define         S_FUNCTION_LEVEL        2
#undef          S_FUNCTION_NAME
#define         S_FUNCTION_NAME         DRS_Sorter

#define DEBUG

#include        <stddef.h>
#include        <stdlib.h>
//#include        <stdio.h>
#include        "simstruc.h"
#include        "Cmd_Routines.h"

#ifdef          MATLAB_MEX_FILE
#include        "mex.h"
#endif

#ifndef         MATLAB_MEX_FILE
//#include        <windows.h>
#endif

//----------------------------------------
// -- BEGIN --
// Copy here the in/output definition to the C testprogram
// -- BEGIN --
//----------------------------------------

#define IN_PORT_Reset                   0
#define IN_PORT_TriggerCounter          1
#define IN_PORT_SortEnable              2
#define IN_PORT_GateActive              3
#define IN_PORT_SeedData_TriggerCounter 4
#define IN_PORT_SeedData_PValue         5
#define IN_PORT_SeedData_Status         6
#define IN_PORT_ValidSeedData           7
#define IN_PORT_BeltLength_mm           8
#define IN_PORT_TriggerDistance_mm      9
#define IN_PORT_PValueThreshold         10
#define IN_PORT_CamToGate_mm            11
#define IN_PORT_GateToNozzle_mm         12
#define IN_PORT_GateWindow_mm           13
#define IN_PORT_FireWindow_mm           14
#define IN_PORT_FireWindowShift_mm      15
#define IN_PORT_Sort_CG                 16
#define NR_IN_PORTS                     17

#define OUT_PORT_NozzleActivation   0
#define OUT_PORT_Count_Pass         1
#define OUT_PORT_Count_Reject       2
#define OUT_PORT_Count_NoData       3
#define OUT_PORT_Count_NoSeed       4
#define OUT_PORT_Count_TooClose     5
#define OUT_PORT_Count_LateResult   6
#define OUT_PORT_Count_NegativePass 7
#define OUT_PORT_Count_NotAnalyzed  8
#define OUT_PORT_LocationInGate     9
#define OUT_PORT_Debug1             10
#define OUT_PORT_Debug2             11
#define OUT_PORT_Enabled            12
#define NR_OUT_PORTS                13

//-- Parameters section
#define NPARAMS              2
#define PARAM_MaxBeltArraySize ssGetSFcnParam(S, 0)
#define PARAM_MaxFallArraySize ssGetSFcnParam(S, 1)

#define IS_PARAM_UINT32(pVal) (mxIsNumeric(pVal) && !mxIsLogical(pVal) &&\
    !mxIsEmpty(pVal) && !mxIsSparse(pVal) && !mxIsComplex(pVal) && mxIsUint32(pVal))

#define SAMPLE_TIME_0        INHERITED_SAMPLE_TIME

//-- Local variables
#define NO_R_WORKS              (0)

#define CTR_PASS_I_IND          (0)
#define CTR_REJECT_I_IND        (1)
#define CTR_NODATA_I_IND        (3)
#define CTR_NOSEED_I_IND        (4)
#define CTR_TOOCLOSE_I_IND      (5)
#define CTR_LATERESULT_I_IND    (6)
#define CTR_NEGATIVEPASS_I_IND  (7)
#define ENABLED_STATE_I_IND     (8)
#define DISABLE_POSBELT_I_IND   (9)
#define DISABLE_POSFALL_I_IND   (10)
#define CTR_NOTANALYZED_I_IND   (11)
#define NO_I_WORKS              (12)

#define BELTARRAY_P_IND         (0)
#define FALLARRAY_P_IND         (1)
#define BTPOINTER_P_IND         (2)
#define FTPOINTER_P_IND         (3)
#define SAVEDTRIGGERCOUNT_P_IND (4)
#define NO_P_WORKS              (5)

#define NOTCOUNTED              0
#define COUNTEDASPASS           1
#define COUNTEDASREJ            2
//#define COUNTEDASMISAALIGNED    3
//#define COUNTEDASLATERESULT     4
//#define COUNTEDASNEGATIVEPASS   5

#define MAXUINT32               4294967295

// The SeedData struct also contains 2 extra fields. Now only one
// structure is used as datatype for both arrays Belt and FallArray:
// NozzleActivation: Calculated Nozzle activation (not used in BeltArray)
// ValidSeedData: To avoid continuous (re-)allocation of SeedData structures
//                we use the ValidSeedData flag to indicate if this position
//                contains data.
typedef struct
{
    int8_T      NozzleActivation;
    int8_T      ValidSeedData; 
    int8_T      SeedSeenAtGate;
    int8_T      CountedAs;
    uint32_T    TriggerCount;
    double      PValue;
    int8_T      Status;
    uint32_T    FireWindowMiddle;
} SeedData_Struct;

#define STATE_ENABLED         1
#define STATE_DISABLED        2
#define STATE_START_ENABLING  3
#define STATE_ENABLING        4

#define DISABLE_NR_ITEMS_TO_CLEAR  25*4    // HKup: *4 because Ts increased to 1 ms
#define MAXLOOPS                   10*4    // HKup: *4 because Ts increased to 1 ms

//----------------------------------------
// -- END --
// Copy here the in/output definition to the C testprogram
// -- END --
//----------------------------------------

/*====================*
* S-function methods *
*====================*/
#define MDL_CHECK_PARAMETERS
#if defined(MDL_CHECK_PARAMETERS) && defined(MATLAB_MEX_FILE)
/* Function: mdlCheckParameters =============================================
* Abstract:
*    Validate our parameters to verify they are okay.
*/
static void mdlCheckParameters(SimStruct *S)
{
    /*
    #define PrmNumPos 46
    int paramIndex = 0;
    bool validParam = false;
    char paramVector[] ={'1','2'};
    static char parameterErrorMsg[] ="The data type and/or complexity of parameter    does not match the information "
    "specified in the S-function Builder dialog. For non-double parameters you will need to cast them using int8, int16,"
    "int32, uint8, uint16, uint32 or boolean."; 

    // All parameters must match the S-function Builder Dialog 
    {
    const mxArray *pVal0 = ssGetSFcnParam(S,0);
    if (!IS_PARAM_UINT32(pVal0)) {
    validParam = true;
    paramIndex = 0;
    goto EXIT_POINT;
    }
    }

    {
    const mxArray *pVal1 = ssGetSFcnParam(S,1);
    if (!IS_PARAM_UINT32(pVal1)) {
    validParam = true;
    paramIndex = 1;
    goto EXIT_POINT;
    }
    }

    EXIT_POINT:
    if (validParam) {
    parameterErrorMsg[PrmNumPos] = paramVector[paramIndex];
    ssSetErrorStatus(S,parameterErrorMsg);
    }
    */
    return;
}
#endif /* MDL_CHECK_PARAMETERS */
/* Function: mdlInitializeSizes ===============================================
* Abstract:
*   Setup sizes of the various vectors.
*/
static void mdlInitializeSizes(SimStruct *S)
{
    ssSetNumSFcnParams(S, NPARAMS);  /* Number of expected parameters */
#if defined(MATLAB_MEX_FILE)
    if (ssGetNumSFcnParams(S) == ssGetSFcnParamsCount(S)) {
        mdlCheckParameters(S);
        if (ssGetErrorStatus(S) != NULL) {
            return;
        }
    } else {
        return; /* Parameter mismatch will be reported by Simulink */
    }
#endif

    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

    //-- Initialize input port
    ssSetNumInputPorts(S, NR_IN_PORTS);

    //-------------------  PortNr,                         Width,         Type,      Contiguous, DirectFF
    SetInputPortConfig( S, IN_PORT_Reset,                   1,     SS_BOOLEAN,  1,          1);
    SetInputPortConfig( S, IN_PORT_TriggerCounter,          1,     SS_UINT32,   1,          1);
    SetInputPortConfig( S, IN_PORT_SortEnable,              1,     SS_BOOLEAN,  1,          1);
    SetInputPortConfig( S, IN_PORT_GateActive,              1,     SS_BOOLEAN,  1,          1);
    SetInputPortConfig( S, IN_PORT_SeedData_TriggerCounter, 1,     SS_UINT32,   1,          1);
    SetInputPortConfig( S, IN_PORT_SeedData_PValue,         1,     SS_DOUBLE,    1,          1);
    SetInputPortConfig( S, IN_PORT_SeedData_Status,         1,     SS_INT8,      1,          1);

    SetInputPortConfig( S, IN_PORT_ValidSeedData,           1,     SS_BOOLEAN,  1,          1);
    SetInputPortConfig( S, IN_PORT_BeltLength_mm ,          1,     SS_DOUBLE,   1,          1);
    SetInputPortConfig( S, IN_PORT_TriggerDistance_mm ,     1,     SS_DOUBLE,   1,          1);

    SetInputPortConfig( S, IN_PORT_PValueThreshold,         1,     SS_DOUBLE,   1,          1);

    SetInputPortConfig( S, IN_PORT_CamToGate_mm,            1,     SS_DOUBLE,   1,          1);
    SetInputPortConfig( S, IN_PORT_GateToNozzle_mm,         1,     SS_DOUBLE,   1,          1);
    SetInputPortConfig( S, IN_PORT_GateWindow_mm,           1,     SS_DOUBLE,   1,          1);
    SetInputPortConfig( S, IN_PORT_FireWindow_mm,           1,     SS_DOUBLE,   1,          1);
    SetInputPortConfig( S, IN_PORT_FireWindowShift_mm,      1,     SS_DOUBLE,   1,          1);

    // Sort on the CG instead of the front of the seed
    SetInputPortConfig( S, IN_PORT_Sort_CG,                 1,     SS_DOUBLE,   1,          1);


    //-- Initialize output ports
    ssSetNumOutputPorts(S, NR_OUT_PORTS);

    //--------------------  PortNr,                  Width, Type
    SetOutputPortConfig( S, OUT_PORT_NozzleActivation,   1,     SS_BOOLEAN);
    SetOutputPortConfig( S, OUT_PORT_Count_Pass,         1,     SS_UINT32);
    SetOutputPortConfig( S, OUT_PORT_Count_Reject,       1,     SS_UINT32);
    SetOutputPortConfig( S, OUT_PORT_Count_NoData,       1,     SS_UINT32);
    SetOutputPortConfig( S, OUT_PORT_Count_NoSeed,       1,     SS_UINT32);
    SetOutputPortConfig( S, OUT_PORT_Count_TooClose,     1,     SS_UINT32);
    SetOutputPortConfig( S, OUT_PORT_Count_LateResult,   1,     SS_UINT32);
    SetOutputPortConfig( S, OUT_PORT_Count_NegativePass, 1,     SS_UINT32);
    SetOutputPortConfig( S, OUT_PORT_Count_NotAnalyzed,  1,     SS_UINT32);
    SetOutputPortConfig( S, OUT_PORT_LocationInGate,     1,     SS_DOUBLE);
    SetOutputPortConfig( S, OUT_PORT_Debug1,             1,     SS_DOUBLE);
    SetOutputPortConfig( S, OUT_PORT_Debug2,             1,     SS_DOUBLE);
    SetOutputPortConfig( S, OUT_PORT_Enabled,            1,     SS_BOOLEAN);
    
    ssSetNumSampleTimes(S, 1);
    ssSetNumRWork(S, NO_R_WORKS);
    ssSetNumIWork(S, NO_I_WORKS);
    ssSetNumPWork(S, NO_P_WORKS);
    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);

    /* Take care when specifying exception free code - see sfuntmpl_doc.c */
    ssSetOptions(S, (SS_OPTION_EXCEPTION_FREE_CODE |
        SS_OPTION_USE_TLC_WITH_ACCELERATOR 
        )); //SS_OPTION_WORKS_WITH_CODE_REUSE
}


/* Function: mdlInitializeSampleTimes =========================================
* Abstract:
*    Specifiy  the sample time.
*/
static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetSampleTime(S, 0, SAMPLE_TIME_0);
    ssSetOffsetTime(S, 0, 0.0);
}

//----------------------------------------
// -- BEGIN --
// Copy here the S-Function code to the C testprogram
// -- BEGIN --
//----------------------------------------

#define MDL_START
static void mdlStart(SimStruct *S)
{
    SeedData_Struct *BeltArray = NULL;
    SeedData_Struct *FallArray = NULL;
    uint32_T        *m_BTPointer = NULL;
    uint32_T        *m_FTPointer = NULL;
    uint32_T        *m_SavedTriggerCount = NULL;
    int_T           i = 0;
    uint32_T        ArrSize = 0;

    //allocate Belt and Fall array
    const uint32_T  MaxBeltArraySize  = (uint32_T)mxGetPr(PARAM_MaxBeltArraySize)[0];
    const uint32_T  MaxFallArraySize  = (uint32_T)mxGetPr(PARAM_MaxFallArraySize)[0];

    ArrSize = sizeof(SeedData_Struct) * (MaxBeltArraySize);
    BeltArray = (SeedData_Struct *)malloc( ArrSize );
    if( BeltArray == 0 )
    {
        ssSetErrorStatus(S,"Can't allocate memory for BeltArray");
        return;
    }
    memset(BeltArray, 0, ArrSize);

    ssSetPWorkValue( S, BELTARRAY_P_IND, (SeedData_Struct *)BeltArray );

    ArrSize = sizeof(SeedData_Struct) * (MaxFallArraySize);
    FallArray = (SeedData_Struct *)malloc( ArrSize );
    if( FallArray == 0 )
    {
        ssSetErrorStatus(S, "Can't allocate memory for FallArray");
        return;
    }
    memset(FallArray, 0, ArrSize);
    ssSetPWorkValue( S, FALLARRAY_P_IND, (SeedData_Struct *)FallArray );

    m_BTPointer = (uint32_T *)malloc( sizeof(uint32_T)); *m_BTPointer = 0;
    m_FTPointer = (uint32_T *)malloc( sizeof(uint32_T)); *m_FTPointer = 0;
    m_SavedTriggerCount = (uint32_T *)malloc( sizeof(uint32_T)); *m_SavedTriggerCount = 0;

    ssSetIWorkValue( S, ENABLED_STATE_I_IND, STATE_ENABLED );

    ssSetPWorkValue( S, BTPOINTER_P_IND, (uint32_T *)m_BTPointer );
    ssSetPWorkValue( S, FTPOINTER_P_IND, (uint32_T *)m_FTPointer );
    ssSetPWorkValue( S, SAVEDTRIGGERCOUNT_P_IND, (uint32_T *)m_SavedTriggerCount );
}

#define CP_ADD      0
#define CP_SUBTRACT 1
static uint32_T CalculatePointer( uint32_T CurrentPosition, int8_T Operation, uint32_T Offset, uint32_T FLength)
{
    uint32_T NewPointer = CurrentPosition;
    if ( Operation == CP_ADD )
    {
        NewPointer = (CurrentPosition + Offset) % FLength;
    }
    if ( Operation == CP_SUBTRACT )
    {
        NewPointer = CurrentPosition - Offset;
        // check on negative roundtrip
        if ( NewPointer > FLength )
        {
            NewPointer = NewPointer + FLength;
        }
    }
    return NewPointer;
}

static uint32_T CalcInterval( uint32_T SeedData_TriggerCounter, uint32_T Current_TriggerCounter, uint32_T BLength)
{
    uint32_T Interval = 0;
    if (SeedData_TriggerCounter <= Current_TriggerCounter)
    {
        Interval = Current_TriggerCounter - SeedData_TriggerCounter;
    } else
    {
        Interval = (MAXUINT32 - SeedData_TriggerCounter) + Current_TriggerCounter;
    }
    return Interval;
}

static void SetNozzleActivation(SeedData_Struct *SeedArray, uint32_T ArrayLength, uint32_T WindowLength, uint32_T Index, uint8_T NozzleValue)
{
    uint32_T StartPointer;
    uint32_T WindowPointer;
    uint32_T idx = 0;
    
    StartPointer = SeedArray[Index].FireWindowMiddle;
    StartPointer = CalculatePointer( StartPointer, CP_SUBTRACT, (uint32_T) (0.5 * WindowLength), ArrayLength); // Minus half firewindow

    for (idx = 0; idx < WindowLength; idx++)
    {
        WindowPointer = (StartPointer + idx) % ArrayLength;
        SeedArray[ WindowPointer ].NozzleActivation = NozzleValue; 
    } // end for
}
/* Function: mdlOutputs =======================================================
*
*/
static void mdlOutputs(SimStruct *S, int_T tid)
{

    // Create pointers to input signals
    const boolean_T *I_Reset                      = (const boolean_T*) ssGetInputPortSignal(S,IN_PORT_Reset);
    const uint32_T  *I_TriggerCounter             = (const uint32_T*) ssGetInputPortSignal(S,IN_PORT_TriggerCounter);
    const boolean_T *I_Enable                     = (const boolean_T*) ssGetInputPortSignal(S,IN_PORT_SortEnable);
    const boolean_T *I_GateActive                 = (const boolean_T*) ssGetInputPortSignal(S,IN_PORT_GateActive);
    const uint32_T  *I_SeedData_TriggerCounter    = (const uint32_T*) ssGetInputPortSignal(S,IN_PORT_SeedData_TriggerCounter);
    const real_T    *I_SeedData_PValue            = (const real_T*) ssGetInputPortSignal(S,IN_PORT_SeedData_PValue);
    const int8_T    *I_SeedData_Status            = (const int8_T*) ssGetInputPortSignal(S,IN_PORT_SeedData_Status);
    const boolean_T *I_ValidSeedData              = (const boolean_T*) ssGetInputPortSignal(S,IN_PORT_ValidSeedData);
    const real_T    *I_BeltLength_mm              = (const real_T*) ssGetInputPortSignal(S,IN_PORT_BeltLength_mm);
    const real_T    *I_TriggerDistance_mm         = (const real_T*) ssGetInputPortSignal(S,IN_PORT_TriggerDistance_mm);
    const real_T    *I_PValueThreshold            = (const real_T*) ssGetInputPortSignal(S,IN_PORT_PValueThreshold);
    const real_T    *I_CamToGate_mm               = (const real_T*) ssGetInputPortSignal(S,IN_PORT_CamToGate_mm); 
    const real_T    *I_GateToNozzle_mm            = (const real_T*) ssGetInputPortSignal(S,IN_PORT_GateToNozzle_mm); 
    const real_T    *I_GateWindow_mm              = (const real_T*) ssGetInputPortSignal(S,IN_PORT_GateWindow_mm); 
    const real_T    *I_FireWindow_mm              = (const real_T*) ssGetInputPortSignal(S,IN_PORT_FireWindow_mm); 
    const real_T    *I_FireWindowShift_mm         = (const real_T*) ssGetInputPortSignal(S,IN_PORT_FireWindowShift_mm); 
    const real_T    *I_Sort_CG                    = (const real_T*) ssGetInputPortSignal(S,IN_PORT_Sort_CG);

    // Create pointers to output signals
    boolean_T       *O_NozzleActivation   = (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_NozzleActivation);
    uint32_T        *O_Count_Pass         = (uint32_T *)ssGetOutputPortRealSignal(S,OUT_PORT_Count_Pass);
    uint32_T        *O_Count_Reject       = (uint32_T *)ssGetOutputPortRealSignal(S,OUT_PORT_Count_Reject);
    uint32_T        *O_Count_NoData       = (uint32_T *)ssGetOutputPortRealSignal(S,OUT_PORT_Count_NoData);
    uint32_T        *O_Count_NoSeed       = (uint32_T *)ssGetOutputPortRealSignal(S,OUT_PORT_Count_NoSeed);
    uint32_T        *O_Count_TooClose     = (uint32_T *)ssGetOutputPortRealSignal(S,OUT_PORT_Count_TooClose);
    uint32_T        *O_Count_LateResult   = (uint32_T *)ssGetOutputPortRealSignal(S,OUT_PORT_Count_LateResult);
    uint32_T        *O_Count_NegativePass = (uint32_T *)ssGetOutputPortRealSignal(S,OUT_PORT_Count_NegativePass);
    real_T          *O_LocationInGate     = (real_T *)ssGetOutputPortRealSignal(S,OUT_PORT_LocationInGate);
    real_T          *O_Debug1             = (real_T *)ssGetOutputPortRealSignal(S,OUT_PORT_Debug1);
    boolean_T       *O_Enabled            = (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_Enabled);
    uint32_T        *O_Count_NotAnalyzed  = (uint32_T *)ssGetOutputPortRealSignal(S,OUT_PORT_Count_NotAnalyzed);
    real_T          *O_Debug2             = (real_T *)ssGetOutputPortRealSignal(S,OUT_PORT_Debug2);

    // Read the parameters
    uint32_T  MaxBeltArraySize  = (uint32_T)mxGetPr(PARAM_MaxBeltArraySize)[0];
    uint32_T  MaxFallArraySize  = (uint32_T)mxGetPr(PARAM_MaxFallArraySize)[0];

    // Fall array length is equal to the parameter value MaxFallArraySize
    uint32_T FLength = MaxFallArraySize;

    // calculate the Belt length in TriggerPulses 
    uint32_T BLength =  (uint32_T) (*I_BeltLength_mm / *I_TriggerDistance_mm);

    // retrieve the Belt and Fall array with their corresponding pointers
    SeedData_Struct *m_BeltArray = (SeedData_Struct *)ssGetPWorkValue( S, BELTARRAY_P_IND );
    SeedData_Struct *m_FallArray = (SeedData_Struct *)ssGetPWorkValue( S, FALLARRAY_P_IND );
    uint32_T *m_BTPointer = (uint32_T *)ssGetPWorkValue( S, BTPOINTER_P_IND ); // keeps track of current position in BeltArray
    uint32_T *m_FTPointer = (uint32_T *)ssGetPWorkValue( S, FTPOINTER_P_IND ); // keeps track of current position in FallArray

    // retrieve the SavedTriggerCount value which indicates which triggers we already have handled
    uint32_T *m_SavedTriggerCount = (uint32_T *)ssGetPWorkValue( S, SAVEDTRIGGERCOUNT_P_IND );

    // Retrieve the counters
    int_T m_Counter_Pass            = ssGetIWorkValue( S, CTR_PASS_I_IND );
    int_T m_Counter_Reject          = ssGetIWorkValue( S, CTR_REJECT_I_IND );
    int_T m_Counter_NoData          = ssGetIWorkValue( S, CTR_NODATA_I_IND );
    int_T m_Counter_NoSeed          = ssGetIWorkValue( S, CTR_NOSEED_I_IND );
    int_T m_Counter_TooClose        = ssGetIWorkValue( S, CTR_TOOCLOSE_I_IND );
    int_T m_Counter_LateResult      = ssGetIWorkValue( S, CTR_LATERESULT_I_IND );
    int_T m_Counter_NegativePass    = ssGetIWorkValue( S, CTR_NEGATIVEPASS_I_IND );
    int_T m_Counter_NotAnalyzed     = ssGetIWorkValue( S, CTR_NOTANALYZED_I_IND );
    
    int_T m_Enabled_State           = ssGetIWorkValue( S, ENABLED_STATE_I_IND );
    uint32_T m_Disable_PosBelt      = (uint32_T)ssGetIWorkValue( S, DISABLE_POSBELT_I_IND );
    uint32_T m_Disable_PosFall      = (uint32_T)ssGetIWorkValue( S, DISABLE_POSFALL_I_IND );

    // Local variables prefixed with L_
    boolean_T L_SeedAccepted = false;
    uint32_T L_Index = 0;
    uint32_T L_LocalPointer = 0;
    uint32_T L_GateWindowMiddle = 0;
    uint32_T L_GateWindowStart = 0;
    uint32_T L_GateWindowLength = 0;
    uint32_T L_FireWindowMiddle = 0;
    // uint32_T L_FireWindowStart = 0;
    uint32_T L_FireWindowLength = 0;
    uint32_T L_nrOfSeedsInGateWindow = 0;
    boolean_T L_PreviousSeedAccepted = false;
    uint32_T L_NewSeedIndex = 0;
    boolean_T L_NewSeedPresent = false;
    uint32_T L_ResetOffset = 0;
    uint32_T L_ArraySize = 0;
    uint32_T L_ResetPointer = 0;
    uint32_T Loops = 0;

    uint32_T Tmp=0;
    uint32_T FLengthNeeded;
    
    uint32_T L_CGPointer = 0;
    
    boolean_T m_Counter_NoData_Bool = false;

    //-- Retrieve the sampletime and convert Ts to ms instead of s
    time_T Ts = ssGetSampleTime(S, 0);
    Ts = Ts * 1000;
    time_T tNow = ssGetT(S);

    // FallArray length is set by a parameter, but we have to check
    // if the 'total falling time' fits into the array...
    FLengthNeeded = (uint32_T)((*I_CamToGate_mm - *I_BeltLength_mm + *I_GateToNozzle_mm + (0.5 * *I_FireWindow_mm)) / *I_TriggerDistance_mm);
    
    if ( FLengthNeeded > FLength )
    {
        // Error FallArray size too small
        ssPrintf("FallArray size (%d) too small (%d)", FLength, FLengthNeeded );
        ssSetErrorStatus(S,"FallArray too small.");
        //ssSetErrorStatus(S, "FallArray size too small");
    }

    // Maximum BeltArray length is set by a parameter, but we have to check
    // if the current beltlength in triggers fit into the array
    if ( (*I_BeltLength_mm / *I_TriggerDistance_mm) > MaxBeltArraySize )
    {
        // Error BeltArray size too small
        ssPrintf("BeltArray size (%d) too small (%d)", MaxBeltArraySize, (*I_BeltLength_mm / *I_TriggerDistance_mm));
        ssPrintf("MaxBeltArraySize: %d, (*I_BeltLength_mm %f / *I_TriggerDistance_mm %f)", MaxBeltArraySize, *I_BeltLength_mm, *I_TriggerDistance_mm);
        ssSetErrorStatus(S, "BeltArray size too small");
    }

    //-- Reset pin resets all counters to 0
    if(*I_Reset == true){
        m_Counter_Pass         =0;
        m_Counter_Reject       =0;
        m_Counter_NoData       =0;
        m_Counter_NoSeed       =0;
        m_Counter_TooClose     =0;  
        m_Counter_LateResult   =0;
        m_Counter_NegativePass =0; 
        m_Counter_NotAnalyzed  =0;   
        
       //-- Reset all counters by saving zero in the workvalues       
       ssSetIWorkValue( S, CTR_PASS_I_IND, 0);
       ssSetIWorkValue( S, CTR_REJECT_I_IND, 0);
       ssSetIWorkValue( S, CTR_NODATA_I_IND, 0);
       ssSetIWorkValue( S, CTR_NOSEED_I_IND, 0);
       ssSetIWorkValue( S, CTR_TOOCLOSE_I_IND, 0);
       ssSetIWorkValue( S, CTR_LATERESULT_I_IND, 0);
       ssSetIWorkValue( S, CTR_NEGATIVEPASS_I_IND, 0);
       ssSetIWorkValue( S, CTR_NOTANALYZED_I_IND, 0);
       
        // Copy counters to output ports
        *O_Count_Pass        = m_Counter_Pass;
        *O_Count_Reject        = m_Counter_Reject;
        *O_Count_NoData        = m_Counter_NoData;
        *O_Count_NoSeed     = m_Counter_NoSeed;
        *O_Count_TooClose    = m_Counter_TooClose;
        *O_Count_LateResult = m_Counter_LateResult;
        *O_Count_NegativePass = m_Counter_NegativePass;
        *O_Count_NotAnalyzed  = m_Counter_NotAnalyzed;
        *O_LocationInGate = 0;
    }
    
    //----------------------
    //-- Enable signal
    //--
    //-- If the Enable signal is false move to the DISABLED state
    //-- when The Enable signal becomes true the system will go to the
    //-- ENABLED state via the START_ENABLING and ENABLING states
    //-- 
    //-- In the (START_)ENABLING state we clear the SeedData arrays in
    //-- small steps to prevent a cpu overload on the target
    //----------------------
    if (*I_Enable == false)
    {
        // switch to the DISABLED state
        m_Enabled_State = STATE_DISABLED;
        ssSetIWorkValue( S, ENABLED_STATE_I_IND, m_Enabled_State );
    } else
    {
        // only enable from the disabled state (otherwise enabling is already in progress)
        if (m_Enabled_State == STATE_DISABLED)
        {
            // State was DISABLED move to the START_ENABLING state
            m_Enabled_State = STATE_START_ENABLING;
            ssSetIWorkValue( S, ENABLED_STATE_I_IND, m_Enabled_State );
        }
    }

    switch(m_Enabled_State)
    {
    case STATE_ENABLED:
        *O_Enabled = true; //-- Signal to the outport that the system is enabled
        break;
    case STATE_START_ENABLING:
        //-- We keep an index in the arrays so we know where
        //-- clearing is stopped last Ts. Reset these indexes here
        m_Disable_PosBelt = 0;
        m_Disable_PosFall = 0;
        //-- Switch to the ENABLING state
        m_Enabled_State = STATE_ENABLING;

        //-- Save the variables into the IWorkValue space
        ssSetIWorkValue( S, ENABLED_STATE_I_IND, m_Enabled_State );
        ssSetIWorkValue( S, DISABLE_POSBELT_I_IND, (int_T)m_Disable_PosBelt );
        ssSetIWorkValue( S, DISABLE_POSFALL_I_IND, (int_T)m_Disable_PosFall );

        *O_Enabled = false; //-- Signal to the outport that the system is still disabled
        return;
        break;

    case STATE_ENABLING:
        // Clear a little part of the Belt and Fall array
        for (L_Index = 0; L_Index < DISABLE_NR_ITEMS_TO_CLEAR; L_Index++)
        {
            if (m_Disable_PosBelt < MaxBeltArraySize)
            {
                //-- clear the array item by setting the ValidSeedData field
                m_BeltArray[m_Disable_PosBelt].ValidSeedData = 0;
                m_Disable_PosBelt++;
            }

            if (m_Disable_PosFall < MaxFallArraySize)
            {
                //-- the FallArray has seeddata and activates the Nozzle
                //-- Clear the array item by setting the ValidSeedData field
                m_FallArray[m_Disable_PosFall].ValidSeedData = 0;
                //-- And clear the NozzleActivation 
                m_FallArray[m_Disable_PosFall].NozzleActivation = 0;
                m_Disable_PosFall++;
            }
        }
        //-- Check if both arrays are cleared completely
        if (m_Disable_PosBelt >= MaxBeltArraySize && m_Disable_PosFall >= MaxFallArraySize)
        {
            //-- Update internal trigger pointer in the beltarray to the
            //-- external triggercounter
            *m_BTPointer = *I_TriggerCounter % BLength;

            // Also clear the Saved trigger otherwise the saved trigger cannot 
            // catch up with the I-Triggercount value.
            *m_SavedTriggerCount = *I_TriggerCounter;

            //-- Clearing of arrays finished, switch to ENABLED state
            m_Enabled_State = STATE_ENABLED;
        }

        //-- Save the variables into the IWorkValue space
        ssSetIWorkValue( S, ENABLED_STATE_I_IND, m_Enabled_State );
        ssSetIWorkValue( S, DISABLE_POSBELT_I_IND, (int_T)m_Disable_PosBelt );
        ssSetIWorkValue( S, DISABLE_POSFALL_I_IND, (int_T)m_Disable_PosFall );

        *O_Enabled = false; //-- Signal to the outport that the system is still disabled
        return;
        break;
    case STATE_DISABLED:
        *O_Enabled = false; //-- Signal to the outport that the system is disabled
        return;
        break;
    }

    //----------------------
    //-- Belt Array
    //--
    //-- update the Beltpointer and copy SeedData that's about to fall into
    //-- the FallArray
    //----------------------

    // Update our internal triggercount with the external camera trigger
    // (We assume the TriggerCounter can only increase !)
    // prevent the while loop for long loop times with the variable Loops
    Loops = 0;

    while ( *m_SavedTriggerCount != *I_TriggerCounter && Loops++ < MAXLOOPS )
    {
        // increase counter and index
        *m_SavedTriggerCount = *m_SavedTriggerCount + 1; // can automatically wrap around at 32 bits
        *m_BTPointer = ( *m_BTPointer + 1 ) % BLength; // wrap around the BeltLength

        // Check if there's data that must be copied to the FallArray
        if ( m_BeltArray[*m_BTPointer].ValidSeedData > 0 )
        {
            // if the FallArray already contains SeedData, the data is 
            // very close in belt array.
            if ( m_FallArray[*m_FTPointer].ValidSeedData > 0)
            {
                m_Counter_TooClose++;
            }

            // Seed is about to fall. Copy the data to the fall array
            m_FallArray[*m_FTPointer].ValidSeedData = m_BeltArray[*m_BTPointer].ValidSeedData;
            m_FallArray[*m_FTPointer].SeedSeenAtGate = m_BeltArray[*m_BTPointer].SeedSeenAtGate;
            m_FallArray[*m_FTPointer].TriggerCount = m_BeltArray[*m_BTPointer].TriggerCount;
            m_FallArray[*m_FTPointer].PValue = m_BeltArray[*m_BTPointer].PValue;
            m_FallArray[*m_FTPointer].Status = m_BeltArray[*m_BTPointer].Status;
            m_FallArray[*m_FTPointer].CountedAs = NOTCOUNTED;
            m_FallArray[*m_FTPointer].FireWindowMiddle = 0;
            m_FallArray[*m_FTPointer].NozzleActivation = 0;

            // delete the current SeedData entry from the BeltArray
            m_BeltArray[*m_BTPointer].ValidSeedData = 0;
        } // end if

        // Check on new SeedData received from vision system
        if (( *I_ValidSeedData == 1 ) && (Loops == 1)) // this should be done only once
        {
            // Check how 'old' the SeedData is. Check the number of triggers
            // between received TriggerCounter and the actual TriggerCounter.
            if (BLength > CalcInterval( *I_SeedData_TriggerCounter, *m_SavedTriggerCount, BLength ))
            {
                // Copy the SeedData into the BeltArray
                m_BeltArray[*I_SeedData_TriggerCounter % BLength].ValidSeedData = 1;
                m_BeltArray[*I_SeedData_TriggerCounter % BLength].SeedSeenAtGate = 0;
                m_BeltArray[*I_SeedData_TriggerCounter % BLength].TriggerCount = *I_SeedData_TriggerCounter;
                m_BeltArray[*I_SeedData_TriggerCounter % BLength].PValue = *I_SeedData_PValue;
                m_BeltArray[*I_SeedData_TriggerCounter % BLength].Status = *I_SeedData_Status;
            } else
            {  // seed data to old! Vision system reacts to late, the seed
                // already fell of the Belt. Don't add it to the array.
                m_Counter_LateResult++;
            }
        }

        // Increase the FTPointer
        *m_FTPointer = ( *m_FTPointer + 1 ) % FLength;

        // Copy NozzleActivation from the fallarray and reset it afterwards
        *O_NozzleActivation = (boolean_T) ((m_FallArray[*m_FTPointer].NozzleActivation) != 0);
        m_FallArray[*m_FTPointer].NozzleActivation = 0;

        // Check if SeedData on FTPointer is seen at the gate and reset it afterwards.
        if ( m_FallArray[*m_FTPointer].ValidSeedData > 0 )
        {
            // if Seed is not seen at the gate we count it as misaligned
            if ( m_FallArray[*m_FTPointer].SeedSeenAtGate == 0)
            {
                m_Counter_NoSeed++;
            }
            // Remove the SeedData from the FallArray
            m_FallArray[*m_FTPointer].ValidSeedData = 0;
        }

    } //end while

    // mhaj: Loops = number of triggercounters passed in this update.

    //----------------------
    //-- Fall Array
    //--
    //-- Check on gate signal, Activate the Nozzle if necessary, and cleanup the FallArray
    //----------------------

    if ( *I_GateActive == true )
    {
        // Gate & fire window are now POSITION based (names still suggest time based).
        //---------------------------------------------------------------------------------------------------------------
        // mhaj @ 05-Jan-2012
        // This code now is OUTSIDE the while loop. Therefore the m_FTPointer has not shifted "1" position, 
        // but "Loops" positions, leaving a gap in between. The Gatewindow size has to be adjusted for this, 
        // otherwise some seeds will "fall into the gap" and will not be counted (and not be cleared!!!).
        // This results in "TooClose" errors when the array flows over and new data is added.  
        // These newly added seeds can then be too close to data that was not cleared.
        // The correction is "Loops-1".
        // Also the gatewindow length has to be increased with the same value.
        // Same for firewindow.
        //---------------------------------------------------------------------------------------------------------------        
        L_GateWindowMiddle = CalculatePointer( *m_FTPointer, CP_SUBTRACT, (uint32_T) ((*I_CamToGate_mm - *I_BeltLength_mm) / *I_TriggerDistance_mm), FLength); 
        L_GateWindowStart = CalculatePointer(L_GateWindowMiddle, CP_SUBTRACT, (uint32_T) ((0.5 * *I_GateWindow_mm) / *I_TriggerDistance_mm) + Loops-1, FLength);
        L_GateWindowLength = (uint32_T) (*I_GateWindow_mm / *I_TriggerDistance_mm)+Loops;

        //---------------------------------------------------------------------------------------------------------------        
        // Added I_FireWindowShift_mm
        //
        // I_FireWindowShift_mm will shift the actual firewindow. This can be usefull for seeds where the CoG (vision data)
        // of the seed and the front (gate sensor) significantly differ. These seeds can be hard to remove from the belt.
        //--------------------------------------------------------------------------------------------------------------- 
        
        // "Classic" sort using the front edge of the seed, as detected by the gate sensors.
        if (*I_Sort_CG < 0.5)
        {
            L_FireWindowMiddle = CalculatePointer( *m_FTPointer, CP_ADD, (uint32_T) ((*I_GateToNozzle_mm + *I_FireWindowShift_mm) / *I_TriggerDistance_mm), FLength);
            L_FireWindowLength = (uint32_T) (*I_FireWindow_mm / *I_TriggerDistance_mm)+Loops;
        }

        // walk through the GateWindow and search for SeedData
        // Count the number of seeds in the seedwindow and determine
        // if we accept this seed
        L_SeedAccepted = true; // default let all seed through
        L_PreviousSeedAccepted = false;
        L_nrOfSeedsInGateWindow = 0;
        L_NewSeedIndex = 0;
        L_NewSeedPresent = false;

        // count the number of seeds in the GateWindow, and remember the index of
        // the first new seed
        L_LocalPointer = L_GateWindowStart;

        for (L_Index = 0; L_Index < L_GateWindowLength; L_Index++)
        {
            // L_LocalPointer = (L_GateWindowStart + L_Index) % FLength;
            L_LocalPointer++;

            if (L_LocalPointer >= FLength) 
            {
                L_LocalPointer = 0;
            }

            // Check for a seed in the fall array
            if ( m_FallArray[ L_LocalPointer ].ValidSeedData > 0)
            {
                L_nrOfSeedsInGateWindow++;

                // This variable shows the location of the seed data with respect to the gate window.
                // Ideal situation = approx 0 mm.
                *O_LocationInGate = (real_T) (L_Index - 0.5*L_GateWindowLength) * *I_TriggerDistance_mm;

                // "SeedSeenAtGate == 1" means this seed was already seen at the gate in a previous model cycle.
                // This condition can only happen if:
                // 1) a seed triggers the gate sensors more than once. Using gate debounce this should not happen.
                // 2) multiple seeds are present and therefore "TooClose" (or the GateWindow is too large)
                
                if ( m_FallArray[ L_LocalPointer ].SeedSeenAtGate == 1)
                {
                    // for positive discrimination we check if a seed in the gatewindow already passed
                    if ( m_FallArray[ L_LocalPointer ].CountedAs == COUNTEDASPASS )
                    {
                        L_PreviousSeedAccepted = true;
                    } else 
                    {
                    }
                } else // (ValidSeedData > 0) && (SeedSeenAtGate == 0)
                {
                    if (L_NewSeedPresent == false)
                    {
                        // remember the seedindex of the new seed entering the gate window
                        L_NewSeedIndex = L_LocalPointer;
                        L_NewSeedPresent = true;
                    } else
                    {   
                        // In the search area around the gate, multiple "ValidSeedData" locations can be found. 
                        // The first one is the one corresponding to current GateActive event.
                        // Other ValidSeedData in the search area will be handled when the Gate is triggered again.
                        // GateActive is edge triggered (so only 1 cycle high after debounce).
                        // 
                        // Warning: This won't work if the Gate isn't triggered again (when two seeds are seen as one).
                        // In that case, the other ValidSeedData won't be handled anymore.
                    }
                }
            }
        } // end for

        if ( L_nrOfSeedsInGateWindow == 0 )
        {
            // No SeedData found on software belt, but hardware gate was triggered
            // m_Counter_NoData++;
            m_Counter_NoData_Bool = true;
        } else
        { 
            // If GateWindow contains only already processed seeds, we can just continue.
            // This can only happen if the gate was triggered multiple times by the same seed.
            if (L_NewSeedPresent == true)
            {
                // when a seed enters the gatewindow while there are others present we increase the TooClose counter
                if ( L_nrOfSeedsInGateWindow > 1 )
                {
                    m_Counter_TooClose++; 
                }

                // mark that we have seen this new seed
                m_FallArray[ L_NewSeedIndex ].SeedSeenAtGate = 1;
                
                //---------------------------------------------------------------------------------------------------------------------
                // Calculate the firewindow based on CG data as found in the vision data instead of the front of the seed detected by the gate sensors.
                // 
                // Summary from above code:
                // *m_FTPointer is the main belt position pointer (counter which loops with FLength)
                // *m_FTPointer is used to calculate the L_GateWindowMiddle. For this a shift of (*I_CamToGate_mm - *I_BeltLength_mm) / *I_TriggerDistance_mm 
                // is used. This is a tuning parameter for each sorter.
                //
                // L_LocalPointer starts at loops L_GateWindowStart and through the GateWindow to find the seed vision data.
                // When the seed data is found, the actual L_LocalPointer is stored in L_NewSeedIndex.
                // L_NewSeedIndex is therefore the position on the belt where the vision data is stored = CG position.
                // 
                // BUT, the L_FireWindowMiddle needs to be calculated based on the *m_FTPointer. 
                // Therefore a shift back of (*I_CamToGate_mm - *I_BeltLength_mm) / *I_TriggerDistance_mm should be performed on the L_NewSeedIndex. 
                // The result is stored in L_CGPointer.
                // When the seed CG and front (gate sensors) are very close, the *m_FTPointer and the L_CGPointer will be very much the same. Just a few mm correction for CG vs front.
                // After the shift back, the "normal" firewindow calculation can be used.
                //---------------------------------------------------------------------------------------------------------------------

                L_CGPointer = CalculatePointer(L_NewSeedIndex, CP_ADD, (uint32_T) ((*I_CamToGate_mm - *I_BeltLength_mm) / *I_TriggerDistance_mm), FLength);

                if (*I_Sort_CG >= 0.5)
                {
                    L_FireWindowMiddle = CalculatePointer( L_CGPointer, CP_ADD, (uint32_T) ((*I_GateToNozzle_mm + *I_FireWindowShift_mm) / *I_TriggerDistance_mm), FLength);
                    L_FireWindowLength = (uint32_T) (*I_FireWindow_mm / *I_TriggerDistance_mm)+Loops;
                }
                
                *O_Debug1 = *m_FTPointer;
                *O_Debug2 = L_CGPointer;

                m_FallArray[ L_NewSeedIndex ].FireWindowMiddle = L_FireWindowMiddle; 
                
                // check if we can accept this seed in status and PValue
                if ( (m_FallArray[ L_NewSeedIndex ].PValue < *I_PValueThreshold && m_FallArray[ L_NewSeedIndex ].Status < 2 ) )
                {
                    m_FallArray[ L_NewSeedIndex ].CountedAs = COUNTEDASREJ; // REJECTED
                    m_Counter_Reject++; // count the fraction the seed originally belongs to, although it might be promoted
                    // seed is rejected but if there's another seed within the gatewindow who was already accepted
                    // we accept this one also (negative discrimination)
                    if (L_PreviousSeedAccepted == true)
                    {
                        // ACC + REJ -> ACC
                        L_SeedAccepted = true;
                        m_Counter_NegativePass++;
                    } else
                    {
                        // REJ + REJ -> REJ
                        L_SeedAccepted = false;
                    }
                } else // ACCEPTED
                {
                    L_SeedAccepted = true;
                    m_FallArray[ L_NewSeedIndex ].CountedAs = COUNTEDASPASS;
                    m_Counter_Pass++;
                    if  (m_FallArray[ L_NewSeedIndex ].Status == 2) // not analyzed; treat as passed but also update 'NotAnalyzed' counter
                    {
                        m_Counter_NotAnalyzed++;
                    }
                }

                // if the new seed is accepted while the previous seeds (still in window) were rejected, we have to correct
                // this situation! because we use the positive discrimination policy
                if ((L_nrOfSeedsInGateWindow > 1) && (L_PreviousSeedAccepted == false && L_SeedAccepted == true))
                {
                    // walk through gatewindow and change status of SeedData. At the same time correct the counters
                    // Reset the nozzle activation bits for seeds that were rejected but not changes it's state to Accepted
                    for (L_Index = 0; L_Index < L_GateWindowLength; L_Index++)
                    {
                        L_LocalPointer = (L_GateWindowStart + L_Index) % FLength;
                        // Check for an other seed in the fall array but not the New SeedData
                        if ( L_NewSeedIndex != L_LocalPointer && m_FallArray[ L_LocalPointer ].ValidSeedData > 0)
                        {
                            if ( m_FallArray[ L_LocalPointer ].CountedAs == COUNTEDASREJ )
                            {
                                // REJ + ACC -> ACC
                                // change status and update the counters
                                m_FallArray[ L_LocalPointer ].CountedAs = COUNTEDASPASS;
                                m_Counter_NegativePass++;
                                // Reset the nozzle activation because status was changed
                                SetNozzleActivation(m_FallArray, FLength, L_FireWindowLength, L_LocalPointer, 0); // reset activation of nozzle
                            } // end for
                        }
                    }
                }
            } else {
                // L_NewSeedPresent == false
            }
        } 

        if ( !L_SeedAccepted )
        {  
            // walk through the FireWindow1 and activate the nozzle
            SetNozzleActivation(m_FallArray, FLength, L_FireWindowLength, L_NewSeedIndex, 1); //   set activation of nozzle
        } else {
            // L_SeedAccepted == true, no nozzle activation
        }
    } // endif gateactive

    if (m_Counter_NoData_Bool)
    {
        m_Counter_NoData++;
    }

    // Copy the counter back to the Work Storage
    ssSetIWorkValue( S, CTR_PASS_I_IND, m_Counter_Pass );
    ssSetIWorkValue( S, CTR_REJECT_I_IND, m_Counter_Reject );
    ssSetIWorkValue( S, CTR_NODATA_I_IND, m_Counter_NoData );
    ssSetIWorkValue( S, CTR_NOSEED_I_IND, m_Counter_NoSeed );
    ssSetIWorkValue( S, CTR_TOOCLOSE_I_IND, m_Counter_TooClose );
    ssSetIWorkValue( S, CTR_LATERESULT_I_IND, m_Counter_LateResult );
    ssSetIWorkValue( S, CTR_NEGATIVEPASS_I_IND, m_Counter_NegativePass );
    ssSetIWorkValue( S, CTR_NOTANALYZED_I_IND,  m_Counter_NotAnalyzed);

    // Copy counters to output ports
    *O_Count_Pass        = m_Counter_Pass;
    *O_Count_Reject        = m_Counter_Reject;
    *O_Count_NoData        = m_Counter_NoData;
    *O_Count_NoSeed     = m_Counter_NoSeed;
    *O_Count_TooClose    = m_Counter_TooClose;
    *O_Count_LateResult = m_Counter_LateResult;
    *O_Count_NegativePass = m_Counter_NegativePass;
    *O_Count_NotAnalyzed  = m_Counter_NotAnalyzed;

}

/* Function: mdlTerminate =====================================================
* Abstract:
*    In this function, you should perform any actions that are necessary
*    at the termination of a simulation.  For example, if memory was
*    allocated in mdlStart, this is the place to free it.
*/
static void mdlTerminate(SimStruct *S)
{
    //-- Free all allocated data
    SeedData_Struct* Array;
    uint32_T* pInteger;

    Array = (SeedData_Struct *)ssGetPWorkValue( S, BELTARRAY_P_IND );
    free( (SeedData_Struct*) Array );

    Array = (SeedData_Struct *)ssGetPWorkValue( S, FALLARRAY_P_IND );
    free( (SeedData_Struct*) Array );

    pInteger = (uint32_T*)ssGetPWorkValue( S, BTPOINTER_P_IND);
    free(pInteger);
    pInteger = (uint32_T*)ssGetPWorkValue( S, FTPOINTER_P_IND);
    free(pInteger);
    pInteger = (uint32_T*)ssGetPWorkValue( S, SAVEDTRIGGERCOUNT_P_IND);
    free(pInteger);
}
//----------------------------------------
// -- END --
// Copy here the S-Function code to the C testprogram
// -- END --
//----------------------------------------

#ifdef  MATLAB_MEX_FILE    /* Is this file being compiled as a MEX-file? */
#include "simulink.c"      /* MEX-file interface mechanism */
#else
#include "cg_sfun.h"       /* Code generation registration function */
#endif


