/*
 * serialfifotypes.h  copied serialfifoptr from  xPC Target Header File
 *
 *
 * Define serialfifoptr , shall be identical with serialfifoptr used by xPC Target blocks.
 */
#ifndef __SERIALFIFOTYPES__
#define __SERIALFIFOTYPES__ 1
    typedef struct serialfifo {
        uint32_T ptrlow;
        uint32_T ptrhigh;
        uint32_T token;
    } serialfifoptr;
#endif
