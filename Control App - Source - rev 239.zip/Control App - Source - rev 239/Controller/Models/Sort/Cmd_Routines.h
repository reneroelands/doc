#ifndef CMDROUTINES_H
#define CMDROUTINES_H


#ifdef DEBUG
    #ifdef MATLAB_MEX_FILE
        #define DbgPrintf( S, msgString )  mexPrintf("%8.3f %s (%s,%d)\n", ssGetT(S), msgString,__FILE__,__LINE__);
    #else
        #define DbgPrintf( S, msgString )  printf("%8.3f %s (%s,%d)\n", ssGetT(S), msgString,__FILE__,__LINE__);
    #endif
#else
    #define DbgPrintf( S, msgString )  {};
#endif

#ifdef MATLAB_MEX_FILE
    #define TrcPrintf( S, modString, msgString )  mexPrintf("%8.3f %s%s\n", ssGetT(S), modString, msgString);
#else
    #ifdef DEBUG
        #define TrcPrintf( S, modString, msgString )  printf("%8.3f %s%s\n", ssGetT(S), modString, msgString);
    #else
        #define TrcPrintf( S, modString, msgString )  {};
    #endif
#endif

static const int_T FiFoID = (('F'*256+'i')*256+'F')*256+'o';

#define MSGLEN  256
static char_T msg[MSGLEN]; //-- used for error messages, and ssPrintf messages

// FIFO read and write block communication
typedef struct serialfifo {
    uint32_T ptrlow;
    uint32_T ptrhigh;
    uint32_T token;
} serialfifoptr;
                            
static int_T* CreateFifo( SimStruct *S , int iFifoLen, int iIWorkIndex)
{
    int_T* fifomem = NULL;
    int    i       = 0;

    //-- We create a fifo
    //-- We add 3 ints at front of memory block to indicate size, readpointer and writepointer in cmdfifo.
    fifomem = (int_T *)malloc( sizeof(int_T) * (iFifoLen + 3) );
    if( fifomem == 0 )
    {
        sprintf_s(msg, MSGLEN, "Can't allocate memory for fifo" );
        ssSetErrorStatus(S,msg);
        return 0;
    }
    ssSetIWorkValue( S, iIWorkIndex, (int) fifomem );

    // Clear the CMDFIFO data
    for( i = 0 ; i < iFifoLen + 3 ; i++ )
    {
        fifomem[i] = 0;
    }
    fifomem[0] = iFifoLen;
    
    return fifomem;
}

static void FreeFifo(SimStruct *S, int iIWorkIndex)
{
     //-- Free the fifo
    int *fifomem = (int *)ssGetIWorkValue( S, iIWorkIndex );
    if ( fifomem != 0)
    {
        free( fifomem );
    }
}

//-- copies the null terminated string (szbuf) into a fifo
static bool StringToFifo( serialfifoptr* IPtr, const char  *szBuf)
{
  #ifdef _WIN64
    int_T *Fifo = (int_T *)( (uint64_T)IPtr->ptrlow | ((uint64_T)IPtr->ptrhigh << 32));
  #else
    int_T *Fifo = (int_T *)IPtr->ptrlow;
  #endif

  int_T fifosize      = Fifo[0];
  int_T *rptr         = &Fifo[1];
  int_T *wptr         = &Fifo[2];
  int_T *data         = &Fifo[3];
  int   iIndex        = 0;
  int   iLen          = strlen(szBuf);
  int_T fifocount     = 0;

  if ( iLen >= fifosize )
  {
    return false;
  }
  
  fifocount = *wptr - *rptr;
  if( fifocount < 0 )
  {
      fifocount += fifosize;
  }
  
  //-- Check on buffer overrun 
  if ( iLen >= ( fifosize - fifocount ) )
  {
      return false; //-- There's too less space in destination buffer
  }

  for (iIndex = 0; iIndex < iLen; iIndex++)
  {
    data[*wptr] = szBuf[iIndex];
    *wptr = (*wptr + 1)%fifosize;
  }
  return true;
}

static bool CopyFifoToFifo( serialfifoptr* DestIPtr, serialfifoptr* SrcIPtr )
{
  #ifdef _WIN64
    int_T *DFifo = (int_T *)( (uint64_T)SrcIPtr->ptrlow | ((uint64_T)SrcIPtr->ptrhigh << 32));
  #else
    int_T *DFifo = (int_T *)DestIPtr->ptrlow;
  #endif

//    int_T *DFifo = (int_T *)DestFifo[0];
//    int_T *DFifo = DestFifo;
    
    int_T *Drptr = &DFifo[1];
    int_T *Dwptr = &DFifo[2];
    int_T *Ddata = &DFifo[3];
    int_T Dfifosize = DFifo[0];

  #ifdef _WIN64
    int_T *SFifo = (int_T *)( (uint64_T)SrcIPtr->ptrlow | ((uint64_T)SrcIPtr->ptrhigh << 32));
  #else
    int_T *SFifo = (int_T *)SrcIPtr->ptrlow;
  #endif
//    int_T *SFifo = (int_T *)SrcFifo[0];
//    int_T *SFifo = SrcFifo;
    
    int_T *Srptr = &SFifo[1];
    int_T *Swptr = &SFifo[2];
    int_T *Sdata = &SFifo[3];
    int_T Sfifosize = SFifo[0];

    int Sfifocount = 0;
    int Dfifocount = 0;
    int i = 0;

//    sprintf_s(msg, MSGLEN, "CopyFifoToFifo: FifoDst=%d FifoSrc=%d\n", (int_T)DestFifo,(int_T)SrcFifo); 
//    mexPrintf(msg);
    
    Sfifocount = *Swptr - *Srptr;
    if( Sfifocount < 0 )
        Sfifocount += Sfifosize;
    Dfifocount = *Dwptr - *Drptr;
    if( Dfifocount < 0 )
        Dfifocount += Dfifosize;

    //-- Check on buffer overrun 
    if ( Sfifocount >= ( Dfifosize - Dfifocount ) )
    {
        return false; //-- There's too less space in destination buffer
    }

    //-- Do the actual copy.
    for( i = 0 ; i < Sfifocount ; i++ )
    {
        Ddata[ *Dwptr ] = Sdata[ *Srptr ];
        *Dwptr = ( *Dwptr + 1 ) % Dfifosize;

        Sdata[*Srptr] = 0;  // clear the data from the source fifo
        *Srptr = ( *Srptr + 1 ) % Sfifosize;
    }
    return true;
}

#ifndef PCSIM

static void SetInputPortConfig( SimStruct *S, int iPortnr, int iPortWidth, DTypeId Type, int iContiguous, int iDirectFF)
{
  ssSetInputPortWidth             ( S, iPortnr, iPortWidth );
  ssSetInputPortDataType          ( S, iPortnr, Type );
  ssSetInputPortRequiredContiguous( S, iPortnr, iContiguous ); 
  ssSetInputPortDirectFeedThrough ( S, iPortnr, iDirectFF);
}

static void SetOutputPortConfig( SimStruct *S, int iPortnr, int iPortWidth, DTypeId Type)
{
   ssSetOutputPortWidth   ( S, iPortnr, iPortWidth);
   ssSetOutputPortDataType( S, iPortnr, Type );
}
#endif

static void AtOffsetGetStringFromBuf(unsigned char* Dest, serialfifoptr* IPtr, int iStartpos, int iLen)
{
    //-- copy a string from fifo with length iLen to a string
  #ifdef _WIN64
    int_T *Fifo = (int_T *)( (uint64_T)IPtr->ptrlow | ((uint64_T)IPtr->ptrhigh << 32));
  #else
    int_T *Fifo = (int_T *)IPtr->ptrlow;
  #endif
    int_T *rptr = &Fifo[1];
    int_T *wptr = &Fifo[2];
    int_T *data = &Fifo[3];
    int_T fifosize = Fifo[0];
    int fifocount = 0;
    int iIndex = 0;
    int iLoc = 0;

    fifocount = *wptr - *rptr;
    if( fifocount < 0 )
    {
        fifocount += fifosize;
    }

    if (iLen >= fifocount)
    {
        Dest[0] = 0;  //-- Zero terminator
        return;       //-- String in fifo is smaller than wanted (iLen) 
    }
 
    //-- copy fifo data into destination buffer
    for( iIndex = 0; iIndex < iLen; iIndex++ )
    {
        int iLoc = (*rptr + iIndex + iStartpos);
        if( iLoc >= fifosize )
            iLoc -= fifosize;

        Dest[iIndex] = data[iLoc];
    }        
    Dest[iIndex] = 0;  //-- Zero terminator
}

static void GetStringFromBuf(unsigned char* Dest, serialfifoptr* IPtr, int iLen)
{
    //-- copy a string from fifo with length iLen to a string
  #ifdef _WIN64
    int_T *Fifo = (int_T *)( (uint64_T)IPtr->ptrlow | ((uint64_T)IPtr->ptrhigh << 32));
  #else
    int_T *Fifo = (int_T *)IPtr->ptrlow;
  #endif
    int_T *rptr = &Fifo[1];
    int_T *wptr = &Fifo[2];
    int_T *data = &Fifo[3];
    int_T fifosize = Fifo[0];
    int fifocount = 0;
    int iIndex = 0;
    int iLoc = 0;

    fifocount = *wptr - *rptr;
    if( fifocount < 0 )
    {
        fifocount += fifosize;
    }

    if (iLen > fifocount)
    {
        return;  //-- String in fifo is smaller than wanted (iLen) 
    }
 
    //-- copy fifo data into destination buffer
    for( iIndex = 0; iIndex < iLen; iIndex++ )
    {
        int iLoc = (*rptr + iIndex);
        if( iLoc >= fifosize )
            iLoc -= fifosize;

        Dest[iIndex] = data[iLoc];
    }        
    Dest[iIndex] = 0;  //-- Zero terminator
}

#endif
