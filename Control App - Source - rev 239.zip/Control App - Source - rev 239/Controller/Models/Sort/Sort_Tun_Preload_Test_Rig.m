%---------------------------------------------------------------------------------------------------------------
% CCM, Center for Concepts in Mechatronics
%---------------------------------------------------------------------------------------------------------------
% Sorter
%
% Initializes tuning parameters
%
%---------------------------------------------------------------------------------------------------------------

disp(sprintf('Sort Tuning Preload --> Test Rig.'))


%-----------------------------------------------------------------------
% Tuning parameters
%-----------------------------------------------------------------------

% Rotation unit, SI units in rad, rad/s, rad/s^2 etc.
Sort.Tun.BeltLength_mm      =   170.00;       % Needed as long as OLD sorter is active.
% Sort.Tun.TriggerDistance_mm =   0.007*2;   % NOT USED. Trigger model sets trigger distance.
Sort.Tun.PValueUpper        =   0.6;       
Sort.Tun.PValueLower        =   0.5;       
Sort.Tun.GateWindow_mm      =   6.00;        % now is [mm]
Sort.Tun.FireWindow_mm      =   6.00;        % now is [mm]

Sort.Tun.Gate_Debounce            = 1;

CamToGate_Offset_mm = 184;

% Distances camera to gate & 2 nozzels
% Camera to Gate 1
% Mid sensor @ pixel 2100
% Approx. 65 pixels /mm 
Sort.Tun.Lane1.Start              =  1150 - 3.25*65;   
Sort.Tun.Lane1.Stop               =  1150 + 3.25*65;   
Sort.Tun.Lane1.CamToGate_mm       =  CamToGate_Offset_mm + 0;
Sort.Tun.Lane1.GateToNozzle1_mm   =  75;
Sort.Tun.Lane1.GateToNozzle2_mm   =  150;

% Camera to Gate 2
Sort.Tun.Lane2.Start              =  100;   
Sort.Tun.Lane2.Stop               =  199;   
Sort.Tun.Lane2.CamToGate_mm       =  CamToGate_Offset_mm + 0;
Sort.Tun.Lane2.GateToNozzle1_mm   =  50;
Sort.Tun.Lane2.GateToNozzle2_mm   =  100;

% Camera to Gate 3
Sort.Tun.Lane3.Start              =  200;   
Sort.Tun.Lane3.Stop               =  299;   
Sort.Tun.Lane3.CamToGate_mm       =  CamToGate_Offset_mm + 0;;
Sort.Tun.Lane3.GateToNozzle1_mm   =  50;
Sort.Tun.Lane3.GateToNozzle2_mm   =  100;

% Camera to Gate 4
Sort.Tun.Lane4.Start              =  300;   
Sort.Tun.Lane4.Stop               =  399;   
Sort.Tun.Lane4.CamToGate_mm       =  CamToGate_Offset_mm + 0;;
Sort.Tun.Lane4.GateToNozzle1_mm   =  50;
Sort.Tun.Lane4.GateToNozzle2_mm   =  100;

% Camera to Gate 5
Sort.Tun.Lane5.Start              =  400;   
Sort.Tun.Lane5.Stop               =  499;   
Sort.Tun.Lane5.CamToGate_mm       =  CamToGate_Offset_mm + 0;;
Sort.Tun.Lane5.GateToNozzle1_mm   =  50;
Sort.Tun.Lane5.GateToNozzle2_mm   =  100;

% Camera to Gate 6
Sort.Tun.Lane6.Start              =  500;   
Sort.Tun.Lane6.Stop               =  599;   
Sort.Tun.Lane6.CamToGate_mm       =  CamToGate_Offset_mm + 0;;
Sort.Tun.Lane6.GateToNozzle1_mm   =  50;
Sort.Tun.Lane6.GateToNozzle2_mm   =  100;

% Camera to Gate 7
Sort.Tun.Lane7.Start              =  600;   
Sort.Tun.Lane7.Stop               =  699;   
Sort.Tun.Lane7.CamToGate_mm       =  CamToGate_Offset_mm + 0;;
Sort.Tun.Lane7.GateToNozzle1_mm   =  50;
Sort.Tun.Lane7.GateToNozzle2_mm   =  100;

% Camera to Gate 8
Sort.Tun.Lane8.Start              =  700;   
Sort.Tun.Lane8.Stop               =  799;   
Sort.Tun.Lane8.CamToGate_mm       =  CamToGate_Offset_mm + 0;;                 
Sort.Tun.Lane8.GateToNozzle1_mm   =  50;
Sort.Tun.Lane8.GateToNozzle2_mm   =  100;

