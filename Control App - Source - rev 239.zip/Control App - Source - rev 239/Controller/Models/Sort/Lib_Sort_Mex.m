MexBuild('DRS_Parser')
MexBuild('DRS_Sorter')
MexBuild('DRS_SorterSimulation')

MexBuild('DRS_RS232Test')
MexBuild('TestSeedData_fifowrite')

MexBuild('EL6002_fiforead')
MexBuild('EL6002_fiforead_ToLabview')
MexBuild('EL6002_fifowrite')

MexBuild('DT_UINTx3_to_Fifo')
MexBuild('DT_Fifo_to_UINTx3')
