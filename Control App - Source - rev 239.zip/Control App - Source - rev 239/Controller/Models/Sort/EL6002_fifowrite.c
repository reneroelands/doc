/* EL6002_fifowrite.c - non-inlined S-function to perform the read
 * side of an EL6002 terminal */

#define         S_FUNCTION_LEVEL        2
#undef          S_FUNCTION_NAME
#define         S_FUNCTION_NAME         EL6002_fifowrite

#include        <stddef.h>
#include        <stdlib.h>
#include        "simstruc.h"
#include        "Cmd_Routines.h"

#ifdef          MATLAB_MEX_FILE
#include        "mex.h"
#endif

#ifndef         MATLAB_MEX_FILE
//#include        <windows.h>
#endif

/* Input Arguments */
#define NR_ARGS                 (2)
#define ARG_DATA_WIDTH          ssGetSFcnParam(S,0)
#define ARG_FIFO_SIZE           ssGetSFcnParam(S,1)

 // IWork variables. For allowing state change detection and output
#define STATEMACHINE_I_IND   (0)
#define PREV_STATE_RECEIVE_REQUEST_I_IND   (1)
#define PREV_STATE_RECEIVE_ACCEPTED_I_IND   (2)
#define NR_I_WORKS              (3)

#define NR_P_WORKS              (1)
#define FIFO_P_IND              (0)

#define NR_R_WORKS              (0)


#define NR_IN_PORTS             (5)     /* max no of ports */
#define NR_OUT_PORTS            (4)     /* max no of ports */

#define IN_PORT_COUNT             0
#define IN_PORT_DATA              1
#define IN_PORT_INIT_ACCEPTED     2
#define IN_PORT_RECEIVE_REQUEST   3
#define IN_PORT_RESET             4

#define OUT_PORT_SERIAL_OUT         0
#define OUT_PORT_ERROR              1
#define OUT_PORT_INIT_REQUEST       2
#define OUT_PORT_RECEIVE_ACCEPTED   3

#define STATE_DISABLED 0
#define STATE_INITIALIZING 1
#define STATE_READY 2

static char_T msg[256];

static void mdlInitializeSizes(SimStruct *S)
{
    int i;
    int datawidth;
    DTypeId id = SS_UINT32;

    ssSetNumSFcnParams(S, NR_ARGS);
    if (ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S)) {
        sprintf(msg,"Wrong number of input arguments passed.\n%d arguments are expected\n", NR_ARGS);
        ssSetErrorStatus(S,msg);
        return;
    }

    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

    datawidth = (int)mxGetPr( ARG_DATA_WIDTH )[0];

    // port 0 is the fifo data
#ifdef          MATLAB_MEX_FILE
    // First create the custom data type for a fifo pointer
    // The Register call defines the signal as a unique type for Simulink
    id = ssRegisterDataType( S, "serialfifoptr" );
    if(id == INVALID_DTYPE_ID)
        return;
    ssSetDataTypeSize(S, id, 12 );

    // The Alias call tells RTW to insert a typedef into the generated code
    //ssSetDataTypeIdAliasedTo( S, id, SS_UINT32 );
    
    if( ssGetDataTypeZero( S, id ) == NULL )
    {
        serialfifoptr fifozero;
        fifozero.ptrlow = 0;
        fifozero.ptrhigh = 0;
        fifozero.token = 0;
        ssSetDataTypeZero( S, id, &fifozero );
    }
        
    // Neither of these functions can be called from the target side.
#endif

    if( !ssSetNumInputPorts(S, NR_IN_PORTS) )return;
    if( !ssSetNumOutputPorts(S, NR_OUT_PORTS) )return;

    //-------------------  PortNr,                 Width, Type,      Contiguous, DirectFF
    SetInputPortConfig( S, IN_PORT_COUNT,       	        1, SS_UINT8,   1, 1);
    SetInputPortConfig( S, IN_PORT_DATA,            datawidth, SS_UINT8,   1, 1);
    SetInputPortConfig( S, IN_PORT_INIT_ACCEPTED,           1, SS_BOOLEAN, 1, 1);
    SetInputPortConfig( S, IN_PORT_RECEIVE_REQUEST,         1, SS_BOOLEAN, 1, 1);
    SetInputPortConfig( S, IN_PORT_RESET,                   1, SS_BOOLEAN, 1, 1);

    //--------------------  PortNr,                Width, Type
    SetOutputPortConfig( S, OUT_PORT_SERIAL_OUT,       1,     id);
    SetOutputPortConfig( S, OUT_PORT_ERROR,            1,     SS_BOOLEAN);
    SetOutputPortConfig( S, OUT_PORT_INIT_REQUEST,     1,     SS_BOOLEAN);
    SetOutputPortConfig( S, OUT_PORT_RECEIVE_ACCEPTED, 1,     SS_BOOLEAN);

    ssSetNumSampleTimes(S, 1);

    ssSetNumRWork(S, NR_R_WORKS );
    ssSetNumIWork(S, NR_I_WORKS );
    ssSetNumPWork(S, NR_P_WORKS );
    
    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);

    for( i = 0 ; i < NR_ARGS ; i++ )
    {
        ssSetSFcnParamTunable(S,i,0);  /* None of the parameters are tunable */
    }

    ssSetSimStateCompliance(S, DISALLOW_SIM_STATE);

    ssSetOptions(S, SS_OPTION_DISALLOW_CONSTANT_SAMPLE_TIME | SS_OPTION_EXCEPTION_FREE_CODE |
                    SS_OPTION_NONSTANDARD_PORT_WIDTHS );
}

static void mdlInitializeSampleTimes(SimStruct *S)
{
    ssSetModelReferenceSampleTimeInheritanceRule(S, USE_DEFAULT_FOR_DISCRETE_INHERITANCE);
    ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
    ssSetOffsetTime(S, 0, 0.0);
}

#ifdef MATLAB_MEX_FILE
#define MDL_SET_INPUT_PORT_WIDTH
static void mdlSetInputPortWidth( SimStruct *S, int_T port, int_T width )
{
    ssSetInputPortWidth( S, port, width );
}

#define MDL_SET_OUTPUT_PORT_WIDTH
static void mdlSetOutputPortWidth( SimStruct *S, int_T port, int_T width )
{
}
#endif

#define MDL_START
static void mdlStart(SimStruct *S)
{
    int i;
    int fifosize;
    serialfifoptr *OPtr = ssGetOutputPortSignal(S,OUT_PORT_SERIAL_OUT);
    int *fifomem;
//    int type = (int)mxGetPr( TYPE_ARG )[0];
//    int presenceflag = (int)(ssGetNumOutputPorts(S) > 1);
    void **pwork = ssGetPWork(S);

    fifosize = (int)mxGetPr( ARG_FIFO_SIZE )[0];

//    ssSetIWorkValue( S, IWIDTH_I_IND, ssGetInputPortWidth(S, 0));
    fifomem = (int *)malloc( 4*(fifosize + 3) );
    if( fifomem == 0 )
    {
        sprintf(msg, "Can't allocate memory for fifo" );
        ssSetErrorStatus(S,msg);
        return;
    }

    pwork[FIFO_P_IND]  = fifomem;

    // Clear the FIFO data
    for( i = 0 ; i < fifosize+3 ; i++ )
        fifomem[i] = 0;
    fifomem[0] = fifosize;  // Have to communicate this to fiforead

    ssSetIWorkValue( S, STATEMACHINE_I_IND, STATE_DISABLED );
    ssSetIWorkValue( S, PREV_STATE_RECEIVE_REQUEST_I_IND, false );
    ssSetIWorkValue( S, PREV_STATE_RECEIVE_ACCEPTED_I_IND, false );
    
    // Make sure initial state is 0
    boolean_T       *O_RecAcc            = (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_RECEIVE_ACCEPTED);
    boolean_T       *O_InitRequest       = (boolean_T *)ssGetOutputPortRealSignal(S,OUT_PORT_INIT_REQUEST);
    
    *O_RecAcc = false;
    *O_InitRequest = false;
    
#ifdef _WIN64
    OPtr->ptrlow  = (uint32_T)( (uint64_T)fifomem & 0xffffffff );
    OPtr->ptrhigh = (uint32_T)( ((uint64_T)fifomem >> 32) & 0xffffffff );
#else
    OPtr->ptrlow  = (uint32_T)fifomem;
    OPtr->ptrhigh = 0;
#endif
    OPtr->token = (int)'FiFo';
}

static void mdlOutputs(SimStruct *S, int_T tid)
{
    void **pwork = ssGetPWork(S);
    int_T *Fifo  = pwork[FIFO_P_IND];

    int_T fifosize      = Fifo[0];
    int_T *rptr         = &Fifo[1];
    int_T *wptr         = &Fifo[2];
    int_T *data         = &Fifo[3];
    
    uint8_T *IPtrCount        = ssGetInputPortSignal(S,IN_PORT_COUNT);
    uint8_T *IPtrData         = ssGetInputPortSignal(S,IN_PORT_DATA);
    boolean_T *IPtrInitAcc    = ssGetInputPortSignal(S,IN_PORT_INIT_ACCEPTED);
    boolean_T *IPtrRecReq     = ssGetInputPortSignal(S,IN_PORT_RECEIVE_REQUEST);
    boolean_T *IPtrReset      = ssGetInputPortSignal(S,IN_PORT_RESET);

    boolean_T    *OPtrError     = ssGetOutputPortSignal(S,OUT_PORT_ERROR);
    boolean_T    *OPtrInitReq   = ssGetOutputPortSignal(S,OUT_PORT_INIT_REQUEST);
    boolean_T    *OPtrRecAcc    = ssGetOutputPortSignal(S,OUT_PORT_RECEIVE_ACCEPTED);
    
    uint8_T m_State             = ssGetIWorkValue( S, STATEMACHINE_I_IND );
    boolean_T m_Prev_Rec_Req 	= ssGetIWorkValue( S, PREV_STATE_RECEIVE_REQUEST_I_IND );
    boolean_T m_Prev_Rec_Acc 	= ssGetIWorkValue( S, PREV_STATE_RECEIVE_ACCEPTED_I_IND );
        
    if(*IPtrReset == true){
        // Reset
        m_State = STATE_DISABLED;
    }
    
    switch(m_State)
    {
        case STATE_DISABLED:
            
            // Clear fifo
            *wptr = *rptr;

            // Init request to true
            *OPtrInitReq = true;

            // Set receive accepted false
            m_Prev_Rec_Acc = false;
            *OPtrRecAcc = m_Prev_Rec_Acc;

            // Set receive request internal variable equal to input
            m_Prev_Rec_Req = *IPtrRecReq;

            m_State = STATE_INITIALIZING;
            break;

        case STATE_INITIALIZING:
            // Set init request
            *OPtrInitReq = true;
            
            if(*IPtrInitAcc == true){
                // Initialization of terminal finished, 
                // set request zero and continue to next state.
                *OPtrInitReq = false;
                m_State = STATE_READY;
            }
            break;

        case STATE_READY:

            if( m_Prev_Rec_Req != *IPtrRecReq ){ // State change?
                // Set equal to new state
                m_Prev_Rec_Req = *IPtrRecReq;

                // Read data and write to buffer
                boolean_T fErr = true;
                int_T fifocount = 0;
                if (Fifo != NULL)
                {

                    fifocount = (*wptr - *rptr + fifosize) % fifosize;
                    int_T iCount = IPtrCount[0];

                    //-- Check on buffer overrun 
                    if ( iCount >= ( fifosize - fifocount ) )
                    {
                        fErr = true; //-- There's too little space in destination buffer
                    }
                    else
                    {
                        fifocount += iCount;
                        fErr = false;
                        for (int_T iIndex = 0; iIndex < iCount; iIndex++)
                        {
                            data[*wptr] = IPtrData[iIndex];
                            *wptr = (*wptr + 1) % fifosize;
                        }
                    }
                }    
                OPtrError[0] = fErr;

                // Toggle state of receive accepted and write to output
                m_Prev_Rec_Acc = ~m_Prev_Rec_Acc;
                OPtrRecAcc[0] = m_Prev_Rec_Acc;
                
                /*
                 * This doesn't work...
                 *
                 * if(m_Prev_Rec_Acc == true){
                    OPtrRecAcc[0] = true;
                }else{
                    OPtrRecAcc[0] = false;
                } */      
            }                           
            break;
    }
    
    // Save variables for next iteration
    ssSetIWorkValue( S, STATEMACHINE_I_IND, m_State );
    ssSetIWorkValue( S, PREV_STATE_RECEIVE_REQUEST_I_IND, m_Prev_Rec_Req );
    ssSetIWorkValue( S, PREV_STATE_RECEIVE_ACCEPTED_I_IND, m_Prev_Rec_Acc );
    
}

static void mdlTerminate(SimStruct *S)
{
    int_T *Fifo = (int_T *)ssGetPWorkValue( S, FIFO_P_IND );
    if( Fifo != 0 )
        free( Fifo );
}

#ifdef MATLAB_MEX_FILE  /* Is this file being compiled as a MEX-file? */
#include "simulink.c"   /* Mex glue */
#else
#include "cg_sfun.h"    /* Code generation glue */
#endif
