disp('InOutputs Simulation Preload')

% Timing of pneumatic functions (default = 0.9 s)
InOutputs.Sim.FilterActuator.StartDelay = 0.1;
InOutputs.Sim.FilterActuator.FinishDelay = 0.8;
InOutputs.Sim.EmergencyStop.StartDelay = 0.1;
InOutputs.Sim.EmergencyStop.FinishDelay = 0.8;
InOutputs.Sim.VacuumPump.StartDelay = 0.1;
InOutputs.Sim.VacuumPump.FinishDelay = 0.8;
InOutputs.Sim.XRayCamera.StartDelay = 0.1;
InOutputs.Sim.XRayCamera.FinishDelay = 0.8;
InOutputs.Sim.BSA.StartDelay = 0.1;
InOutputs.Sim.BSA.FinishDelay = 0.8;
InOutputs.Sim.SystemGas.StartDelay = 0.1;
InOutputs.Sim.SystemGas.FinishDelay = 0.8;
InOutputs.Sim.WeissVacuum.StartDelay = 0.1;
InOutputs.Sim.WeissVacuum.FinishDelay = 0.8;
