%-------------------------------------------------------------------------
% InOutputs Init
%-------------------------------------------------------------------------
InOutputs.Name = 'InOut';                            %required! Has to be the same as object name.
InOutputs.Const.Model.Version.Major    = 1;          %maybe try to integrate SVN directory revision number here??
InOutputs.Const.Model.Version.Minor    = 0;

disp(sprintf('InOutputs Constants Preload. Version %d.%d', InOutputs.Const.Model.Version.Major, InOutputs.Const.Model.Version.Minor))

InOutputs.Const.UnitID = 5;

%-------------------------------------------------------------------------
% Sampletime
%-------------------------------------------------------------------------
InOutputs.Const.Ts      = Ts;                        % Samplefrequency

%-----------------------------------------------------------------------
% Mode Commands
%-----------------------------------------------------------------------
InOutputs.Const.Mlc.ModeCmd.NoCommand                     = 0;
InOutputs.Const.Mlc.ModeCmd.Reset                         = 1;
InOutputs.Const.Mlc.ModeCmd.SetBSAUp                      = 50;
InOutputs.Const.Mlc.ModeCmd.SetBSADown                    = 51;
InOutputs.Const.Mlc.ModeCmd.SetVacuumGeneratorTrayHndlr   = 53;
InOutputs.Const.Mlc.ModeCmd.SetSystemGas                  = 54;
InOutputs.Const.Mlc.ModeCmd.SetXRayCameraUp               = 55;
InOutputs.Const.Mlc.ModeCmd.SetXRayCameraDown             = 56;
InOutputs.Const.Mlc.ModeCmd.SetFeeder                     = 57;
InOutputs.Const.Mlc.ModeCmd.SetHopper                     = 58;
InOutputs.Const.Mlc.ModeCmd.SetLightInspectionCamera      = 59;
InOutputs.Const.Mlc.ModeCmd.SetVacuumPump                 = 60;
InOutputs.Const.Mlc.ModeCmd.SetCyclonGas                  = 62;
InOutputs.Const.Mlc.ModeCmd.SetReturnCleanGasOn           = 63;
InOutputs.Const.Mlc.ModeCmd.SetFilterActuatorActive       = 64;
InOutputs.Const.Mlc.ModeCmd.SetFilterActuatorInactive     = 65;
InOutputs.Const.Mlc.ModeCmd.SetVacuumPressureSetpoint     = 66;
InOutputs.Const.Mlc.ModeCmd.SetLineVacuumOn               = 67;

% Enum for last command ID. This to prevent endless updates of the
% stateflow model each time a command is added.
InOutputs.Const.Mlc.ModeCmd.FirstCommand                  = 50;
InOutputs.Const.Mlc.ModeCmd.LastCommand                   = max(structfun(@(x)max(x(:)),InOutputs.Const.Mlc.ModeCmd));

%-----------------------------------------------------------------------
% Status Feedback 
%-----------------------------------------------------------------------
InOutputs.Const.Mlc.Sts.NOK                   = 0;
InOutputs.Const.Mlc.Sts.Disabled              = 1;                % = Reset
InOutputs.Const.Mlc.Sts.Enabled               = 2;

%-----------------------------------------------------------------------
% Module ErrorID's
%-----------------------------------------------------------------------
InOutputs.Const.Err.Base                      = InOutputs.Const.UnitID * 100;
InOutputs.Const.Err.NoError                   = 0;   
InOutputs.Const.Err.NotAccepted               = 1;
InOutputs.Const.Err.ParamOORange              = 2;
InOutputs.Const.Err.EthercatError             = 3;

% IO Terminals Errors
InOutputs.Const.Err.TerminalErrorMassFlow   = 4;
InOutputs.Const.Err.TerminalSortVacuum      = 5;
InOutputs.Const.Err.TerminalEL9110          = 6;
InOutputs.Const.Err.TerminalEL1018_1        = 7;
InOutputs.Const.Err.TerminalEL1018_2        = 8;
InOutputs.Const.Err.TerminalEL3102          = 9;
InOutputs.Const.Err.TerminalEL2024_1        = 10;
InOutputs.Const.Err.TerminalEL2024_2        = 11;
InOutputs.Const.Err.TerminalEL9110          = 14;
InOutputs.Const.Err.TerminalEL2024_3        = 12;
InOutputs.Const.Err.TerminalEL2024_4        = 13;
InOutputs.Const.Err.TerminalEL4011          = 15;
InOutputs.Const.Err.TerminalEL2612_1        = 16;
InOutputs.Const.Err.TerminalEL2612_2        = 17;


