Com : Serial communication host
Sbc : Seed Belt Control