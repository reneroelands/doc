%---------------------------------------------------------------------------------------------------------------
% CCM, Center for Concepts in Mechatronics
%---------------------------------------------------------------------------------------------------------------
% Sbc : Seed Belt Control
%
% Initializes control tuning parameters
%
% Seed belt control defines a stepper control based on frequency setpoint.
% This control is suited for accurate velocity control.
% It can not be used for position control. This would lead to "servo-like" settling in absolute steps.
% 
% RPul,HKup,  2009-02-20     : Version XSSCC1
% ENuij,      2009-12-01     : Rewritten in new SAXCS template.
%
%---------------------------------------------------------------------------------------------------------------

disp(sprintf('Sbc Control Preload --> Demonstrator.'))

%-----------------------------------------------------------------------
% Tuning parameters
%-----------------------------------------------------------------------

% Rotation unit, SI units in rad, rad/s, rad/s^2 etc.

Sbc.Tun.PosMin_m       =   -10.00;    % Minimum Position parameter  [SI]
Sbc.Tun.PosMax_m   	   =    10.00;    % Maximum Position parameter  [SI]
Sbc.Tun.VelMin_m_s	   =   -0.101;    % Minimum Velocity            [SI
Sbc.Tun.VelDef_m_s 	   =    0.060;    % Default Velocity            [SI] 
Sbc.Tun.VelMax_m_s     =    0.100;    % Maximum Velocity            [SI]
Sbc.Tun.VelOvr_m_s     =    1.000;    % Overspeed protection        [SI]
Sbc.Tun.TimeOut_s      =  60.000;    % Generic timeout             [s]
Sbc.Tun.AccMax_m_s2    =   1.000;    % Acceleration                [SI]
Sbc.Tun.JerkMax_m_s3   =  10.000;    % Jerk                        [SI]
Sbc.Tun.CtrlDiffMax    =   1e-3;     % Max Control tracking error  [SI]
Sbc.Tun.CtrlDiffWarn   =   5e-4;     % Control tracking warning
                                            % level (not locked)          [SI]
Sbc.Tun.Modulo         =  0*2*pi*30e-3/2;  %2*pi*CameraTrigger.TotalRatio;       % Modulo                      [SI] 
                                            % Modulo=0 disables modulo function   

Sbc.Tun.HomePos_m       =    0;      % Home sensor position        [SI]
Sbc.Tun.LimitPosLeft_m  =    0;      % Lower Limit position        [SI]
Sbc.Tun.LimitPosRight_m =    0;      % Upper Limit position        [SI]

%-----------------------------------------------------------------------
% Scaling
%-----------------------------------------------------------------------

Sbc.Tun.JogSlewRate           = 0.1;                    % Jogging Slew rate in [Nm/s]

Sbc.Tun.FF_Kfx                =  1.000;                 % Position FeedForward
Sbc.Tun.FF_Kfc                =  0.000;                 % Static friction FeedForward
Sbc.Tun.FF_Kfv                =  0.000;                 % Viscous friction FeedForward
Sbc.Tun.FF_Kfa                =  0.0;                   % Acceleration feedforward fine-tuning parameter

Sbc.Tun.GearRatio             = 1/1;                    % [rad/rad]

% Added belt thickness for improved accuracy
Sbc.Tun.BeltPulleyRatio       = 30.1e-3/2;              % Radius DriveRoll [m]
% Sbc.Tun.TotalRatio            = Sbc.Tun.GearRatio * Sbc.Tun.BeltPulleyRatio; %[m/rad]

Sbc.Tun.StepperPPrev          = 125000;                                         % Pulses/rev

% Sbc.Tun.StepperSclng          = (Sbc.Tun.StepperPPrev/(2*pi*Sbc.Tun.TotalRatio));   % Pulses/m

Sbc.Tun.mot_pulsewidth        = 5e-6/12.5e-9;           %stepper motor pulsewidth in 12.5ns counts
                                                        %(minimal: 2 us = 160,
                                                        % typical: 5 us = 400)

Sbc.Tun.BaseFrequency         = 150000; % Maximum frequency of stepper can not be calculated from info in this file, tehrefore assume <134kHz                                                       
% Sbc.Tun.VelocityToPD          = Sbc.Tun.StepperSclng * 32767 / Sbc.Tun.BaseFrequency; % See datasheet of EL252X for output frequency