%---------------------------------------------------------------------------------------------------------------
% CCM, Center for Concepts in Mechatronics
%---------------------------------------------------------------------------------------------------------------
% Sbc : Seed Belt Control
%
% Initializes constant definitions
%
% Seed belt control defines a stepper control based on frequency setpoint.
% This control is suited for accurate velocity control.
% It can not be used for position control. This would lead to "servo-like" settling in absolute steps.
% 
% RPul,HKup,  2009-02-20     : Version XSSCC1
% ENuij,      2009-12-01     : Rewritten in new SAXCS template.
%
%---------------------------------------------------------------------------------------------------------------
Sbc.Name = 'Sbc'; %required! Has to be the same as object name.
Sbc.Const.Model.Version.Major    = 1;  %maybe try to integrate SVN directory revision number here??
Sbc.Const.Model.Version.Minor    = 0;
disp(sprintf('Sbc Constants Preload. Version %d.%d', Sbc.Const.Model.Version.Major, Sbc.Const.Model.Version.Minor))


%-------------------------------------------------------------------------
% UNIT ID
%-------------------------------------------------------------------------

Sbc.Const.UnitID = 1;

%-------------------------------------------------------------------------
% Sampletime
%-------------------------------------------------------------------------

Sbc.Const.Ts      = Ts;                          % Samplefrequency for BeltControl

Sbc.Const.Mlc.TrjCmd.NoCommand           = 0;    % No Sbcmand
Sbc.Const.Mlc.TrjCmd.Reset               = 1;    % Reset all axes to initial state
Sbc.Const.Mlc.TrjCmd.SetSPGParams        = 2;    % SetSPGParams(AxisID MaxVel MaxAcc MaxJer 0)
Sbc.Const.Mlc.TrjCmd.StartRotating       = 3;    % Start Rotating at MaxVel
Sbc.Const.Mlc.TrjCmd.StopRotating        = 4;    % Stop Rotating
Sbc.Const.Mlc.TrjCmd.Calibrate           = 5;    % [NOT USED HERE] Start Calibration routine
Sbc.Const.Mlc.TrjCmd.MoveAbsolute        = 7;    % [NOT USED HERE] Move to absolute position (starting from current position)
Sbc.Const.Mlc.TrjCmd.MoveRelative        = 8;    % Relative movement with distance PosStep [Param1] from current position
Sbc.Const.Mlc.TrjCmd.StartCycling        = 9;    % [NOT USED HERE] Start cycling (relative) between startposition Param1] to endposition [Param2]
Sbc.Const.Mlc.TrjCmd.StopCycling         = 10;   % [NOT USED HERE] Stop cycling


%-----------------------------------------------------------------------
% Rotation Unit Status
%-----------------------------------------------------------------------

Sbc.Const.Slc.Rot.Cmd.Mode.ROF          = 1;   % Rotation on
Sbc.Const.Slc.Rot.Cmd.Mode.RON          = 2;   % Rotation off

Sbc.Const.Slc.Rot.Sts.Rotating      = 2;   % Rotating but no lock

%-----------------------------------------------------------------------
% Translation Unit Mode Commands and Status
%-----------------------------------------------------------------------

Sbc.Const.Mlc.ModeCmd.TOF          = 1;   % Motion axis disabled (after Reset)
Sbc.Const.Mlc.ModeCmd.TON          = 2;   % Motion axis enabled 
Sbc.Const.Mlc.ModeCmd.MA           = 3;   % Move Absolute to new position
Sbc.Const.Mlc.ModeCmd.RA           = 4;   % Move relative to new position
Sbc.Const.Mlc.ModeCmd.CYC          = 5;   % Cycle relative between start and end position
Sbc.Const.Mlc.ModeCmd.CAL          = 6;   % Calibration mode
%only in SLC layer: (??)
Sbc.Const.Mlc.ModeCmd.ROF          = 7;   % Rotate at constant speed disabled
Sbc.Const.Mlc.ModeCmd.RON          = 8;   % Rotate at constant speed enabled 

Sbc.Const.Mlc.Sts.Idle              = 1;   % Motion axis disabled (uncalibrated)
Sbc.Const.Mlc.Sts.Calibrating       = 2;   % Busy calibrating
Sbc.Const.Mlc.Sts.Calibrated        = 3;   % Calibrated succesfully
Sbc.Const.Mlc.Sts.MoveBusy          = 4;   % Moving to new random endposition
Sbc.Const.Mlc.Sts.MoveReady         = 5;   % Arrived at new random endposition
Sbc.Const.Mlc.Sts.Cycling           = 6;   % Cycling between start and end position
Sbc.Const.Mlc.Sts.Rotating          = 7;   % Rotating at constant speed

%-----------------------------------------------------------------------
% Translation Unit ErrorID's
%-----------------------------------------------------------------------

Sbc.Const.Err.Base          = Sbc.Const.UnitID * 100;             % Corresponding to UnitType 2 in Error Code
Sbc.Const.Err.NoError       = 0;
Sbc.Const.Err.NotAccepted   = 1;
Sbc.Const.Err.TimeOut       = 2;
Sbc.Const.Err.ParamOORange  = 3;
Sbc.Const.Err.EStopDetected = 4;
Sbc.Const.Err.Arbitrage     = 5;        % not used
Sbc.Const.Err.TerminalError = 6;        
Sbc.Const.Err.TerminalErrorEL2124 = 7;        


