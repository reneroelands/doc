classdef(Enumeration) Steering_Mlc_ModeCmd_Enums < Simulink.IntEnumType
% Note: syntax with (Enumeration) required for ML version 2008
    %   Detailed explanation goes here
    
    enumeration
        NoCommand(0);
        Reset(1);
        Enable(2)
        Disable(3);
        Count(4);
    end
    
    
end