%-------------------------------------------------------------------------
% Steering init
%-------------------------------------------------------------------------
Steering.Name = 'Steering';                         %required! Has to be the same as object name.
Steering.Const.Model.Version.Major    = 1;          %maybe try to integrate SVN directory revision number here??
Steering.Const.Model.Version.Minor    = 0;

disp(sprintf('Steering Constants Preload. Version %d.%d', Steering.Const.Model.Version.Major, Steering.Const.Model.Version.Minor))

Steering.Const.UnitID = 4;

%-------------------------------------------------------------------------
% Sampletime
%-------------------------------------------------------------------------
Steering.Const.Ts      = Ts;                        % Samplefrequency

%-----------------------------------------------------------------------
% Mode Commands
%-----------------------------------------------------------------------
Steering.Const.Mlc.ModeCmd.NoCommand       = 0;
Steering.Const.Mlc.ModeCmd.Reset           = 1;
Steering.Const.Mlc.ModeCmd.Enable          = 40;
Steering.Const.Mlc.ModeCmd.Disable         = 41;

%-----------------------------------------------------------------------
% Status Feedback 
%-----------------------------------------------------------------------
Steering.Const.Mlc.Sts.NOK                  = 0;
Steering.Const.Mlc.Sts.Disabled             = 1;
Steering.Const.Mlc.Sts.Enabled              = 2;
Steering.Const.Mlc.Sts.Homing               = 3;

Steering.Const.Slc.ModeCmd.NoCommand        = 0;
Steering.Const.Slc.ModeCmd.Disable          = 1;
Steering.Const.Slc.ModeCmd.Home             = 2;
Steering.Const.Slc.ModeCmd.Enable           = 3;

Steering.Const.Slc.Sts.NoStatus             = 0;
Steering.Const.Slc.Sts.Busy                 = 1;
Steering.Const.Slc.Sts.Finished             = 2;

%-----------------------------------------------------------------------
% Module ErrorID's
%-----------------------------------------------------------------------
Steering.Const.Err.Base                         = Steering.Const.UnitID * 100;
Steering.Const.Err.NoError                      = 0;   
Steering.Const.Err.NotAccepted                  = 1;
Steering.Const.Err.BeltOutOfRange               = 2;
Steering.Const.Err.ActOutOfRange                = 3;
Steering.Const.Err.EthercatError                = 4;
Steering.Const.Err.EStopPressed                 = 5;
Steering.Const.Err.AssyRetracted                = 6;
Steering.Const.Err.TerminalStatusErrorEL2521    = 7;
Steering.Const.Err.TerminalErrorSensor          = 8;


