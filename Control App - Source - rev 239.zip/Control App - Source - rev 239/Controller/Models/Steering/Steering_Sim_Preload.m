disp('Steering Simulation Preload')

% Stability of frequency oscillator
Steering.Sim.HomePos_deg = Steering.Tun.HomePos_deg;
Steering.Sim.SteeringGain = 5;
