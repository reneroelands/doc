%---------------------------------------------------------------------------------------------------------------
% CCM, Center for Concepts in Mechatronics
%---------------------------------------------------------------------------------------------------------------
% Steering_Tun_Preload
%
% Initializes tuning parameters
%
%---------------------------------------------------------------------------------------------------------------

disp(sprintf('Steering Tuning Preload.'))

%-----------------------------------------------------------------------
% Tuning parameters
%-----------------------------------------------------------------------
% Rotation unit: 
% Belt position: [m] 
% Motor angle  : [deg]

Steering.Tun.Modulo                  = 0;                   % Modulo=0 disables modulo function   
Steering.Tun.TimeOut_s               = 60.000;              % Generic timeout             [s]
Steering.Tun.HomeVelocity_deg_s      = 90;                  % home velocity
Steering.Tun.BeltSteeringFadein_m_s  = 1e-5;                % velocity for fading-in the belt setpoint. Used when system starts with large belt offset.

% Degrees per step
Steering.Tun.MicrostepFactor         = 128;                 % microstepping factor
Steering.Tun.MicrostepAngle          = 1.8;                 % 1.8 degree step angle
Steering.Tun.StepperSclng            = Steering.Tun.MicrostepFactor / Steering.Tun.MicrostepAngle;

% Belt ADC count to SI, calibrated onsite
Steering.Tun.corrgain = 0.000000597;
Steering.Tun.corroffs = 0.0002198;

% Belt limits
Steering.Tun.BeltSetpoint            = 0.005; %[m]
Steering.Tun.BeltLimitPos_m          = Steering.Tun.BeltSetpoint + 0.003;              % Lower Limit position belt   [m]
Steering.Tun.BeltLimitNeg_m          = Steering.Tun.BeltSetpoint - 0.003;              % Upper Limit position belt   [m]

% Actuators limit s
Steering.Tun.ActLimitPos_deg         = +150;                % Lower Limit position actuator [deg]
Steering.Tun.ActLimitNeg_deg         = -150;                % Upper Limit position actuator [deg]
Steering.Tun.mot_pulsewidth          = 5e-6/12.5e-9;        % Stepper motor pulsewidth in 12.5ns counts
Steering.Tun.HomePos_deg             = 0.000;               % Home sensor position          [deg]

Steering.Tun.MinBeltVelocity_m_s     = 25e-3;               % Below 20 mm/s no steering as belt will not respond to steering. Integrator wind-up.

% Controller tuning. Controller inverted?
Steering.Tun.Kp                      = 10000;
Steering.Tun.Ki                      = 200;

Steering.Tun.BaseFrequency         = 150000; % Maximum frequency of stepper can not be calculated from info in this file, tehrefore assume <134kHz                                                       
Steering.Tun.VelocityToPD          = Steering.Tun.StepperSclng * 32767 / Steering.Tun.BaseFrequency; % See datasheet of EL252X for output frequency