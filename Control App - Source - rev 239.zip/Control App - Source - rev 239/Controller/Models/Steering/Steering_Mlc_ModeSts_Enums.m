classdef(Enumeration) Steering_Mlc_ModeSts_Enums < Simulink.IntEnumType
% Note: syntax with (Enumeration) required for ML version 2008
    %   Detailed explanation goes here
    
    enumeration
        Nok(0);
        Idle(1);
        Homing(2);
        Enabled(3);
        Count(4);
    end
end