% Tracescript for DRS sorter
% Analyse trace data
% CCM, Center for Concepts in Mechatronics
% Last Modified by JHER/ENUIJ on 2010-06-03
%------------------------------------------------------------------

% Logging data from target via .m file
% Be sure that target is running

TraceTime = 5; % [s]

%------------------------------------------------------------------
% Define measurement parameters
%------------------------------------------------------------------
TraceLength=TraceTime/Ts;   % Number of measurement points
TraceDecimation=1;          % Every nth sample

%**************************************************************************

if strcmp(xpctargetping,'success')
    
    Target=xpctarget.xpc;  % Define Target
    
    
    
    %*********************************************************************
    % Remove all host scopes and create 1 new
    %*********************************************************************
    allscopes = getscope(Target);
    
    for j=1:length(allscopes)
        ScopeID=allscopes(j).ScopeID;
        if ScopeID == 255
            Target.remscope(255);             %Remove Scope
            allscopes = getscope(Target);   %Redefine (one scope removed)
        end
    end
    
    %*********************************************************************
    % Define Host scope(s)
    %*********************************************************************
    
    TraceScope = Target.addscope('host',255);
    
    %******************************************************************
    % example commands
    %******************************************************************
    
    %         Sgnl1=Target.getsignalid(['Diagnostics and Validation/Axis',UnitNumber,'/SC_Sys_NoiseInpt']); % Measured Noise
    %         Sgnl2=Target.getsignalid(['Diagnostics and Validation/Axis',UnitNumber,'/SC_Sys_CtrlInpt']);  % Controller Input
    %         Sgnl3=Target.getsignalid(['Diagnostics and Validation/Axis',UnitNumber,'/SC_Sys_CtrlOtpt']);  % Controller Output
    %         Sgnl4=Target.getsignalid(['Diagnostics and Validation/Axis',UnitNumber,'/SC_Sys_PlantInpt']); % Plant Input
    %         Sgnl5=Target.getsignalid(['Diagnostics and Validation/Axis',UnitNumber,'/SC_Sys_PlantOtpt']); % PLant Output
    %
    
    % select in simulink the block output that you want to measure.
    % use "gcb" to find the address and remove the model name.
    %add below and add a variable name for the workspace.
    
    signals  = { %<location>,<trace name>
        {'Models/Sort/Slc/SeedData_TriggerCount','SeedData_TriggerCount'};
        {'Models/Sort/Slc/SeedData_PValue','SeedData_PValue'};
        {'Models/Sort/Slc/SeedData_Status','SeedData_Status'};
        {'Models/Sort/Slc/SeedData_Valid1','SeedData_Valid1'};
        {'Models/Sort/Slc/SeedData_Valid2','SeedData_Valid2'};
        {'Models/Sort/Slc/SeedData_Valid3','SeedData_Valid3'};
        {'Models/Sort/Slc/SeedData_Valid4','SeedData_Valid4'};
        {'Models/Sort/Slc/SeedData_Valid5','SeedData_Valid5'};
        {'Models/Sort/Slc/SeedData_Valid6','SeedData_Valid6'};
        {'Models/Sort/Slc/SeedData_Valid7','SeedData_Valid7'};
        {'Models/Sort/Slc/SeedData_Valid8','SeedData_Valid8'};
        };
    
    
    %******************************************************************
    % Define Host scope
    %******************************************************************
    for i=1:length(signals)
        
        ID=Target.getsignalid(char(signals{i}(1))); %retrieve ID
        if (ID <= 0)
            fprintf('ID not found for %s/n',signals{i}(1));
            return;
        end;
        TraceScope.addsignal(ID);
        TraceScope.triggermode = 'software'; %'FreeRun'
        TraceScope.NumSamples = TraceLength;
        TraceScope.Decimation = TraceDecimation;
    end;
    
    TraceScope.start;
    fprintf(1,['Measurement started, Please wait!\n']);
    xpctargetping; % Ping target to ensure connection before data transfer
    TraceScope.trigger;
    fprintf(1,'Processing starts after %2.0f seconds!\n',TraceLength*TraceDecimation*Ts+1);
    
    %******************************************************************
    % Measurement started. Waiting...
    %******************************************************************
    
    pause((TraceLength*TraceDecimation*Ts+1));
    
    TraceScope.stop;
    
    xpctargetping; % Ping target to ensure connection before data transfer
    
    
    % Stop target scopes to speed up communication
    for j=1:length(allscopes)
        ScopeID=allscopes(j).ScopeID;
        sc = Target.getscope(ScopeID);
        sc.stop;
    end
    
    
    
    fprintf(1,'Getting data from target, Please wait!\n');
    TraceTime=TraceScope.time(:);
    TraceTime=TraceTime-TraceTime(1);%remove T0.
    TraceData = TraceScope.data;
    
    for i=1:length(signals)
        assignin('base','tmp_',TraceData(:,i));
        evalin('base',['trc.' char(signals{i}(2)) '=tmp_;']);
    end;
    
    fprintf(1,'Data retrieved!\n');
    
    
    % Remove host scope
    Target.remscope(255);
    
    % Restart target scopes
    for j=1:length(allscopes)
        ScopeID=allscopes(j).ScopeID;
        sc = Target.getscope(ScopeID);
        sc.start;
    end
    
    %**************************************************************************
    
else
    fprintf(1,'No connection found!\n')
    fprintf(1,'Make sure xPC-Target is running!\n')
end % Measurement


clear TraceData;
clear TraceDecimation;
clear TraceLength;
clear TraceScope;

%*************************************************************************%
%*************************************************************************%
%*************************************************************************%
%Plot results
%use "whos Trace*" to find all plottable signals.



%---> data must be in rows!!!!


%do dummy data
% clear all
% SeedData_TriggerCount=[1 2 3 4 5 6 7 8 9 10 1 2 3 4 5 6 7 8 9 10];
% SeedData_PValue=[0 0 0 0 0 0 0 0 0 0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 0.10];
% SeedData_Status=rand(1,20);
% SeedData_Valid1=[0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1 0];
% SeedData_Valid2=[0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0 1];
% SeedData_Valid3=[0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0 0];
% SeedData_Valid4=[0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0 0];
% SeedData_Valid5=[0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0 0];
% SeedData_Valid6=[0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0 0];
% SeedData_Valid7=[0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0 0];
% SeedData_Valid8=[0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0 0];

DataIndex_Lane=find((trc.SeedData_Valid1==1)|(trc.SeedData_Valid2==1)|(trc.SeedData_Valid3==1)|(trc.SeedData_Valid4==1)|(trc.SeedData_Valid5==1)|(trc.SeedData_Valid6==1)|(trc.SeedData_Valid7==1)|(trc.SeedData_Valid8==1));
% DataIndex_Lane{2}=find(SeedData_Valid2==1);
% DataIndex_Lane{3}=find(SeedData_Valid3==1);
% DataIndex_Lane{4}=find(SeedData_Valid4==1);
% DataIndex_Lane{5}=find(SeedData_Valid5==1);
% DataIndex_Lane{6}=find(SeedData_Valid6==1);
% DataIndex_Lane{7}=find(SeedData_Valid7==1);
% DataIndex_Lane{8}=find(SeedData_Valid8==1);

%determine screen settings. Keep left side free for start-menu.
scrsz = get(0,'ScreenSize');
FigurePos=[80 10 scrsz(3)-100 scrsz(4)-100]

fh=figure('Position',FigurePos) %from left lower corner

TableData=[];
row=1;
for i=1:length(DataIndex_Lane)
    index=DataIndex_Lane(i)
    TableData{row,1}=trc.SeedData_TriggerCount(index);
    TableData{row,2}=trc.SeedData_PValue(index);
    TableData{row,3}=trc.SeedData_Status(index);
    if trc.SeedData_Valid1(index)==1
        TableData{row,4}=char('X')
    end;
    if trc.SeedData_Valid2(index)==1
        TableData{row,5}='X'
    end;
    if trc.SeedData_Valid3(index)==1
        TableData{row,6}='X'
    end;
    if trc.SeedData_Valid4(index)==1
        TableData{row,7}='X'
    end;
    if trc.SeedData_Valid5(index)==1
        TableData{row,8}='X'
    end;
    if trc.SeedData_Valid6(index)==1
        TableData{row,9}='X'
    end;
    if trc.SeedData_Valid7(index)==1
        TableData{row,10}='X'
    end;
    if trc.SeedData_Valid8(index)==1
        TableData{row,11}='X'
    end;
    row=row+1;
end;

TableColNames={'TrigCnt','PValue','Status','Chan1','Chan2','Chan3','Chan4','Chan5','Chan6','Chan7','Chan8'};
colnames = {'X-Data', 'Y-Data', 'Z-Data'};
t = uitable(fh, 'Data', TableData, 'ColumnName', TableColNames, 'Units','normalized','Position',[0 0 1.0 1.0]);
%t = uitable(fh, 'Data', TableData, 'ColumnName', TableColNames, 'Position', TablePos);


% figure;
%plot(TraceTime, TraceSbcVelAct);
% plot(TraceTime, Sort1Debug);


