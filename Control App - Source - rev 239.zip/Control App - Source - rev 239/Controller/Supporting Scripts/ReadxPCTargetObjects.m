% Get current signal or parameter ID and Value (if possible)

%Try to connect to target
if strcmp(xpctargetping, 'success')
    
    Target              =   xpctarget.xpc;
    ApplicationRunning  =   Target.Application;
    
    disp(['Target defined! Application running: ',ApplicationRunning])
    fprintf(1,'\n');
    
else
    disp('Target connection error!')
    return
end

try
    % Read current block path
    BlockPath = gcb;
    
    % Substract modelname from BlockPath (=ApplicationRunning)
    BlockPath = BlockPath(length(ApplicationRunning)+2:end);
catch
    disp('Could not find Block path!')
end

try
    % Read Blocks signal
    SignalID = Target.getsignalid(BlockPath);
    if ~isempty(SignalID)
        SignalValue     =   Target.getsignal(SignalID);
        %Show output
        disp(['SignalName:      ',BlockPath])
        disp(['SignalID:        ',num2str(SignalID)])
        disp(['SignalValue:     ',num2str(SignalValue)])
        fprintf(1,'\n');
    end
catch
    disp('Error finding SignalID!')
end

try
    % Read Blocks parameter value
    KnownParameterTypes = {'Value', 'Gain','UpperLimit','LowerLimit',...
        'RisingSlewLimit','FallingSlewLimit','InitialCondition','Threshold'};
    for i = 1:length(KnownParameterTypes)
        ParameterType   = KnownParameterTypes{i};
        ParameterID     = Target.getparamid(BlockPath,ParameterType);
        
        if ~isempty(ParameterID)
            ParameterValue  = Target.getparam(ParameterID);
            %Show output
            disp(['ParameterName:   ',BlockPath])
            disp(['ParameterID:     ',num2str(ParameterID)])
            disp(['ParameterType:   ',ParameterType])
            disp(['ParameterValue:  ',num2str(ParameterValue)])
            fprintf(1,'\n');
        end
    end
    
catch
    disp('Error finding Parameter!')
end