
Valves.Enable={ 'Hardware/HIL/SortHw/HwCmdNozzle1_Bypass/Enable';
                'Hardware/HIL/SortHw/HwCmdNozzle2_Bypass/Enable';
                'Hardware/HIL/SortHw/HwCmdNozzle3_Bypass/Enable';
                'Hardware/HIL/SortHw/HwCmdNozzle4_Bypass/Enable';
                'Hardware/HIL/SortHw/HwCmdNozzle5_Bypass/Enable';
                'Hardware/HIL/SortHw/HwCmdNozzle6_Bypass/Enable';
                'Hardware/HIL/SortHw/HwCmdNozzle7_Bypass/Enable';
                'Hardware/HIL/SortHw/HwCmdNozzle8_Bypass/Enable';
                }
Valves.Value ={ 'Hardware/HIL/SortHw/HwCmdNozzle1_Bypass/Value';
                'Hardware/HIL/SortHw/HwCmdNozzle2_Bypass/Value';
                'Hardware/HIL/SortHw/HwCmdNozzle3_Bypass/Value';
                'Hardware/HIL/SortHw/HwCmdNozzle4_Bypass/Value';
                'Hardware/HIL/SortHw/HwCmdNozzle5_Bypass/Value';
                'Hardware/HIL/SortHw/HwCmdNozzle6_Bypass/Value';
                'Hardware/HIL/SortHw/HwCmdNozzle7_Bypass/Value';
                'Hardware/HIL/SortHw/HwCmdNozzle8_Bypass/Value';
                }            

VOFF=0;
VON=1;

try
    %defined state where bypass is active and valves are off.
    for i=1:8
        ParamID=Target.getparamid(Valves.Value{i});
        Target.setparam(ParamID,VOFF);
        ParamID=Target.getparamid(Valves.Enable{i});
        Target.setparam(ParamID,1);
    end;
    
    %loop a sequence
    while 1
        pause(10); %wait before starting. Indication that the 1st valve will follow and 8 have to "sound"
        %activate valve for 1 second
        ParamID=Target.getparamid(Valves.Value{i});
        Target.setparam(ParamID,VON);
        ParamID=Target.getparamid(Valves.Enable{i});
        Target.setparam(ParamID,1);
        
        pause(1);
        %deactivate
        ParamID=Target.getparamid(Valves.Value{i});
        Target.setparam(ParamID,VOFF);
        
        pause(2); %2 seconds between valves
    end;
    
catch
    %on user intervention or error reset runtime settings.
    for i=1:8
        %defined state where bypass is active and valves are off.
        ParamID=Target.getparamid(Valves.Value{i});
        Target.setparam(ParamID,VOFF);
        ParamID=Target.getparamid(Valves.Enable{i});
        Target.setparam(ParamID,0);
    end;
end;
