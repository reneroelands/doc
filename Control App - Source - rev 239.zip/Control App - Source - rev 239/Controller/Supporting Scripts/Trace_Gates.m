% Tracescript for DRS sorter
% Analyse trace data
% CCM, Center for Concepts in Mechatronics
% Last Modified by JHER/ENUIJ on 2010-06-03
%------------------------------------------------------------------

% Logging data from target via .m file
% Be sure that target is running

TraceTime = 5; % [s]

%------------------------------------------------------------------
% Define measurement parameters
%------------------------------------------------------------------
TraceLength=TraceTime/Ts;   % Number of measurement points
TraceDecimation=1;          % Every nth sample

%**************************************************************************

if strcmp(xpctargetping,'success')
    
    Target=xpctarget.xpc;  % Define Target
    
    
    
    %*********************************************************************
    % Remove all host scopes and create 1 new
    %*********************************************************************
    allscopes = getscope(Target);
    
    for j=1:length(allscopes)
        ScopeID=allscopes(j).ScopeID;
        if ScopeID == 255
            Target.remscope(255);             %Remove Scope
            allscopes = getscope(Target);   %Redefine (one scope removed)
        end
    end
    
    %*********************************************************************
    % Define Host scope(s)
    %*********************************************************************
    
    TraceScope = Target.addscope('host',255);
    
    %******************************************************************
    % example commands
    %******************************************************************
    
    %         Sgnl1=Target.getsignalid(['Diagnostics and Validation/Axis',UnitNumber,'/SC_Sys_NoiseInpt']); % Measured Noise
    %         Sgnl2=Target.getsignalid(['Diagnostics and Validation/Axis',UnitNumber,'/SC_Sys_CtrlInpt']);  % Controller Input
    %         Sgnl3=Target.getsignalid(['Diagnostics and Validation/Axis',UnitNumber,'/SC_Sys_CtrlOtpt']);  % Controller Output
    %         Sgnl4=Target.getsignalid(['Diagnostics and Validation/Axis',UnitNumber,'/SC_Sys_PlantInpt']); % Plant Input
    %         Sgnl5=Target.getsignalid(['Diagnostics and Validation/Axis',UnitNumber,'/SC_Sys_PlantOtpt']); % PLant Output
    %
    
    % select in simulink the block output that you want to measure.
    % use "gcb" to find the address and remove the model name.
    %add below and add a variable name for the workspace.
    
    signals  = { %<location>,<trace name>
        {'Models/Sort/Slc/Gate1','Gate1'};
        {'Models/Sort/Slc/Gate1','Gate2'};
        {'Models/Sort/Slc/Gate1','Gate3'};
        {'Models/Sort/Slc/Gate1','Gate4'};
        {'Models/Sort/Slc/Gate1','Gate5'};
        {'Models/Sort/Slc/Gate1','Gate6'};
        {'Models/Sort/Slc/Gate1','Gate7'};
        {'Models/Sort/Slc/Gate1','Gate8'};       
        {'Models/Sort/Slc/Nozzle1','Nozzle1'}; 
        {'Models/Sort/Slc/Nozzle1','Nozzle2'}; 
        {'Models/Sort/Slc/Nozzle1','Nozzle3'}; 
        {'Models/Sort/Slc/Nozzle1','Nozzle4'}; 
        {'Models/Sort/Slc/Nozzle1','Nozzle5'}; 
        {'Models/Sort/Slc/Nozzle1','Nozzle6'}; 
        {'Models/Sort/Slc/Nozzle1','Nozzle7'}; 
        {'Models/Sort/Slc/Nozzle1','Nozzle8'}; 
        
        {'Models/Sort/Slc/Sort1Pass','Sort1Pass'}; 
        {'Models/Sort/Slc/Sort1Reject','Sort1Reject'}; 
        {'Models/Sort/Slc/Sort1NoData','Sort1NoData'}; 
        {'Models/Sort/Slc/Sort1Misaligned','Sort1Misaligned'}; 
        {'Models/Sort/Slc/Sort1TooClose','Sort1TooClose'}; 
        {'Models/Sort/Slc/Sort1LateResult','Sort1LateResult'}; 
        {'Models/Sort/Slc/Sort1NegativePass','Sort1NegativePass'}; 

        };
    
    
    %******************************************************************
    % Define Host scope
    %******************************************************************
    for i=1:length(signals)
        
        ID=Target.getsignalid(char(signals{i}(1))); %retrieve ID
        if (ID <= 0)
            fprintf('ID not found for %s/n',signals{i}(1));
            return;
        end;
        TraceScope.addsignal(ID);
        TraceScope.triggermode = 'software'; %'FreeRun'
        TraceScope.NumSamples = TraceLength;
        TraceScope.Decimation = TraceDecimation;
    end;
    
    TraceScope.start;
    fprintf(1,['Measurement started, Please wait!\n']);
    xpctargetping; % Ping target to ensure connection before data transfer
    TraceScope.trigger;
    fprintf(1,'Processing starts after %2.0f seconds!\n',TraceLength*TraceDecimation*Ts+1);
    
    %******************************************************************
    % Measurement started. Waiting...
    %******************************************************************
    
    pause((TraceLength*TraceDecimation*Ts+1));
    
    TraceScope.stop;
    
    xpctargetping; % Ping target to ensure connection before data transfer
    
    
    % Stop target scopes to speed up communication
    for j=1:length(allscopes)
        ScopeID=allscopes(j).ScopeID;
        sc = Target.getscope(ScopeID);
        sc.stop;
    end
    
    
    
    fprintf(1,'Getting data from target, Please wait!\n');
    TraceTime=TraceScope.time(:);
    TraceTime=TraceTime-TraceTime(1);%remove T0.
    TraceData = TraceScope.data;
    
    for i=1:length(signals)
        assignin('base','tmp_',TraceData(:,i));
        evalin('base',['trc.' char(signals{i}(2)) '=tmp_;']);
    end;
    
    fprintf(1,'Data retrieved!\n');
    
    
    % Remove host scope
    Target.remscope(255);
    
    % Restart target scopes
    for j=1:length(allscopes)
        ScopeID=allscopes(j).ScopeID;
        sc = Target.getscope(ScopeID);
        sc.start;
    end
    
    %**************************************************************************
    
else
    fprintf(1,'No connection found!\n')
    fprintf(1,'Make sure xPC-Target is running!\n')
end % Measurement


clear TraceData;
clear TraceDecimation;
clear TraceLength;
clear TraceScope;

%*************************************************************************%
%*************************************************************************%
%*************************************************************************%
%Plot results
%use "whos Trace*" to find all plottable signals.


figure;
%plot(TraceTime, TraceSbcVelAct);
subplot(3,1,1);
plot(TraceTime, trc.Gate1,'b');
hold on;
plot(TraceTime, trc.Gate2,'g');
plot(TraceTime, trc.Gate3,'r');
plot(TraceTime, trc.Gate4,'c');
plot(TraceTime, trc.Gate5,'m');
plot(TraceTime, trc.Gate6,'y');
plot(TraceTime, trc.Gate7,'k');
plot(TraceTime, trc.Gate8,'b:');

subplot(3,1,2);
plot(TraceTime, trc.Nozzle1,'b');
hold on;
plot(TraceTime, trc.Nozzle2,'g');
plot(TraceTime, trc.Nozzle3,'r');
plot(TraceTime, trc.Nozzle4,'c');
plot(TraceTime, trc.Nozzle5,'m');
plot(TraceTime, trc.Nozzle6,'y');
plot(TraceTime, trc.Nozzle7,'k');
plot(TraceTime, trc.Nozzle8,'b:');

%only look at increments of counters.
subplot(3,1,3);
plot(TraceTime, [0 diff(trc.Sort1Pass)],'bo');
hold on;
plot(TraceTime, [0 diff(trc.Sort1Reject)],'go');
plot(TraceTime, [0 diff(trc.Sort1NoData)],'ro');
plot(TraceTime, [0 diff(trc.Sort1Misaligned)],'co');
plot(TraceTime, [0 diff(trc.Sort1TooClose)],'mo');
plot(TraceTime, [0 diff(trc.Sort1LateResult)],'yo');
plot(TraceTime, [0 diff(trc.Sort1NegativePass)],'ko');
