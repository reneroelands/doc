function MakeLook
%MAKELOOK Summary
%   MakeLook generates default color layout for the active model according
%   to MAAB guidelines for model readibility.
%   - Inputs and From blocks are colored Orange
%   - Outputs and Goto blocks are colored Blue.
%   Latest update: ENUIJ 26022009
FromGotoMatchMode=2;  %0=none 1=Goto blue, From orange. 2=map color palette to From/Goto combinations.

Inports  =  find_system(gcs,'BlockType','Inport');
Outports =  find_system(gcs,'BlockType','Outport');
Gotos    =  find_system(gcs,'BlockType','Goto');
Froms    =  find_system(gcs,'BlockType','From');
Consts   =  find_system(gcs,'BlockType','Constant');
States   =  [find_system(gcs,'BlockType','Memory');find_system(gcs,'BlockType','UnitDelay');];
systems  =  find_system(gcs,'BlockType','SubSystem');

%tryout regexp usage.
%name=Froms;until=regexp(name,'[/]');
%for x=1:length(Froms)
%    subsyss{x}=name{x}(1:until{1}(end))
%end;

fprintf('Color Map: \n');

%Inputs orange
fprintf('  Inputs    : Orange \n');
for x=1:length(Inports)
    set_param(char(Inports(x)),'BackgroundColor','orange');
end;

%outputs light blue
fprintf('  Outputs   : Blue \n');
for x=1:length(Outports)
    set_param(char(Outports(x)),'BackgroundColor','lightBlue');
end;

%Constants are gray
fprintf('  Constants : Light Gray \n');
for x=1:length(Consts)
    set_param(char(Consts(x)),'BackgroundColor','[0.752941, 0.752941, 0.752941]');
end;

%States are Light Magenta
fprintf('  States    : Light Magenta \n');
for x=1:length(States)
    set_param(char(States(x)),'BackgroundColor','[1.000000, 0.501961, 1.000000]');
end;

if (FromGotoMatchMode==1)
    fprintf('  From      : orange        \n');
    for x=1:length(Gotos)
        set_param(char(Gotos(x)),'BackgroundColor','lightBlue');
    end;
    fprintf('  Goto      : lightBlue     \n');
    for x=1:length(Froms)
        set_param(char(Froms(x)),'BackgroundColor','orange');
    end;
elseif (FromGotoMatchMode==2)
    fprintf('  From      : automatic matched    \n');
    fprintf('  Goto      : automatic matched    \n');
    %match colors From/Goto blocks automatically.
    figure;cm=colormap('colorcube');close; %apply color map to empty figure and remove it;
    cm=cm(2:38,:); %remove dark colors
    colorcnt=0;
    for x=1:length(systems)
        sysFrom=find_system(systems{x},'BlockType','From');
        sysGoto=find_system(systems{x},'BlockType','Goto');
        colorcnt=0;
        if ~isempty(sysFrom)
            for y=1:length(sysGoto)
                colorcnt=colorcnt+5;
                color=cm(rem(colorcnt,length(cm)),:);
                sysgotosigname=get_param(sysGoto{y},'GotoTag');
                set_param(sysGoto{y},'BackgroundColor',['[' num2str(color(1)) ', ' num2str(color(2)) ', ' num2str(color(3)) ']']);
                for z=1:length(sysFrom)
                    sysfromsigname=get_param(sysFrom{z},'GotoTag');
                    if strcmp(sysfromsigname,sysgotosigname)
                        set_param(sysFrom{z},'BackgroundColor',['[' num2str(color(1)) ', ' num2str(color(2)) ', ' num2str(color(3)) ']']);
                    end;
                end;
            end;
        end;
    end;
end;

disp 'MakeLook Done!'