% Tracescript for DRS sorter
% Analyse trace data
% CCM, Center for Concepts in Mechatronics
% Last Modified by JHER/ENUIJ on 2010-06-03
%------------------------------------------------------------------

% Logging data from target via .m file
% Be sure that target is running

TraceTime = 5; % [s]

%------------------------------------------------------------------
% Define measurement parameters
%------------------------------------------------------------------
TraceLength=TraceTime/Ts;   % Number of measurement points
TraceDecimation=1;          % Every nth sample

%**************************************************************************

if strcmp(xpctargetping,'success')
    
    Target=xpctarget.xpc;  % Define Target
    
    
    
    %*********************************************************************
    % Remove all host scopes and create 1 new
    %*********************************************************************
    allscopes = getscope(Target);
    
    for j=1:length(allscopes)
        ScopeID=allscopes(j).ScopeID;
        if ScopeID == 255
            Target.remscope(255);             %Remove Scope
            allscopes = getscope(Target);   %Redefine (one scope removed)
        end
    end
    
    %*********************************************************************
    % Define Host scope(s)
    %*********************************************************************
    
    TraceScope = Target.addscope('host',255);
    
    %******************************************************************
    % example commands
    %******************************************************************
    
    %         Sgnl1=Target.getsignalid(['Diagnostics and Validation/Axis',UnitNumber,'/SC_Sys_NoiseInpt']); % Measured Noise
    %         Sgnl2=Target.getsignalid(['Diagnostics and Validation/Axis',UnitNumber,'/SC_Sys_CtrlInpt']);  % Controller Input
    %         Sgnl3=Target.getsignalid(['Diagnostics and Validation/Axis',UnitNumber,'/SC_Sys_CtrlOtpt']);  % Controller Output
    %         Sgnl4=Target.getsignalid(['Diagnostics and Validation/Axis',UnitNumber,'/SC_Sys_PlantInpt']); % Plant Input
    %         Sgnl5=Target.getsignalid(['Diagnostics and Validation/Axis',UnitNumber,'/SC_Sys_PlantOtpt']); % PLant Output
    %
    
    % select in simulink the block output that you want to measure.
    % use "gcb" to find the address and remove the model name.
    %add below and add a variable name for the workspace.
    
    signals  = {
        {'Diagnostics/SbcDiagnostics/SC_Sys_VelRef','TraceSbcVelRef'};
        {'Diagnostics/SbcDiagnostics/SC_Sys_VelAct','TraceSbcVelAct'};
        {'Hardware/Simulation/Hw_SimulationSort/Trc_Spare1','TraceDebug1'};
        {'Hardware/Simulation/Hw_SimulationSort/Spare1','TraceDebug2'};
        {'Models/Sort/Slc/Unit Delay2','SortTriggerCounter'};
        {'Models/Sort/Slc/Data Type Conversion19','ValidSignalSorter1'};
        {'Models/Sort/Slc/Sort1Debug','Sort1Debug'};
        {'Models/Sort/Slc/Sort1Misaligned','Misaligned'};
        };
    
    
    %******************************************************************
    % Define Host scope
    %******************************************************************
    for i=1:length(signals)
        
        ID=Target.getsignalid(char(signals{i}(1))); %retrieve ID
        if (ID <= 0)
            fprintf('ID not found for %s/n',signals{i}(1));
            return;
        end;
        TraceScope.addsignal(ID);
        TraceScope.triggermode = 'software'; %'FreeRun'
        TraceScope.NumSamples = TraceLength;
        TraceScope.Decimation = TraceDecimation;
    end;
    
    TraceScope.start;
    fprintf(1,['Measurement started, Please wait!\n']);
    xpctargetping; % Ping target to ensure connection before data transfer
    TraceScope.trigger;
    fprintf(1,'Processing starts after %2.0f seconds!\n',TraceLength*TraceDecimation*Ts+1);
    
    %******************************************************************
    % Measurement started. Waiting...
    %******************************************************************
    
    pause((TraceLength*TraceDecimation*Ts+1));
    
    TraceScope.stop;
    
    xpctargetping; % Ping target to ensure connection before data transfer
    
    
    % Stop target scopes to speed up communication
    for j=1:length(allscopes)
        ScopeID=allscopes(j).ScopeID;
        sc = Target.getscope(ScopeID);
        sc.stop;
    end
    
    
    
    fprintf(1,'Getting data from target, Please wait!\n');
    TraceTime=TraceScope.time(:);
    TraceTime=TraceTime-TraceTime(1);%remove T0.
    TraceData = TraceScope.data;
    
    for i=1:length(signals)
        assignin('base',char(signals{i}(2)),TraceData(:,i));
    end;
    
    fprintf(1,'Data retrieved!\n');
    
    
    % Remove host scope
    Target.remscope(255);
    
    % Restart target scopes
    for j=1:length(allscopes)
        ScopeID=allscopes(j).ScopeID;
        sc = Target.getscope(ScopeID);
        sc.start;
    end
    
    %**************************************************************************
    
else
    fprintf(1,'No connection found!\n')
    fprintf(1,'Make sure xPC-Target is running!\n')
end % Measurement


clear TraceData;
clear TraceDecimation;
clear TraceLength;
clear TraceScope;

%*************************************************************************%
%*************************************************************************%
%*************************************************************************%
%Plot results
%use "whos Trace*" to find all plottable signals.

figure;
%plot(TraceTime, TraceSbcVelAct);
plot(TraceTime, Sort1Debug);


