classdef TestCommandCreator < handle
    %UNTITLED2 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties (Access = private)
        CmdTable = []
        RelativeTime = 0
        
        CompAll   = 0
        CompSbc   = evalin('base', 'Sbc.Const.UnitID')
        CompTrig  = evalin('base', 'Trig.Const.UnitID')
        CompSort  = evalin('base', 'Sort.Const.UnitID')
        CompSteer = evalin('base', 'Steering.Const.UnitID')
        CompIO    = evalin('base', 'InOutputs.Const.UnitID')
    end

    methods (Access = private)
        function AddCommand(obj, timeStep, NewCmd, CompID, Params)
            %METHOD1 Summary of this method goes here
            %   Detailed explanation goes here
            obj.RelativeTime = obj.RelativeTime + timeStep;
            if nargin == 3
                CompID = obj.CompAll;
            end
            if nargin < 5
                Params = [];
            end
            Params = [Params zeros(1,4-length(Params))];
            obj.CmdTable = [obj.CmdTable; [obj.RelativeTime double(NewCmd) CompID Params]];
        end
    end
    
    methods
        function obj = TestCommandCreator()
            % Construct an instance of this class
            %   Detailed explanation goes here
            obj.CmdTable = [];
        end
        
        function [outputTab, simDuration] = GetTable(obj, fileName)
            %METHOD1 Summary of this method goes here
            %   Detailed explanation goes here
            FinalRow = [inf 0 0 0 0 0 0];
            outputTab = [obj.CmdTable; FinalRow]';
            simDuration = 10*ceil(obj.CmdTable(end,1)/10);
			
			TstCmdDir = [evalin('base','ModelPath'), '\Supporting Scripts\Com\TstCmd'];
            if exist(TstCmdDir) ~= 7
                mkdir(TstCmdDir);
            end
            fileDir = fullfile(TstCmdDir, [fileName, '.csv']);
            T = array2table(obj.CmdTable);
            writetable(T, fileDir,'Delimiter','\t', 'WriteVariableNames',0);
        end

% Command interface        
        function CmdNoCommand(obj, timeStep)
            obj.AddCommand(timeStep, evalin('base', 'Com.Hc.Cmd.NoCommand'));
        end
        
        function CmdReset(obj, timeStep)
            obj.AddCommand(timeStep, evalin('base', 'Com.Hc.Cmd.Reset'));
        end
        
        function CmdPullErrorFIFO(obj, timeStep)
            obj.AddCommand(timeStep, evalin('base', 'Com.Hc.Cmd.PullErrorFIFO'));
        end
        
% Sbc module
        function CmdSbcReset(obj, timeStep)
            obj.AddCommand(timeStep, evalin('base', 'Sbc.Const.Mlc.TrjCmd.Reset'), obj.CompSbc);
        end

        function CmdSbcSetSPGParams(obj, timeStep, Vel, Acc, Jerk, DriveRollDiameter)
            obj.AddCommand(timeStep, evalin('base', 'Sbc.Const.Mlc.TrjCmd.SetSPGParams'), obj.CompSbc, [Vel Acc Jerk DriveRollDiameter]);
        end
        
        function CmdSbcStartRotating(obj, timeStep)
            obj.AddCommand(timeStep, evalin('base', 'Sbc.Const.Mlc.TrjCmd.StartRotating'), obj.CompSbc);
        end
        
        function CmdSbcStopRotating(obj, timeStep)
            obj.AddCommand(timeStep, evalin('base', 'Sbc.Const.Mlc.TrjCmd.StopRotating'), obj.CompSbc);
        end
        
        function CmdSbcMoveRelative(obj, timeStep, PosStep)
            obj.AddCommand(timeStep, evalin('base', 'Sbc.Const.Mlc.TrjCmd.MoveRelative'), obj.CompSbc, PosStep);
        end

% Trigger module
        function CmdTrigReset(obj, timeStep)
            obj.AddCommand(timeStep, evalin('base', 'Trig.Const.Mlc.TrjCmd.Reset'), obj.CompTrig);
        end

        function CmdTrigSetTriggerParams(obj, timeStep, PosInterval, LCM, Ratio, TriggerNr)
            obj.AddCommand(timeStep, evalin('base', 'Trig.Const.Mlc.TrjCmd.SetTriggerParams'), obj.CompTrig, [PosInterval LCM Ratio TriggerNr]);
        end
        
        function CmdTrigStartTriggering(obj, timeStep)
            obj.AddCommand(timeStep, evalin('base', 'Trig.Const.Mlc.TrjCmd.StartTriggering'), obj.CompTrig);
        end
        
        function CmdTrigStopTriggering(obj, timeStep)
            obj.AddCommand(timeStep, evalin('base', 'Trig.Const.Mlc.TrjCmd.StopTriggering'), obj.CompTrig);
        end
        
        function CmdTrigResetTriggerCounter(obj, timeStep)
            obj.AddCommand(timeStep, evalin('base', 'Trig.Const.Mlc.TrjCmd.ResetTriggerCounter'), obj.CompTrig);
        end
        

% Sort module
        function CmdSortEnableSorting(obj, timeStep)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.ENABLE'), obj.CompSort);
        end
        
        function CmdSortDisableSorting(obj, timeStep)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.DISABLE'), obj.CompSort);
        end
        
        function CmdSortSetSortParamsA(obj, timeStep, BeltLength, PValue)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetSortParamsA'), obj.CompSort, [BeltLength PValue]);
        end
        
        function CmdSortSetSortParamsB(obj, timeStep, GateWindow, FireWindow, FireWindowShift)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetSortParamsB'), obj.CompSort, [GateWindow FireWindow FireWindowShift]);
        end
        
        function CmdSortSetSortParamsC(obj, timeStep, LaneDef_Start1, LaneDef_Stop1, LaneDef_Start2, LaneDef_Stop2)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetSortParamsC'), obj.CompSort, [LaneDef_Start1 LaneDef_Stop1 LaneDef_Start2 LaneDef_Stop2]);
        end
        
        function CmdSortSetSortParamsD(obj, timeStep, LaneDef_Start3, LaneDef_Stop3, LaneDef_Start4, LaneDef_Stop4)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetSortParamsD'), obj.CompSort, [LaneDef_Start3 LaneDef_Stop3 LaneDef_Start4 LaneDef_Stop4]);
        end
        
        function CmdSortSetSortParamsE(obj, timeStep, LaneDef_Start5, LaneDef_Stop5, LaneDef_Start6, LaneDef_Stop6)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetSortParamsE'), obj.CompSort, [LaneDef_Start5 LaneDef_Stop5 LaneDef_Start6 LaneDef_Stop6]);
        end
        
        function CmdSortSetSortParamsF(obj, timeStep, LaneDef_Start7, LaneDef_Stop7, LaneDef_Start8, LaneDef_Stop8)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetSortParamsF'), obj.CompSort, [LaneDef_Start7 LaneDef_Stop7 LaneDef_Start8 LaneDef_Stop8]);
        end
        
        function CmdSortSetSortDistanceLane1(obj, timeStep, CamToGate, GateToNozzle, CameraNr)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetSortDistanceLane1'), obj.CompSort, [CamToGate GateToNozzle CameraNr]);
        end
        
        function CmdSortSetSortDistanceLane2(obj, timeStep, CamToGate, GateToNozzle, CameraNr)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetSortDistanceLane2'), obj.CompSort, [CamToGate GateToNozzle CameraNr]);
        end
        
        function CmdSortSetSortDistanceLane3(obj, timeStep, CamToGate, GateToNozzle, CameraNr)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetSortDistanceLane3'), obj.CompSort, [CamToGate GateToNozzle CameraNr]);
        end
        
        function CmdSortSetSortDistanceLane4(obj, timeStep, CamToGate, GateToNozzle, CameraNr)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetSortDistanceLane4'), obj.CompSort, [CamToGate GateToNozzle CameraNr]);
        end
        
        function CmdSortSetSortDistanceLane5(obj, timeStep, CamToGate, GateToNozzle, CameraNr)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetSortDistanceLane5'), obj.CompSort, [CamToGate GateToNozzle CameraNr]);
        end
        
        function CmdSortSetSortDistanceLane6(obj, timeStep, CamToGate, GateToNozzle, CameraNr)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetSortDistanceLane6'), obj.CompSort, [CamToGate GateToNozzle CameraNr]);
        end
        
        function CmdSortSetSortDistanceLane7(obj, timeStep, CamToGate, GateToNozzle, CameraNr)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetSortDistanceLane7'), obj.CompSort, [CamToGate GateToNozzle CameraNr]);
        end
        
        function CmdSortSetSortDistanceLane8(obj, timeStep, CamToGate, GateToNozzle, CameraNr)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetSortDistanceLane8'), obj.CompSort, [CamToGate GateToNozzle CameraNr]);
        end

        function CmdSortSetGateDisableParam(obj, timeStep, GateDisable_to_WeldDistance_mm, GateDisable_Length_mm)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetGateDisableParam'), obj.CompSort, [GateDisable_to_WeldDistance_mm GateDisable_Length_mm]);
        end
        
        function CmdSortSetSort_CG(obj, timeStep, Sort_CG)
            obj.AddCommand(timeStep, evalin('base', 'Sort.Const.Mlc.ModeCmd.SetSort_CG'), obj.CompSort, [Sort_CG]);
        end
        
% Steering module
        function CmdSteeringReset(obj, timeStep)
            obj.AddCommand(timeStep, evalin('base', 'Steering.Const.Mlc.ModeCmd.Reset'), obj.CompSteer);
        end

        function CmdSteeringEnableSteering(obj, timeStep)
            obj.AddCommand(timeStep, evalin('base', 'Steering.Const.Mlc.ModeCmd.Enable'), obj.CompSteer);
        end
        
        function CmdSteeringDisableSteering(obj, timeStep)
            obj.AddCommand(timeStep, evalin('base', 'Steering.Const.Mlc.ModeCmd.Disable'), obj.CompSteer);
        end

% InOutputs module
        function CmdInOutSetBSAUp(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetBSAUp'), obj.CompIO, Enable);
        end
        
        function CmdInOutSetBSADown(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetBSADown'), obj.CompIO, Enable);
        end
        
        function CmdInOutSetIonizer(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetIonizer'), obj.CompIO, Enable);
        end
        
        function CmdInOutSetVacuumGeneratorTrayHndlr(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetVacuumGeneratorTrayHndlr'), obj.CompIO, Enable);
        end
        
        function CmdInOutSetSystemGas(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetSystemGas'), obj.CompIO, Enable);
        end
        
        function CmdInOutSetXRayCameraUp(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetXRayCameraUp'), obj.CompIO, Enable);
        end
        function CmdInOutSetXRayCameraDown(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetXRayCameraDown'), obj.CompIO, Enable);
        end
        
        function CmdInOutSetFeeder(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetFeeder'), obj.CompIO, Enable);
        end
        
        function CmdInOutSetHopper(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetHopper'), obj.CompIO, Enable);
        end
        
        function CmdInOutSetLightInspectionCamera(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetLightInspectionCamera'), obj.CompIO, Enable);
        end
        
        function CmdInOutSetVacuumPump(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetVacuumPump'), obj.CompIO, Enable);
        end
        
        function CmdInOutSetCyclonGas(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetCyclonGas'), obj.CompIO, Enable);
        end
        
        function CmdInOutSetReturnCleanGasOn(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetReturnCleanGasOn'), obj.CompIO, Enable);
        end
        
        function CmdInOutSetFilterActuatorActive(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetFilterActuatorActive'), obj.CompIO, Enable);
        end
        
        function CmdInOutSetFilterActuatorInactive(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetFilterActuatorInactive'), obj.CompIO, Enable);
        end
        
        function CmdInOutSetVacuumPressureSetpoint(obj, timeStep, Percentage)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetVacuumPressureSetpoint'), obj.CompIO, Percentage);
        end
        
        function CmdInOutSetLineVacuumOn(obj, timeStep, Enable)
            obj.AddCommand(timeStep, evalin('base', 'InOutputs.Const.Mlc.ModeCmd.SetLineVacuumOn'), obj.CompIO, Enable);
        end

%         function outputArg = GetTable(obj, timeStep)
%             %METHOD1 Summary of this method goes here
%             %   Detailed explanation goes here
%             outputArg = obj.CmdTable + inputArg;
%         end
    end
end

