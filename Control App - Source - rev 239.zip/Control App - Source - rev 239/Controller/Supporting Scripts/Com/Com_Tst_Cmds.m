fprintf(1,'Defining Com TestCommands Sequences...\n')

%This file defines simulation commands sent to the Com module to trigger
%functions on modules: Sbc, Trig

% Each row has 4 parameters:
% Time CmdID UnitID Param[0] Param[1] Param[2]
% Unit-ID is used to filter/route commands to a specific module. 
% Command-ID's are defined specifically per module. ID's can overlap with other modules.

% Reset
TstCmdReset = TestCommandCreator; 
TstCmdReset.CmdSbcReset(0.1);
TstCmdReset.CmdSteeringReset(0.1);
TstCmdReset.CmdTrigReset(0.1);
TstCmdReset.CmdReset(0.1);
TstCmdReset.GetTable('Reset');

% None
TstCmdNone = TestCommandCreator;
TstCmdNone.CmdNoCommand(1);
TstCmdNone.CmdNoCommand(1);
TstCmdNone.CmdNoCommand(1);
TstCmdNone.CmdNoCommand(1);
TstCmdNone.CmdNoCommand(1);
TstCmdNone.CmdNoCommand(1);
TstCmdNone.CmdNoCommand(1);
TstCmdNone.CmdNoCommand(1);

% Sbc Continuous
TstCmdSbcCont = TestCommandCreator;
TstCmdSbcCont.CmdNoCommand(0.1);
TstCmdSbcCont.CmdSbcReset(0.5);
TstCmdSbcCont.CmdSbcSetSPGParams(0.1, 0.06, 0.1, 0.1, 0.01505);
TstCmdSbcCont.CmdSbcStartRotating(0.1);
TstCmdSbcCont.CmdSbcStopRotating(15.0);
% TstCmdSbcCont.GetTable('SbcContinuous');

%Sbc P2P
TstCmdSbcP2P = TestCommandCreator;
TstCmdSbcP2P.CmdNoCommand(0.1);
TstCmdSbcP2P.CmdSbcReset(0.5);
TstCmdSbcP2P.CmdSbcSetSPGParams(0.1, 0.06, 0.1, 0.1, 0.01505);
TstCmdSbcP2P.CmdSbcMoveRelative(0.1, 0.3);
TstCmdSbcP2P.CmdNoCommand(10);

% Steering only
TstCmdSteerOnly = TestCommandCreator;
TstCmdSteerOnly.CmdReset(0.1);
TstCmdSteerOnly.CmdInOutSetSystemGas(2.0, 1);
TstCmdSteerOnly.CmdSteeringReset(0.1);
TstCmdSteerOnly.CmdInOutSetBSAUp(2.0, 0);
TstCmdSteerOnly.CmdInOutSetBSADown(2.0, 1);
TstCmdSteerOnly.CmdSteeringEnableSteering(15.1);
TstCmdSteerOnly.CmdSteeringDisableSteering(10.1);
TstCmdSteerOnly.GetTable('SteeringOnly');

% Sbc with steering
TstCmdSteer = TestCommandCreator;
TstCmdSteer.CmdReset(0.1);
TstCmdSteer.CmdSteeringReset(0.1);
TstCmdSteer.CmdSbcReset(0.1);
TstCmdSteer.CmdInOutSetSystemGas(0.1, 1);
TstCmdSteer.CmdInOutSetBSAUp(2.0, 0);
TstCmdSteer.CmdInOutSetBSADown(2.0, 1);
TstCmdSteer.CmdNoCommand(15.0);
TstCmdSteer.CmdSteeringEnableSteering(0.1);
TstCmdSteer.CmdNoCommand(10.0);
TstCmdSteer.CmdSbcSetSPGParams(5.1, 0.06, 0.1, 0.1, 0.01505);
TstCmdSteer.CmdSbcStartRotating(0.1);
TstCmdSteer.CmdSbcStopRotating(180.0);
TstCmdSteer.CmdSteeringDisableSteering(0.1);
TstCmdSteer.CmdNoCommand(10);
TstCmdSteer.GetTable('Steering');

%% ---

% Sbc with steering and triggering
TstCmdTrig = TestCommandCreator;
    % Reset
% TstCmdTrig.CmdReset(0.1);
TstCmdTrig.CmdSteeringReset(0.1);
TstCmdTrig.CmdTrigReset(0.1);
TstCmdTrig.CmdSbcReset(0.1);
TstCmdTrig.CmdTrigResetTriggerCounter(0.1);

TstCmdTrig.CmdInOutSetSystemGas(0.1, 1);

    % Steering
TstCmdTrig.CmdInOutSetBSAUp(0.1, 0);
TstCmdTrig.CmdInOutSetBSADown(0.1, 1);
TstCmdTrig.CmdSteeringEnableSteering(2.0);
TstCmdTrig.CmdNoCommand(7.0);

    % Triggering
TstCmdTrig.CmdTrigSetTriggerParams(0.1, 13.4e-3, 1000, 4, 1);
TstCmdTrig.CmdTrigSetTriggerParams(0.1, 13.4e-3, 1000, 1, 2);
TstCmdTrig.CmdTrigSetTriggerParams(0.1, 13.4e-3, 1000, 2, 3);
TstCmdTrig.CmdTrigSetTriggerParams(0.1, 13.4e-3, 1000, 3, 4);
TstCmdTrig.CmdTrigSetTriggerParams(0.1, 13.4e-3, 1000, 4, 5);
TstCmdTrig.CmdSbcSetSPGParams(0.1, 0.05, 0.1, 0.1, 0.01505);
TstCmdTrig.CmdTrigStartTriggering(0.5);

    % Belt Control
TstCmdTrig.CmdSbcStartRotating(0.5);
    
TstCmdTrig.CmdNoCommand(30.0);

    % Stop all
TstCmdTrig.CmdSbcStopRotating(0.1);
TstCmdTrig.CmdTrigStopTriggering(0.1);
TstCmdTrig.CmdSteeringDisableSteering(0.1);
TstCmdTrig.CmdNoCommand(1);
TstCmdTrig.GetTable('BeltSteerTrig');

%%
% Triggering Continuous
TstCmdTrigCont = TestCommandCreator;
TstCmdTrigCont.CmdNoCommand(0.1);
TstCmdTrigCont.CmdTrigResetTriggerCounter(0.1);
TstCmdTrigCont.CmdTrigSetTriggerParams(0.1, 40e-3, 1000, 4, 1);
TstCmdTrigCont.CmdTrigSetTriggerParams(0.1, 40e-3, 1000, 1, 2);
TstCmdTrigCont.CmdTrigSetTriggerParams(0.1, 40e-3, 1000, 2, 3);
TstCmdTrigCont.CmdTrigSetTriggerParams(0.1, 40e-3, 1000, 3, 4);
TstCmdTrigCont.CmdTrigSetTriggerParams(0.1, 40e-3, 1000, 4, 5);
TstCmdTrigCont.CmdTrigStartTriggering(0.1);
TstCmdTrigCont.CmdSbcSetSPGParams(0.1, 0.06, 0.1, 0.1, 0.01505);
TstCmdTrigCont.CmdSbcStartRotating(0.1);
TstCmdTrigCont.CmdTrigStopTriggering(30);
TstCmdTrigCont.CmdSbcStopRotating(0.1);
TstCmdTrigCont.GetTable('UnitTestTrigger');

% Triggering P2P
TstCmdTrigP2P = TestCommandCreator;
TstCmdTrigP2P.CmdNoCommand(0.1);
TstCmdTrigP2P.CmdTrigResetTriggerCounter(0.1);
TstCmdTrigP2P.CmdTrigSetTriggerParams(0.1, 13.4e-3, 1000, 4, 1);
TstCmdTrigP2P.CmdTrigSetTriggerParams(0.1, 13.4e-3, 1000, 1, 2);
TstCmdTrigP2P.CmdTrigSetTriggerParams(0.1, 13.4e-3, 1000, 2, 3);
TstCmdTrigP2P.CmdTrigSetTriggerParams(0.1, 13.4e-3, 1000, 3, 4);
TstCmdTrigP2P.CmdTrigSetTriggerParams(0.1, 13.4e-3, 1000, 4, 5);
TstCmdTrigP2P.CmdTrigStartTriggering(0.1);
TstCmdTrigP2P.CmdSbcReset(0.1);
TstCmdTrigP2P.CmdSbcSetSPGParams(0.1, 0.06, 0.1, 0.1, 0.01505);
TstCmdTrigP2P.CmdSbcMoveRelative(0.1, 0.3);
TstCmdTrigP2P.CmdTrigStopTriggering(8);

% IO
TstCmdIO = TestCommandCreator;
TstCmdIO.CmdNoCommand(0.1);
    % System Gas ON
TstCmdIO.CmdInOutSetSystemGas(2, 1);
    % Steering
TstCmdIO.CmdInOutSetBSADown(2, 0);
TstCmdIO.CmdInOutSetBSAUp(2, 1);
TstCmdIO.CmdInOutSetBSAUp(2, 0);
TstCmdIO.CmdInOutSetBSADown(2, 1);
    % Filter
TstCmdIO.CmdInOutSetFilterActuatorInactive(2, 0);
TstCmdIO.CmdInOutSetFilterActuatorActive(2, 1);
TstCmdIO.CmdInOutSetFilterActuatorActive(2, 0);
TstCmdIO.CmdInOutSetFilterActuatorInactive(2, 1);
    % X-Ray camera
TstCmdIO.CmdInOutSetXRayCameraDown(2, 0);
TstCmdIO.CmdInOutSetXRayCameraUp(2, 1);
TstCmdIO.CmdInOutSetXRayCameraUp(2, 0);
TstCmdIO.CmdInOutSetXRayCameraDown(2, 1);
    % Feeder
TstCmdIO.CmdInOutSetFeeder(2, 1);
TstCmdIO.CmdInOutSetFeeder(2, 0);
    % Hopper
TstCmdIO.CmdInOutSetHopper(2, 1);
TstCmdIO.CmdInOutSetHopper(2, 0);
    % Cyclon Gas
TstCmdIO.CmdInOutSetCyclonGas(2, 1);
TstCmdIO.CmdInOutSetCyclonGas(2, 0);
    % Tray Handler
TstCmdIO.CmdInOutSetVacuumGeneratorTrayHndlr(2, 1);
TstCmdIO.CmdInOutSetVacuumGeneratorTrayHndlr(2, 0);
    % Vacuum Pump
TstCmdIO.CmdInOutSetVacuumPump(2,1);
TstCmdIO.CmdInOutSetVacuumPump(2,0);

%% Sorting
TstCmdSort = TestCommandCreator;

% Reset
TstCmdSort.CmdSteeringReset(0.1);
TstCmdSort.CmdTrigReset(0.1);
TstCmdSort.CmdSbcReset(0.1);
TstCmdSort.CmdTrigResetTriggerCounter(0.1);

% System gas on, probably its on already
TstCmdSort.CmdInOutSetSystemGas(0.1, 1);

% Set BSA down and enable steering
TstCmdSort.CmdInOutSetBSAUp(0.1, 0);
TstCmdSort.CmdInOutSetBSADown(0.1, 1);
TstCmdSort.CmdSteeringEnableSteering(1.0);
TstCmdSort.CmdNoCommand(1.0);

% Enable sorting
TstCmdSort.CmdSortEnableSorting(0.1);

% Triggering 
TstCmdSort.CmdTrigSetTriggerParams(0.1, 13.4e-3, 1000, 4, 1);
TstCmdSort.CmdTrigSetTriggerParams(0.1, 13.4e-3, 1000, 1, 2);
TstCmdSort.CmdTrigSetTriggerParams(0.1, 13.4e-3, 1000, 2, 3);
TstCmdSort.CmdTrigSetTriggerParams(0.1, 13.4e-3, 1000, 3, 4);
TstCmdSort.CmdTrigSetTriggerParams(0.1, 13.4e-3, 1000, 4, 5);
TstCmdSort.CmdTrigStartTriggering(0.1)

% Belt
TstCmdSort.CmdSbcSetSPGParams(0.1, 0.055, 0.1, 0.1, 0.01505);
TstCmdSort.CmdSbcStartRotating(0.1);
TstCmdSort.CmdNoCommand(3.0);

% Stop
TstCmdSort.CmdSortDisableSorting(20);
TstCmdSort.CmdTrigStopTriggering(0.1)
TstCmdSort.CmdSbcStopRotating(0.1);
TstCmdSort.CmdSteeringDisableSteering(0.1);

TstCmdSort.GetTable('Sorting');


%%

% if ~exist('TestCmdChoice', 'var')
    O = {'None','SbcContinuous','SbcP2P', 'Steering', 'TriggerContinuous', 'TriggerP2P', 'IO', 'Sort'};
    TestCmdChoice=menu('Select the Com test sequence to be used:', O{1}, O{2}, O{3}, O{4}, O{5}, O{6}, O{7}, O{8});
    TestCmdChoiceString = O{TestCmdChoice};
% end

switch (TestCmdChoiceString)
case 'None'
    [Com.Test.Cmd, SimDuration] = TstCmdSbc.GetTable(TestCmdChoiceString);
case 'SbcContinuous'
    [Com.Test.Cmd, SimDuration] =  TstCmdSbcCont.GetTable(TestCmdChoiceString);
case 'SbcP2P'
    [Com.Test.Cmd, SimDuration] =  TstCmdSbcP2P.GetTable(TestCmdChoiceString);
case 'Steering'
    [Com.Test.Cmd, SimDuration] =  TstCmdSteer.GetTable(TestCmdChoiceString);
case 'TriggerContinuous'
    [Com.Test.Cmd, SimDuration] =  TstCmdTrigCont.GetTable(TestCmdChoiceString);
case 'TriggerP2P'
    [Com.Test.Cmd, SimDuration] = TstCmdTrigP2P.GetTable(TestCmdChoiceString);
case 'IO'
    [Com.Test.Cmd, SimDuration] = TstCmdIO.GetTable(TestCmdChoiceString);
case 'Sort'
    [Com.Test.Cmd, SimDuration] = TstCmdSort.GetTable(TestCmdCho---iceString);
otherwise
end

% Test.Cmd = Tst.Cmd.None.';
clear Tst.Cmd.Normal;
clear Tst.Cmd.None;