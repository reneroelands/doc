function blkStruct = slblocks

if (verLessThan('simulink','8.4'))
	blkStruct.Browser(1).Library = 'TcTargetLib';
	blkStruct.Browser(1).Name    = 'TwinCAT Target';
	blkStruct.Browser(1).IsFlat  =  0;
	blkStruct.Browser(1).IsTopLevel = 0;
else
	blkStruct.Browser(1).Library = 'TcTargetLib';
	blkStruct.Browser(1).Name    = 'Beckhoff TwinCAT Target';
	blkStruct.Browser(1).IsFlat  =  0;
	blkStruct.Browser(1).IsTopLevel = 1;
end