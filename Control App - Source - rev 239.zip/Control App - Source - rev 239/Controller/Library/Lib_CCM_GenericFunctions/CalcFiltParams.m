function [Ki,Kd1,Kd2,Kd3,...
            Filt1_a1,Filt1_a2,Filt1_b0,Filt1_b1,Filt1_b2,...
            Filt2_a1,Filt2_a2,Filt2_b0,Filt2_b1,Filt2_b2,...
            Ctrl_Sys]...
            = CalcFiltParams(Ts,Kp,FrqI,FrqD,BetaD,...
                                Filt1_Frq0,Filt1_Frq1,Filt1_Mag0,Filt1_Mag1,Filt1_Gain,...
                                Filt2_Frq0,Filt2_Frq1,Filt2_Mag0,Filt2_Mag1,Filt2_Gain)


%-----------------------------------------------------------------------
% PID
%-----------------------------------------------------------------------

% Conversion to rad/s
TauI = 1/(FrqI*2*pi);
TauD = 1/(FrqD*2*pi);

%-----------------------------------------------------------------------
% Filter1
%-----------------------------------------------------------------------

% Conversion to rad/s and dB's
Filt1_Omega0    = 2*pi*Filt1_Frq0;           
Filt1_Omega1    = 2*pi*Filt1_Frq1;
Filt1_Beta0     = 1/(2*10^(Filt1_Mag0/20)); 
Filt1_Beta1     = 1/(2*10^(Filt1_Mag1/20));

%-----------------------------------------------------------------------
% Filter2
%-----------------------------------------------------------------------


% Conversion to rad/s and dB's
Filt2_Omega0    = 2*pi*Filt2_Frq0;           
Filt2_Omega1    = 2*pi*Filt2_Frq1;
Filt2_Beta0     = 1/(2*10^(Filt2_Mag0/20)); 
Filt2_Beta1     = 1/(2*10^(Filt2_Mag1/20));

%-------------------------------------------------------------------
% Alternative Discrete filter parameters for PID controller 
% Gert van Ooik 26-09-2006
%-------------------------------------------------------------------

%-------------------------------------------------------------------
% PI filter
%-------------------------------------------------------------------

Ki = Ts * Kp / TauI; % Integral gain

%-------------------------------------------------------------------
% PD filter (P=1)
%-------------------------------------------------------------------

Kd1 = (Ts * 1) / (Ts + TauD * BetaD ); 
Kd2 = (TauD * 1) / (Ts + TauD * BetaD ); 
Kd3 = (TauD * BetaD) / (Ts + TauD * BetaD ); % feedback


% *************************************************************************
% Continuous time transfer functions

% PI-action
NumPI  = [TauI*Kp Kp];
DenPI  = [TauI 0];
SysPI = tf(NumPI,DenPI);

% D-action
NumD = [TauD 1];
DenD = [TauD*BetaD 1];
SysD = tf(NumD,DenD);

% Filter 1
NumFilt1 = [1 2*Filt1_Beta0 * Filt1_Omega0 Filt1_Omega0^2];
DenFilt1 = [1 2*Filt1_Beta1 * Filt1_Omega1 Filt1_Omega1^2];
SysFilt1 = tf(NumFilt1,DenFilt1);
SysFilt1 = series(SysFilt1,Filt1_Gain);

% Filter 2
NumFilt2 = [1 2*Filt2_Beta0 * Filt2_Omega0 Filt2_Omega0^2];
DenFilt2 = [1 2*Filt2_Beta1 * Filt2_Omega1 Filt2_Omega1^2];
SysFilt2 = tf(NumFilt2,DenFilt2);
SysFilt2 = series(SysFilt2,Filt2_Gain);

% Create controller response functions for offline tuning purposes
PID         =   series(SysPI,SysD);
Notches     =   series(SysFilt1,SysFilt2);

Ctrl_Sys    =   series(PID,Notches);
% 
% 
% figure(1)
% bode(Ctrl_Sys);hold on

%**************************************************************************
% Convert to Discrete time transfer function

SysFilt1_D =   c2d(SysFilt1, Ts,'matched');
SysFilt2_D =   c2d(SysFilt2, Ts,'matched');

[NumFilt1_D,DenFilt1_D] =   tfdata(SysFilt1_D,'v');
[NumFilt2_D,DenFilt2_D] =   tfdata(SysFilt2_D,'v');

% % 
% figure(10)
% dbode(NumFilt1_D,DenFilt1_D,Ts);hold on
% 
% figure(11)
% dbode(NumFilt2_D,DenFilt2_D,Ts);hold on

Filt1_a1    = DenFilt1_D(1,2);
Filt1_a2    = DenFilt1_D(1,3);
Filt1_b0    = NumFilt1_D(1,1);
Filt1_b1    = NumFilt1_D(1,2);
Filt1_b2    = NumFilt1_D(1,3);

Filt2_a1    = DenFilt2_D(1,2);
Filt2_a2    = DenFilt2_D(1,3);
Filt2_b0    = NumFilt2_D(1,1);
Filt2_b1    = NumFilt2_D(1,2);
Filt2_b2    = NumFilt2_D(1,3);

