function MexBuild(sfile, libfile) 
%-------------------------------------------------------------------------
% Conditionally compile and build (MEX) the *.c source files (S-Functions)
%
% CCM, Center for Concepts in Mechatronics
% by Hans Kuppens
%
% Last updated: 20 Sep 2006, by HKup
%-------------------------------------------------------------------------
%
% Parameter "sfile" contains filename without extension
%
%-------------------------------------------------------------------------

if nargin < 2, libfile = ''; end

% fprintf(1, sfile);
cfile = [sfile '.c'];            % Source filename
% fprintf(1, cfile);
wfile = [sfile '.' mexext];       % Destination target filename
% fprintf(1, wfile);

fc=dir(cfile);
fw=dir(wfile);

if isempty(fc)
    % Source file (*.c) does not exist!!!
    cfile = [sfile '.cpp'];   % Try *.cpp file
    fc=dir(cfile);
end

if isempty(fc)
    % Source file (*.cpp) does not exist!!!
    fprintf(1,'<!!! ')
    fprintf(1,sfile)
    fprintf(1,' !!!>')
else
    if isempty(fw)
        % Target file (*.mexw32) does not exist, needs to be compiled
        fprintf(1,'*')
        eval(['mex -silent ' cfile ' ' libfile])
    else
        if datenum(fc.date) > datenum(fw.date)
            % Target file (*.mexw32) is older, needs to be recompiled
            fprintf(1,'*')
            eval(['mex -silent ' cfile ' ' libfile])
        else
            % Target file (*.mexw32) is newer, OK
            fprintf(1,'.')
        end
    end
end
