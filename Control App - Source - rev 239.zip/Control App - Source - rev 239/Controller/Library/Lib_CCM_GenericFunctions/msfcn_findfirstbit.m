function msfcn_findfirstbit(block)
% Level-2 M file S-Function for limited integrator demo.
%   Copyright 1990-2004 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $ 
% Finds the least significant bit that is active.

  setup(block);
  
%endfunction

function setup(block)
  
  %% Register number of dialog parameters   
  block.NumDialogPrms = 0;

  %% Register number of input and output ports
  block.NumInputPorts  = 1;
  block.NumOutputPorts = 1;

  %% Setup functional port properties to dynamically
  %% inherited.
  block.SetPreCompInpPortInfoToDynamic;
  block.SetPreCompOutPortInfoToDynamic;
 
  block.InputPort(1).Dimensions        = 1;
  block.InputPort(1).DirectFeedthrough = true;
  
% typedef enum {
%     SS_DOUBLE  =  0,    /* real_T    */
%     SS_SINGLE  =  1,    /* real32_T  */
%     SS_INT8    =  2,    /* int8_T    */
%     SS_UINT8   =  3,    /* uint8_T   */
%     SS_INT16   =  4,    /* int16_T   */
%     SS_UINT16  =  5,    /* uint16_T  */
%     SS_INT32   =  6,    /* int32_T   */
%     SS_UINT32  =  7,    /* uint32_T  */
%     SS_BOOLEAN =  8     /* boolean_T */
% } BuiltInDTypeId;

  
  block.InputPort(1).DatatypeID  = 7;  % SS_UINT32
  block.InputPort(1).Complexity  = 'Real';
  
  
  
  block.OutputPort(1).Dimensions       = 1;
  block.OutputPort(1).DatatypeID       = 7;  % SS_UINT32
  block.OutputPort(1).Complexity        = 'Real';
  
  %% Set block sample time to continuous
  block.SampleTimes = [0 0];
  
  %% Setup Dwork
  block.NumContStates = 0; %1

  %% Register methods
  block.RegBlockMethod('InitializeConditions',    @InitConditions);  
  block.RegBlockMethod('Outputs',                 @Output);  
%  block.RegBlockMethod('Derivatives',             @Derivative);  
  
%endfunction

function InitConditions(block)

  %% Initialize Dwork
  %block.ContStates.Data = block.DialogPrm(3).Data;
  block.OutputPort(1).Data=uint32(0);
  
%endfunction

function Output(block)

u=uint32(block.InputPort(1).Data);

if u~=0  %only run loop if an error is active.
    for x=0:31
        a=double(u);
        i=uint32(a)-uint32(floor(a/(2^(x+8)))*uint32(2^(x+8))); %remove all values above maxuint8, because cast function clips at max value.
        i= uint32(i / 2^x);              %shift data so that interesting bit is at position 0.
        a = cast(i,'uint8');             %cast to uint8 (note this is not a pure cast!!)
        if (bitand(a,uint8(1))>0) %check for lowest bit.
            break;
        end;
    end;
    block.OutputPort(1).Data = uint32(x);
else
    block.OutputPort(1).Data = uint32(-1);
end;
%  block.OutputPort(1).Data = block.ContStates.Data;

%endfunction

%function Derivative(block)

%      lb = block.DialogPrm(1).Data;
%      ub = block.DialogPrm(2).Data;
%      u =  block.InputPort(1).Data;
% 
%      if (block.ContStates.Data <= lb && u < 0) || (block.ContStates.Data >= ub && u > 0)
%        block.Derivatives.Data = 0;
%      else
%        block.Derivatives.Data = u;
%      end
  
%endfunction

