/*
 * Xeno_ServerEvent.cpp - Linux Xenomai Target Event Sender.
 *
 * Copyright 2009 CCM Centre for Concepts in Mechatronics
 */

#ifdef __cplusplus
extern "C" { // use the C fcn-call standard for all functions
#endif       // defined within this scope

#define S_FUNCTION_LEVEL   2
#undef  S_FUNCTION_NAME
#define S_FUNCTION_NAME    FindFirstBit    // The name of the S-function must match the
                                           // "S-function name" found in the "Look Under Mask" menu entry
#include <stddef.h>
#include <stdlib.h>
#include "simstruc.h"

#ifdef MATLAB_MEX_FILE
  #include "mex.h"
#endif

static char_T msg[256];

/* List of parameters. The order must match the order in "S-function parameters" found in the "Look Under Mask" menu entry */
typedef enum {
    NUMBER_OF_ARGS
} eParams;

//-- Parameters section (optional)
// #define GET_ARG_XXX  ssGetSFcnParam(S,S_ARG_XXX)

/* List of input ports, in the given order. */
typedef enum {
    S_IN_PORT_BITS, // 0
    NUMBER_OF_INPUT_PORTS   // = 1
} eInputPorts;

/* List of output ports, in the given order. */
typedef enum {
    S_OUT_PORT_LOWEST_BIT,  // 0
    NUMBER_OF_OUTPUT_PORTS  // = 1
} eOutputPorts;

/* List of I Works storage. Used to share local information between mdlStart, Outputs and Terminate */
typedef enum {
    NUMBER_OF_I_WORKS
} eIworks;

/* List of R Works storage. Used to share local information between mdlStart, Outputs and Terminate */
typedef enum {
    NUMBER_OF_R_WORKS
} eRworks;

/* List of P Works storage. Used to share local information between mdlStart, Outputs and Terminate */
typedef enum {
    NUMBER_OF_P_WORKS
} ePworks;

//===========================================================================

static void SetInputPortConfig(SimStruct *S, int iPortnr, int iPortWidth, DTypeId Type, int iContiguous, int iDirectFF)
{
    ssSetInputPortWidth             (S, iPortnr, iPortWidth);
    ssSetInputPortDataType          (S, iPortnr, Type);
    ssSetInputPortRequiredContiguous(S, iPortnr, iContiguous);
    ssSetInputPortDirectFeedThrough (S, iPortnr, iDirectFF);
}

static void SetOutputPortConfig(SimStruct *S, int iPortnr, int iPortWidth, DTypeId Type)
{
    ssSetOutputPortWidth   (S, iPortnr, iPortWidth);
    ssSetOutputPortDataType(S, iPortnr, Type );
}

//===========================================================================

static void mdlInitializeSizes(SimStruct *S)
{
    int i;

    /* Verify that the number of parameters passed from the mask match what is expected */
    ssSetNumSFcnParams(S, NUMBER_OF_ARGS);
    if ( ssGetNumSFcnParams(S) != ssGetSFcnParamsCount(S) ) {
        sprintf(msg,
                "Wrong number of input arguments passed.\n%d arguments are expected\n",
                NUMBER_OF_ARGS);
        ssSetErrorStatus(S, msg);
        return;
    }

    ssSetNumContStates(S, 0);
    ssSetNumDiscStates(S, 0);

    ssSetNumInputPorts (S, NUMBER_OF_INPUT_PORTS);
    ssSetNumOutputPorts(S, NUMBER_OF_OUTPUT_PORTS);
    ssSetNumSampleTimes(S, 1);

    // --- PortNr, Width, Type, Contiguous, DirectFF
    SetInputPortConfig(S, S_IN_PORT_BITS, 1, SS_UINT32, 1, 1);

    // --- PortNr, Width, Type
    SetOutputPortConfig(S, S_OUT_PORT_LOWEST_BIT, 1, SS_INT32);

    /* Reserve space for the work variables */
    ssSetNumPWork(S, NUMBER_OF_P_WORKS);
    ssSetNumRWork(S, NUMBER_OF_R_WORKS);
    ssSetNumIWork(S, NUMBER_OF_I_WORKS);

    ssSetNumModes(S, 0);
    ssSetNumNonsampledZCs(S, 0);

    for (i = 0 ; i < NUMBER_OF_ARGS ; i++) {
        ssSetSFcnParamTunable(S, i, SS_PRM_NOT_TUNABLE);
    }

    /* Set options */
    ssSetOptions(S, SS_OPTION_RUNTIME_EXCEPTION_FREE_CODE);
}

/* This function uses the sample time value (-1 for inherit or a specified value) and passes
 * the appropriate values to the Simulink functions.
 */
static void mdlInitializeSampleTimes(SimStruct *S)
{
    time_T sample_time = -1;

    if ( sample_time == -1.0 ) {
        ssSetSampleTime(S, 0, INHERITED_SAMPLE_TIME);
        ssSetOffsetTime(S, 0, FIXED_IN_MINOR_STEP_OFFSET);
    } else {
        ssSetSampleTime(S, 0, sample_time);
        ssSetOffsetTime(S, 0, 0.0);
    }
}

// #define MDL_START
// static void mdlStart(SimStruct *S)
// {
// }

static void mdlOutputs(SimStruct *S, int_T tid)
{
// Return index of lowest bit set.
// Bit index ranges from 0 to 31.
// Examples:
//    ***1 --> 0
//    **10 --> 1
//    *100 --> 2
// Return -1 if no bit is set.

    uint32_T *IPtr = (uint32_T *) ssGetInputPortSignal(S, S_IN_PORT_BITS);
    int32_T  *OPtr = (int32_T  *) ssGetOutputPortSignal(S, S_OUT_PORT_LOWEST_BIT);

    uint32_T  x = IPtr[0];
    int32_T   r = -1;

    if (x != 0)
    {
		r = 0;
		x &= ((~x)+1);  // isolate lowest bit (x &= -x;)

		if ( x & 0xffff0000 )  r += 16;
		if ( x & 0xff00ff00 )  r += 8;
		if ( x & 0xf0f0f0f0 )  r += 4;
		if ( x & 0xcccccccc )  r += 2;
		if ( x & 0xaaaaaaaa )  r += 1;
    }
    OPtr[0] = r;
}

static void mdlTerminate(SimStruct *S)
{
}

//===========================================================================

#ifdef MATLAB_MEX_FILE  /* Is this file being compiled as a MEX-file? */
#include "simulink.c"   /* Mex glue */
#else
#include "cg_sfun.h"    /* Code generation glue */
#endif

#ifdef __cplusplus
} // end of extern "C" scope
#endif
