% Mex all files in Lib_CCM_GenericFunctions.mdl library

MexBuild('FindFirstBit')
