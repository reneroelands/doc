function MexBuildLib(sfile,libfile) 
%-------------------------------------------------------------------------
% Conditionally compile and build (MEX) the *.c source files (S-Functions)
%
% CCM, Center for Concepts in Mechatronics
% by Hans Kuppens
%
% Last updated: 22 Jun 2007, by HKup
%-------------------------------------------------------------------------
%
% Parameter "sfile" contains source filename without extension
% Parameter "libfile" contains library filename without extension
%
%-------------------------------------------------------------------------

% fprintf(1, sfile);
cfile = [sfile '.c'];        % Source filename
% fprintf(1, cfile);
wfile = [sfile '.mexw32'];   % Destination target filename
% fprintf(1, wfile);
hfile = [libfile '.h'];      % Header filename
% fprintf(1, hfile);
lfile = [libfile '.c'];      % Library Source filename
% fprintf(1, lfile);
ofile = [libfile '.obj'];    % Library Object filename
% fprintf(1, ofile);

% Do files exist in directory?
fc=dir(cfile);             
fw=dir(wfile);
fh=dir(hfile);
fl=dir(lfile);
fo=dir(ofile);

cmd_mexo = ['mex -c ' lfile];
cmd_mexw = ['mex ' cfile ' ' ofile];

if (length(fc) == 0) || (length(fl) == 0) || (length(fh) == 0)
    % Source file (*.c;*.h) does not exist!!!
    fprintf(1,'<!!! ')
    fprintf(1,sfile)
    fprintf(1,' !!!>')
else
    if length(fo) == 0
        % Object file (*.obj) does not exist, needs to be compiled
        fprintf(1,'o')
        eval(['mex -c ' lfile])
    else
        if (datenum(fl.date) > datenum(fo.date)) || (datenum(fh.date) > datenum(fo.date))
            % Target file (*.mexw32) is older, needs to be recompiled
            fprintf(1,'o')
            eval(['mex -c ' lfile])
        else
            % Target file (*.mexw32) is newer, OK
            fprintf(1,'.')
        end
    end
    if length(fw) == 0
        % Target file (*.mexw32) does not exist, needs to be compiled
        fprintf(1,'*')
        eval(['mex ' cfile ' ' ofile])
    else
        fo=dir(ofile);
        if (datenum(fc.date) > datenum(fw.date)) || (datenum(fo.date) > datenum(fw.date))
            % Target file (*.mexw32) is older, needs to be recompiled
            fprintf(1,'*')
            eval(['mex ' cfile ' ' ofile])
        else
            % Target file (*.mexw32) is newer, OK
            fprintf(1,'.')
        end
    end
end
