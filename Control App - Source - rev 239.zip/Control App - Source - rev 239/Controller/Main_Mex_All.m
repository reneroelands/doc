% MEX ALL
fprintf('%s : Main_Mex_ALL\n',Main.ModelName);

% fprintf(1,'Copying S-Function files to root...\n')
% copyfile('./Library/Lib_CCM_GenericFunctions/*.cpp', '.','f');

% fprintf(1,'Done copying\n')

fprintf(1,'Starting MEX<')

run Library\Lib_CCM_GenericFunctions\Lib_CCM_GenericFunctions_Mex
run Models\Sort\Lib_Sort_Mex

cd(Main.ModelPath)

fprintf(1,'>\nDone MEX\n')

