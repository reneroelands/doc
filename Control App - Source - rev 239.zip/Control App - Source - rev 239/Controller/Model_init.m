% This is the main init script for the XSSCC2 hardware controller
% Editor:       ENui/Mott/RPul/Wildschutj

%--------------------------------------------------------------------
% General stuff
%--------------------------------------------------------------------

Main.ModelPath = pwd;               % Store model path for logo
Main.ModelName = 'MIGRATION_BECKHOFF';   % Define Simulink model name
ModelPath = Main.ModelPath;         % Needed for EtherCAT
MODEL_DATE = str2double(datestr(now,'yyyymmdd')); % yyyymmdd

% Add EtherCAT target dir
HostTargetDir = [Main.ModelPath '\TargetDir'];


%--------------------------------------------------------------------
%% Configure/check compiler (Generic code, do not change)
%--------------------------------------------------------------------

% Verify the selected compiler(s)
%
% Note: Using mex.getCompilerConfigurations() to verify which compiler is used is
% not 100% reliable due to a known issue in ML2010/ML2012/ML2015:
% *) During compiling, the MEX compiler is selected from %APPDATA% mexopts.bat file,
%    even when the MATLB prefdir points to a different folder.
% *) Command mex.getCompilerConfigurations does point to the MATLAB prefdir folder
% -> When using a custom defined prefs folder, the wrong mex compiler version
%    can be returned. Future solution: use -f option in mex command to explicitly
%    point to prefdir folder, however -f option is deprecated.
% The mex_C_win64.xml \ mex_C++_win64.xml are no longer versioned in the MATLAB_PREFS,
% in stead we just set the version

MatlabVersion = ver('Matlab');
try 
    disp('configuring the compiler');
    switch MatlabVersion.Version
        %  the mex setup produces a lot of warning output, use evalc to capture and prevent the warning is displayed
        case '9.3' % ML2017b
            % Contrary to other Sioux project, this project required using an Visual C++ 2015 compiler (=due to
            % compatibility issues between TwinCAT TE1400 and the Visual C++ 2017 compiler)
            evalc('mex -silent -setup:C:\Matlab\R2017b\bin\win64\mexopts\msvc2015.xml C');
            evalc('mex -silent -setup:C:\Matlab\R2017b\bin\win64\mexopts\msvcpp2015.xml C++');
        otherwise
            error('Matlab version not supported');
    end        
catch
    disp('compiler could not be set automatically')
end

% consider to remove the following version check once the scripted mex -setup have been proven to work reliable 
try
    cc=mex.getCompilerConfigurations('C');
    MexCompiler_C=[cc.Name ' ' cc.Version];
catch
    MexCompiler_C='None';
    error('ERROR DURING CONFIGUATION OF MexCompiler_C');
end
try
    cc=mex.getCompilerConfigurations('C++');
    MexCompiler_Cpp=[cc.Name ' ' cc.Version];
catch
    MexCompiler_Cpp='None';
    error('ERROR DURING CONFIGUATION OF MexCompiler_Cpp');
end
disp(['Used MEX compiler (Language: C)   : ' MexCompiler_C]);
disp(['Used MEX compiler (Language: C++) : ' MexCompiler_Cpp]);

switch MatlabVersion.Version
    case '9.3' % ML2017b
        assert(strcmp(MexCompiler_C,'Microsoft Visual C++ 2015 (C) 14.0'),['Error, unexpected MEX compiler (Language:C) : ' MexCompiler_C ' , use mex -setup'])
        assert(strcmp(MexCompiler_Cpp,'Microsoft Visual C++ 2015 14.0'),['Error, unexpected C++ compiler (Language:C++) : ' MexCompiler_Cpp ' , use mex -setup'])
end


%--------------------------------------------------------------------
% Add paths libraries and supporting scripts
%--------------------------------------------------------------------
% Use absolute path, so that it still works if the 'work folder' changes.

addpath([Main.ModelPath '\Hi']);
addpath([Main.ModelPath '\Hw']);
addpath([Main.ModelPath '\Models']);
addpath([Main.ModelPath '\Models\Com']);
addpath([Main.ModelPath '\Models\Sbc']);
addpath([Main.ModelPath '\Models\Sort']);
addpath([Main.ModelPath '\Models\Trig']);
addpath([Main.ModelPath '\Models\Steering']);
addpath([Main.ModelPath '\Models\InOutputs']);

%.... add module paths here....
addpath([Main.ModelPath '\Library']);
addpath([Main.ModelPath '\Library\Lib_CCM_GenericFunctions']);
addpath([Main.ModelPath '\Supporting Scripts']);
addpath([Main.ModelPath '\Supporting Scripts\Com']);
addpath([Main.ModelPath '\Supporting Scripts\slalign']); %nice tool...

if ~(exist('TcTargetLib.slx')==4)
    errordlg({'*** TwinCAT is not installed ***','',...
        'Added local copy of TcTargetLib to allow VIEWING of the model.','',...
        'Please install the full [TwinCAT 3 Target for Simulink] before EDITING or BUILDING the model. Risk: model settings can get lost when not all toolboxes are installed'});
    addpath([Main.ModelPath,'\Library\TcTargetLib']);
end


%--------------------------------------------------------------------
% Basic model settings
%--------------------------------------------------------------------
%Main.Ts = 2e-4;
Main.Ts = 1e-3;

Ts = Main.Ts; %obsolete definition!! Inherit sample time by module name. E.a. Chk.Ts = Main.Ts; Prepare for multi-rate model architecture!

%--------------------------------------------------------------------
% Mex all S-Functions
%--------------------------------------------------------------------
Main_Mex_All;                       % Copy & Build all S-Functions

%--------------------------------------------------------------------
% Define all Buses
%--------------------------------------------------------------------
Main_Buses_Load;

%-------------------------------------------------------------------------
% Submodule related .M files
%-------------------------------------------------------------------------
SimPreload = strcmp(MnChoice, 'SIL') + strcmp(MnChoice, 'PIL');

Com_Const_Preload;

% Seed belt control
Sbc_Const_Preload;
% Sbc_Ctrl_Preload --> machine specific
Sbc_Ctrl_Preload_Demonstrator;

% Triggering
Trig_Const_Preload;
Trig_Ctrl_Preload;
if SimPreload
    Trig_Sim_Preload;
end

% Sorting
% Sort_Const_Preload is machine specific --> see below
Sort_Const_Preload;
Sort_Tun_Preload_Demonstrator;
if SimPreload
    Sort_Sim_Preload;
end

% Belt steering
Steering_Tun_Preload;
Steering_Const_Preload;
if SimPreload
    Steering_Sim_Preload;
end

% Direct in & outputs to & from Labview
InOutputs_Const_Preload;
if SimPreload
    InOutputs_Sim_Preload;
end

%-------------------------------------------------------------------------
% Connect simulink twincat blocks withing the Twincat environment
%-------------------------------------------------------------------------
HwInit;

%-------------------------------------------------------------------------
% Simulation related .M files
%-------------------------------------------------------------------------
if SimPreload
    Simulator.SeedData = CreateSeedData(100, 'seedspreadl', 0);
end