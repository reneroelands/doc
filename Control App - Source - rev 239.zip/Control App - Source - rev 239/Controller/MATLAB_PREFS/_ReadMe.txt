Sioux way-of-working:

Matlab configuration for a project are stored in the MATLAB_PREFS and applied when loading
the project by using _matlab.bat or _aInitMain.bat.
This guarantees that the same binaries will be ontained on each developer system, indenpendent
on Matlab settings that were changed by a local user or previous project

NB. Nowadays this can also be guaranteed by using 'Matlab Projects' -> Since different project
at Sioux are still using older matlab version, this WoW cannot be used for all projects -->
Use custom Sioux implementation of 'Sioux Matlab Projects' instead :-)
