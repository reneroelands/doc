% This is the main init script for the XSSCC2 hardware controller
% Editor:       HKup/Wildschutj

%--------------------------------------------------------------------
% General stuff
%--------------------------------------------------------------------
clear all;
clc;
close all;


%--------------------------------------------------------------------
% Suppress warnings for known build issues
%--------------------------------------------------------------------

warning('off','SL_SERVICES:utils:UNDEFINED_ID');

%--------------------------------------------------------------------
% Show menu for model configuration modes5
%--------------------------------------------------------------------
disp('Asking for Simulink Model Configuration (menu)...');

warning('Restore steering error checking. For now temporarily partially disabled.')

MenuOptions={ 
    {'Matlab/Simulink Simulation (SIL)'         ,'SIL'}
    {'Controller and Simulator over ADS (PIL)'  ,'PIL'}
    {'Hardware in the loop (HIL)'               ,'HIL'}
    {'Testrig (TEST)'                           ,'TEST'}
};

MnChoice=menu('Please select',MenuOptions); 
MnChoice=char(MenuOptions{MnChoice}(2));

Model_init;
Model_open;

