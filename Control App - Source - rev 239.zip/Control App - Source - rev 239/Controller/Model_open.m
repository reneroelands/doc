% This is the main init script for the XSSCC2 hardware controller
% Editor:       ENui/Mott/RPul/Wildschutj

%--------------------------------------------------------------------
% Open simulink model
%--------------------------------------------------------------------
open([Main.ModelName,'.mdl']); % Load Simulink model

%--------------------------------------------------------------------
% Model configuration
%--------------------------------------------------------------------

assert(exist('MnChoice', 'var')==1, 'Variable ''MnChoice'' is not set');

TargetConfigSet = {'ConfigurationSIL', 'ConfigurationTC'}; 

disp(['Configuration = ' MnChoice]);
if strcmp(MnChoice,'SIL')
    set_param([Main.ModelName,'/Host Interface'], 'BlockChoice', 'Sequencer');
    set_param([Main.ModelName,'/Hardware'], 'BlockChoice', 'Simulation');
    setActiveConfigSet(Main.ModelName, TargetConfigSet{1}); 
    
    Com_Tst_Cmds;
end

if strcmp(MnChoice,'HIL')
    set_param([Main.ModelName,'/Host Interface'], 'BlockChoice', 'Server Host');
    set_param([Main.ModelName,'/Hardware'], 'BlockChoice', 'HIL');
    setActiveConfigSet(Main.ModelName, TargetConfigSet{2}); 
end

if strcmp(MnChoice,'PIL')
    set_param([Main.ModelName,'/Host Interface'], 'BlockChoice', 'Server Host');
    set_param([Main.ModelName,'/Hardware'], 'BlockChoice', 'HIL');
    setActiveConfigSet(Main.ModelName, TargetConfigSet{2});  
end

if strcmp(MnChoice,'TEST')
    set_param([Main.ModelName,'/Host Interface'], 'BlockChoice', 'Server Host');
    set_param([Main.ModelName,'/Hardware'], 'BlockChoice', 'HIL');
    setActiveConfigSet(Main.ModelName, TargetConfigSet{2});  
end