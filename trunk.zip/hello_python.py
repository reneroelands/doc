#! _python.bat
# first line is a so called 'shebang' and can be used to execute the python script direct from explorer (doubleclick)
# refer to _python.bat for more details.

def main():
  print('Hello World!')
  input("enter to close")
  
if __name__== "__main__":
  main()
