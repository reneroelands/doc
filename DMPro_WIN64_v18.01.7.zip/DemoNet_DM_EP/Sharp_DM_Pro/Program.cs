using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Sharp_DM_EP
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [DllImport("DM_EP_64.dll", EntryPoint = "Connect_DM_Decoder", CallingConvention = CallingConvention.StdCall)]
        internal static extern IntPtr Connect_DM_Decoder([In] Int32 MaxColCount, [In] Int32 MaxRowCount);

        [STAThread]
        static void Main ( )
        {
            //            int vers;
            //            vers = Version();
            //            if (vers!=0)
            IntPtr decPtr = Connect_DM_Decoder(8192, 8192);
            if (decPtr == IntPtr.Zero)
            {
                return;
            }
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1(decPtr));
        }
    }
}