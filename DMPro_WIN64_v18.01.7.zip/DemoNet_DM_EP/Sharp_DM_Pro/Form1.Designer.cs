namespace Sharp_DM_EP
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose (bool disposing)
        {
            if ( disposing && ( components != null ) )
            {
                components.Dispose( );
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent ( )
        {
           this.OpenDialog = new System.Windows.Forms.OpenFileDialog();
           this.panel1 = new System.Windows.Forms.Panel();
           this.LabelFileName = new System.Windows.Forms.Label();
           this.label3 = new System.Windows.Forms.Label();
           this.CountEdit = new System.Windows.Forms.TextBox();
           this.label2 = new System.Windows.Forms.Label();
           this.rrEdit = new System.Windows.Forms.TextBox();
           this.label1 = new System.Windows.Forms.Label();
           this.TimeEdit = new System.Windows.Forms.TextBox();
           this.button2 = new System.Windows.Forms.Button();
           this.button1 = new System.Windows.Forms.Button();
           this.splitContainer1 = new System.Windows.Forms.SplitContainer();
           this.Img = new System.Windows.Forms.PictureBox();
           this.SymbolsInfoGroupBox = new System.Windows.Forms.GroupBox();
           this.label31 = new System.Windows.Forms.Label();
           this.TB_ActColor = new System.Windows.Forms.TextBox();
           this.TB_SymbologyID = new System.Windows.Forms.TextBox();
           this.label32 = new System.Windows.Forms.Label();
           this.label15 = new System.Windows.Forms.Label();
           this.RSErrTextBox = new System.Windows.Forms.TextBox();
           this.label14 = new System.Windows.Forms.Label();
           this.HDimTextBox = new System.Windows.Forms.TextBox();
           this.label13 = new System.Windows.Forms.Label();
           this.VDimTextBox = new System.Windows.Forms.TextBox();
           this.label12 = new System.Windows.Forms.Label();
           this.DotPeenTextBox = new System.Windows.Forms.TextBox();
           this.label11 = new System.Windows.Forms.Label();
           this.MirroredTextBox = new System.Windows.Forms.TextBox();
           this.label10 = new System.Windows.Forms.Label();
           this.SymbolNumber = new System.Windows.Forms.NumericUpDown();
           this.OptionsGroupBox = new System.Windows.Forms.GroupBox();
           this.QzComboBox = new System.Windows.Forms.ComboBox();
           this.label29 = new System.Windows.Forms.Label();
           this.label28 = new System.Windows.Forms.Label();
           this.FilterComboBox = new System.Windows.Forms.ComboBox();
           this.label9 = new System.Windows.Forms.Label();
           this.CellColorComboBox = new System.Windows.Forms.ComboBox();
           this.label8 = new System.Windows.Forms.Label();
           this.QualityComboBox = new System.Windows.Forms.ComboBox();
           this.label7 = new System.Windows.Forms.Label();
           this.LabelComboBox = new System.Windows.Forms.ComboBox();
           this.label6 = new System.Windows.Forms.Label();
           this.SpeedComboBox = new System.Windows.Forms.ComboBox();
           this.label5 = new System.Windows.Forms.Label();
           this.label4 = new System.Windows.Forms.Label();
           this.MaxDMCountEdit = new System.Windows.Forms.NumericUpDown();
           this.MirrorComboBox = new System.Windows.Forms.ComboBox();
           this.panel3 = new System.Windows.Forms.Panel();
           this.textBox1 = new System.Windows.Forms.TextBox();
           this.panel4 = new System.Windows.Forms.Panel();
           this.label34 = new System.Windows.Forms.Label();
           this.label33 = new System.Windows.Forms.Label();
           this.comboBox1 = new System.Windows.Forms.ComboBox();
           this.panel2 = new System.Windows.Forms.Panel();
           this.QualityGroupBox = new System.Windows.Forms.GroupBox();
           this.panel5 = new System.Windows.Forms.Panel();
           this.label30 = new System.Windows.Forms.Label();
           this.label27 = new System.Windows.Forms.Label();
           this.TB_horizontal_print_growth = new System.Windows.Forms.TextBox();
           this.TB_vertical_print_growth = new System.Windows.Forms.TextBox();
           this.label26 = new System.Windows.Forms.Label();
           this.label25 = new System.Windows.Forms.Label();
           this.label24 = new System.Windows.Forms.Label();
           this.TB_overall_grade = new System.Windows.Forms.TextBox();
           this.label23 = new System.Windows.Forms.Label();
           this.TB_decode_grade = new System.Windows.Forms.TextBox();
           this.label22 = new System.Windows.Forms.Label();
           this.TB_modulation_grade = new System.Windows.Forms.TextBox();
           this.label21 = new System.Windows.Forms.Label();
           this.TB_fixed_pattern_damage_grade = new System.Windows.Forms.TextBox();
           this.TB_fixed_pattern_damage = new System.Windows.Forms.TextBox();
           this.label20 = new System.Windows.Forms.Label();
           this.TB_unused_error_correction_grade = new System.Windows.Forms.TextBox();
           this.TB_unused_error_correction = new System.Windows.Forms.TextBox();
           this.label19 = new System.Windows.Forms.Label();
           this.TB_symbol_contrast_grade = new System.Windows.Forms.TextBox();
           this.TB_symbol_contrast = new System.Windows.Forms.TextBox();
           this.label18 = new System.Windows.Forms.Label();
           this.TB_grid_nonuniformity_grade = new System.Windows.Forms.TextBox();
           this.TB_grid_nonuniformity = new System.Windows.Forms.TextBox();
           this.label17 = new System.Windows.Forms.Label();
           this.TB_axial_nonuniformity_grade = new System.Windows.Forms.TextBox();
           this.TB_axial_nonuniformity = new System.Windows.Forms.TextBox();
           this.label16 = new System.Windows.Forms.Label();
           this.panel1.SuspendLayout();
           this.splitContainer1.Panel1.SuspendLayout();
           this.splitContainer1.Panel2.SuspendLayout();
           this.splitContainer1.SuspendLayout();
           ((System.ComponentModel.ISupportInitialize)(this.Img)).BeginInit();
           this.SymbolsInfoGroupBox.SuspendLayout();
           ((System.ComponentModel.ISupportInitialize)(this.SymbolNumber)).BeginInit();
           this.OptionsGroupBox.SuspendLayout();
           ((System.ComponentModel.ISupportInitialize)(this.MaxDMCountEdit)).BeginInit();
           this.panel3.SuspendLayout();
           this.panel4.SuspendLayout();
           this.panel2.SuspendLayout();
           this.QualityGroupBox.SuspendLayout();
           this.SuspendLayout();
           // 
           // OpenDialog
           // 
           this.OpenDialog.Filter = "All (*.jpg;*.jpeg;*.gif;*.bmp;*.tif)|*.jpg;*.jpeg;*.gif;*.bmp;*.tif;*.tiff|JPEG I" +
               "mage File (*.jpg)|*.jpg|JPEG Image File (*.jpeg)|*.jpeg|Bitmaps (*.bmp)|*.bmp|Ti" +
               "f Image File (*.tif)|*.tif;*.tiff";
           // 
           // panel1
           // 
           this.panel1.Controls.Add(this.LabelFileName);
           this.panel1.Controls.Add(this.label3);
           this.panel1.Controls.Add(this.CountEdit);
           this.panel1.Controls.Add(this.label2);
           this.panel1.Controls.Add(this.rrEdit);
           this.panel1.Controls.Add(this.label1);
           this.panel1.Controls.Add(this.TimeEdit);
           this.panel1.Controls.Add(this.button2);
           this.panel1.Controls.Add(this.button1);
           this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
           this.panel1.Location = new System.Drawing.Point(0, 0);
           this.panel1.Name = "panel1";
           this.panel1.Size = new System.Drawing.Size(877, 74);
           this.panel1.TabIndex = 0;
           // 
           // LabelFileName
           // 
           this.LabelFileName.AutoSize = true;
           this.LabelFileName.Location = new System.Drawing.Point(16, 55);
           this.LabelFileName.Name = "LabelFileName";
           this.LabelFileName.Size = new System.Drawing.Size(0, 13);
           this.LabelFileName.TabIndex = 8;
           // 
           // label3
           // 
           this.label3.AutoSize = true;
           this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.label3.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label3.Location = new System.Drawing.Point(339, 9);
           this.label3.Name = "label3";
           this.label3.Size = new System.Drawing.Size(81, 13);
           this.label3.TabIndex = 7;
           this.label3.Text = "Decoded DM";
           // 
           // CountEdit
           // 
           this.CountEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.CountEdit.Location = new System.Drawing.Point(342, 29);
           this.CountEdit.Name = "CountEdit";
           this.CountEdit.ReadOnly = true;
           this.CountEdit.Size = new System.Drawing.Size(71, 20);
           this.CountEdit.TabIndex = 6;
           this.CountEdit.TabStop = false;
           // 
           // label2
           // 
           this.label2.AutoSize = true;
           this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.label2.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label2.Location = new System.Drawing.Point(438, 9);
           this.label2.Name = "label2";
           this.label2.Size = new System.Drawing.Size(108, 13);
           this.label2.TabIndex = 5;
           this.label2.Text = "Rejection Reason";
           // 
           // rrEdit
           // 
           this.rrEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.rrEdit.Location = new System.Drawing.Point(441, 29);
           this.rrEdit.Name = "rrEdit";
           this.rrEdit.ReadOnly = true;
           this.rrEdit.Size = new System.Drawing.Size(200, 20);
           this.rrEdit.TabIndex = 4;
           this.rrEdit.TabStop = false;
           // 
           // label1
           // 
           this.label1.AutoSize = true;
           this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.label1.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label1.Location = new System.Drawing.Point(647, 9);
           this.label1.Name = "label1";
           this.label1.Size = new System.Drawing.Size(53, 13);
           this.label1.TabIndex = 3;
           this.label1.Text = "Time ms";
           // 
           // TimeEdit
           // 
           this.TimeEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TimeEdit.Location = new System.Drawing.Point(650, 29);
           this.TimeEdit.Name = "TimeEdit";
           this.TimeEdit.ReadOnly = true;
           this.TimeEdit.Size = new System.Drawing.Size(79, 20);
           this.TimeEdit.TabIndex = 2;
           this.TimeEdit.TabStop = false;
           // 
           // button2
           // 
           this.button2.AccessibleDescription = "Decode Image";
           this.button2.BackColor = System.Drawing.SystemColors.ControlLightLight;
           this.button2.Enabled = false;
           this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
           this.button2.Image = global::Sharp_DM_EP.Properties.Resources.Key1;
           this.button2.Location = new System.Drawing.Point(59, 12);
           this.button2.Margin = new System.Windows.Forms.Padding(4);
           this.button2.Name = "button2";
           this.button2.Size = new System.Drawing.Size(36, 36);
           this.button2.TabIndex = 1;
           this.button2.UseVisualStyleBackColor = false;
           this.button2.Click += new System.EventHandler(this.button2_Click);
           // 
           // button1
           // 
           this.button1.AccessibleDescription = "Lod Image";
           this.button1.BackColor = System.Drawing.SystemColors.ControlLightLight;
           this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
           this.button1.Image = global::Sharp_DM_EP.Properties.Resources.Load;
           this.button1.Location = new System.Drawing.Point(12, 12);
           this.button1.Margin = new System.Windows.Forms.Padding(4);
           this.button1.Name = "button1";
           this.button1.Size = new System.Drawing.Size(36, 36);
           this.button1.TabIndex = 0;
           this.button1.UseVisualStyleBackColor = false;
           this.button1.Click += new System.EventHandler(this.button1_Click);
           // 
           // splitContainer1
           // 
           this.splitContainer1.BackColor = System.Drawing.SystemColors.Highlight;
           this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
           this.splitContainer1.ForeColor = System.Drawing.SystemColors.ActiveCaption;
           this.splitContainer1.Location = new System.Drawing.Point(0, 74);
           this.splitContainer1.Name = "splitContainer1";
           this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
           // 
           // splitContainer1.Panel1
           // 
           this.splitContainer1.Panel1.BackColor = System.Drawing.SystemColors.Control;
           this.splitContainer1.Panel1.Controls.Add(this.Img);
           this.splitContainer1.Panel1.Controls.Add(this.SymbolsInfoGroupBox);
           this.splitContainer1.Panel1.Controls.Add(this.OptionsGroupBox);
           // 
           // splitContainer1.Panel2
           // 
           this.splitContainer1.Panel2.BackColor = System.Drawing.SystemColors.Control;
           this.splitContainer1.Panel2.Controls.Add(this.panel3);
           this.splitContainer1.Panel2.Controls.Add(this.panel2);
           this.splitContainer1.Size = new System.Drawing.Size(877, 557);
           this.splitContainer1.SplitterDistance = 275;
           this.splitContainer1.TabIndex = 1;
           // 
           // Img
           // 
           this.Img.Dock = System.Windows.Forms.DockStyle.Fill;
           this.Img.Location = new System.Drawing.Point(261, 0);
           this.Img.Margin = new System.Windows.Forms.Padding(0);
           this.Img.Name = "Img";
           this.Img.Size = new System.Drawing.Size(407, 275);
           this.Img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
           this.Img.TabIndex = 2;
           this.Img.TabStop = false;
           this.Img.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Img_MouseDown);
           // 
           // SymbolsInfoGroupBox
           // 
           this.SymbolsInfoGroupBox.Controls.Add(this.label31);
           this.SymbolsInfoGroupBox.Controls.Add(this.TB_ActColor);
           this.SymbolsInfoGroupBox.Controls.Add(this.TB_SymbologyID);
           this.SymbolsInfoGroupBox.Controls.Add(this.label32);
           this.SymbolsInfoGroupBox.Controls.Add(this.label15);
           this.SymbolsInfoGroupBox.Controls.Add(this.RSErrTextBox);
           this.SymbolsInfoGroupBox.Controls.Add(this.label14);
           this.SymbolsInfoGroupBox.Controls.Add(this.HDimTextBox);
           this.SymbolsInfoGroupBox.Controls.Add(this.label13);
           this.SymbolsInfoGroupBox.Controls.Add(this.VDimTextBox);
           this.SymbolsInfoGroupBox.Controls.Add(this.label12);
           this.SymbolsInfoGroupBox.Controls.Add(this.DotPeenTextBox);
           this.SymbolsInfoGroupBox.Controls.Add(this.label11);
           this.SymbolsInfoGroupBox.Controls.Add(this.MirroredTextBox);
           this.SymbolsInfoGroupBox.Controls.Add(this.label10);
           this.SymbolsInfoGroupBox.Controls.Add(this.SymbolNumber);
           this.SymbolsInfoGroupBox.Dock = System.Windows.Forms.DockStyle.Right;
           this.SymbolsInfoGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.SymbolsInfoGroupBox.ForeColor = System.Drawing.SystemColors.Desktop;
           this.SymbolsInfoGroupBox.Location = new System.Drawing.Point(668, 0);
           this.SymbolsInfoGroupBox.Name = "SymbolsInfoGroupBox";
           this.SymbolsInfoGroupBox.Size = new System.Drawing.Size(209, 275);
           this.SymbolsInfoGroupBox.TabIndex = 1;
           this.SymbolsInfoGroupBox.TabStop = false;
           this.SymbolsInfoGroupBox.Text = "Symbol Info";
           // 
           // label31
           // 
           this.label31.AutoSize = true;
           this.label31.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label31.Location = new System.Drawing.Point(15, 135);
           this.label31.Name = "label31";
           this.label31.Size = new System.Drawing.Size(80, 13);
           this.label31.TabIndex = 15;
           this.label31.Text = "Actual Color ";
           // 
           // TB_ActColor
           // 
           this.TB_ActColor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_ActColor.Location = new System.Drawing.Point(119, 132);
           this.TB_ActColor.Name = "TB_ActColor";
           this.TB_ActColor.ReadOnly = true;
           this.TB_ActColor.Size = new System.Drawing.Size(75, 20);
           this.TB_ActColor.TabIndex = 14;
           this.TB_ActColor.TabStop = false;
           // 
           // TB_SymbologyID
           // 
           this.TB_SymbologyID.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_SymbologyID.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_SymbologyID.Location = new System.Drawing.Point(119, 54);
           this.TB_SymbologyID.Name = "TB_SymbologyID";
           this.TB_SymbologyID.ReadOnly = true;
           this.TB_SymbologyID.Size = new System.Drawing.Size(75, 20);
           this.TB_SymbologyID.TabIndex = 13;
           this.TB_SymbologyID.TabStop = false;
           // 
           // label32
           // 
           this.label32.AutoSize = true;
           this.label32.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label32.Location = new System.Drawing.Point(15, 56);
           this.label32.Name = "label32";
           this.label32.Size = new System.Drawing.Size(84, 13);
           this.label32.TabIndex = 12;
           this.label32.Text = "Symbology ID";
           // 
           // label15
           // 
           this.label15.AutoSize = true;
           this.label15.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label15.Location = new System.Drawing.Point(15, 213);
           this.label15.Name = "label15";
           this.label15.Size = new System.Drawing.Size(65, 13);
           this.label15.TabIndex = 11;
           this.label15.Text = "R-S Errors";
           // 
           // RSErrTextBox
           // 
           this.RSErrTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.RSErrTextBox.Location = new System.Drawing.Point(119, 211);
           this.RSErrTextBox.Name = "RSErrTextBox";
           this.RSErrTextBox.ReadOnly = true;
           this.RSErrTextBox.Size = new System.Drawing.Size(75, 20);
           this.RSErrTextBox.TabIndex = 10;
           this.RSErrTextBox.TabStop = false;
           // 
           // label14
           // 
           this.label14.AutoSize = true;
           this.label14.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label14.Location = new System.Drawing.Point(15, 108);
           this.label14.Name = "label14";
           this.label14.Size = new System.Drawing.Size(41, 13);
           this.label14.TabIndex = 9;
           this.label14.Text = "H Dim";
           // 
           // HDimTextBox
           // 
           this.HDimTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.HDimTextBox.Location = new System.Drawing.Point(119, 106);
           this.HDimTextBox.Name = "HDimTextBox";
           this.HDimTextBox.ReadOnly = true;
           this.HDimTextBox.Size = new System.Drawing.Size(75, 20);
           this.HDimTextBox.TabIndex = 8;
           this.HDimTextBox.TabStop = false;
           // 
           // label13
           // 
           this.label13.AutoSize = true;
           this.label13.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label13.Location = new System.Drawing.Point(15, 82);
           this.label13.Name = "label13";
           this.label13.Size = new System.Drawing.Size(40, 13);
           this.label13.TabIndex = 7;
           this.label13.Text = "V Dim";
           // 
           // VDimTextBox
           // 
           this.VDimTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.VDimTextBox.Location = new System.Drawing.Point(119, 80);
           this.VDimTextBox.Name = "VDimTextBox";
           this.VDimTextBox.ReadOnly = true;
           this.VDimTextBox.Size = new System.Drawing.Size(75, 20);
           this.VDimTextBox.TabIndex = 6;
           this.VDimTextBox.TabStop = false;
           // 
           // label12
           // 
           this.label12.AutoSize = true;
           this.label12.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label12.Location = new System.Drawing.Point(15, 187);
           this.label12.Name = "label12";
           this.label12.Size = new System.Drawing.Size(56, 13);
           this.label12.TabIndex = 5;
           this.label12.Text = "DotPeen";
           // 
           // DotPeenTextBox
           // 
           this.DotPeenTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.DotPeenTextBox.Location = new System.Drawing.Point(119, 184);
           this.DotPeenTextBox.Name = "DotPeenTextBox";
           this.DotPeenTextBox.ReadOnly = true;
           this.DotPeenTextBox.Size = new System.Drawing.Size(75, 20);
           this.DotPeenTextBox.TabIndex = 4;
           this.DotPeenTextBox.TabStop = false;
           // 
           // label11
           // 
           this.label11.AutoSize = true;
           this.label11.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label11.Location = new System.Drawing.Point(15, 161);
           this.label11.Name = "label11";
           this.label11.Size = new System.Drawing.Size(53, 13);
           this.label11.TabIndex = 3;
           this.label11.Text = "Mirrored";
           // 
           // MirroredTextBox
           // 
           this.MirroredTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.MirroredTextBox.Location = new System.Drawing.Point(119, 158);
           this.MirroredTextBox.Name = "MirroredTextBox";
           this.MirroredTextBox.ReadOnly = true;
           this.MirroredTextBox.Size = new System.Drawing.Size(75, 20);
           this.MirroredTextBox.TabIndex = 2;
           this.MirroredTextBox.TabStop = false;
           // 
           // label10
           // 
           this.label10.AutoSize = true;
           this.label10.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label10.Location = new System.Drawing.Point(15, 29);
           this.label10.Name = "label10";
           this.label10.Size = new System.Drawing.Size(94, 13);
           this.label10.TabIndex = 1;
           this.label10.Text = "Symbol Number";
           // 
           // SymbolNumber
           // 
           this.SymbolNumber.Enabled = false;
           this.SymbolNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.SymbolNumber.Location = new System.Drawing.Point(119, 28);
           this.SymbolNumber.Name = "SymbolNumber";
           this.SymbolNumber.Size = new System.Drawing.Size(75, 20);
           this.SymbolNumber.TabIndex = 0;
           this.SymbolNumber.TabStop = false;
           this.SymbolNumber.ValueChanged += new System.EventHandler(this.SymbolNumber_ValueChanged);
           // 
           // OptionsGroupBox
           // 
           this.OptionsGroupBox.Controls.Add(this.QzComboBox);
           this.OptionsGroupBox.Controls.Add(this.label29);
           this.OptionsGroupBox.Controls.Add(this.label28);
           this.OptionsGroupBox.Controls.Add(this.FilterComboBox);
           this.OptionsGroupBox.Controls.Add(this.label9);
           this.OptionsGroupBox.Controls.Add(this.CellColorComboBox);
           this.OptionsGroupBox.Controls.Add(this.label8);
           this.OptionsGroupBox.Controls.Add(this.QualityComboBox);
           this.OptionsGroupBox.Controls.Add(this.label7);
           this.OptionsGroupBox.Controls.Add(this.LabelComboBox);
           this.OptionsGroupBox.Controls.Add(this.label6);
           this.OptionsGroupBox.Controls.Add(this.SpeedComboBox);
           this.OptionsGroupBox.Controls.Add(this.label5);
           this.OptionsGroupBox.Controls.Add(this.label4);
           this.OptionsGroupBox.Controls.Add(this.MaxDMCountEdit);
           this.OptionsGroupBox.Controls.Add(this.MirrorComboBox);
           this.OptionsGroupBox.Dock = System.Windows.Forms.DockStyle.Left;
           this.OptionsGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.OptionsGroupBox.ForeColor = System.Drawing.SystemColors.Desktop;
           this.OptionsGroupBox.Location = new System.Drawing.Point(0, 0);
           this.OptionsGroupBox.Name = "OptionsGroupBox";
           this.OptionsGroupBox.Size = new System.Drawing.Size(261, 275);
           this.OptionsGroupBox.TabIndex = 0;
           this.OptionsGroupBox.TabStop = false;
           this.OptionsGroupBox.Text = "Options";
           // 
           // QzComboBox
           // 
           this.QzComboBox.AutoCompleteCustomSource.AddRange(new string[] {
            "No",
            "Yes"});
           this.QzComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.QzComboBox.FormattingEnabled = true;
           this.QzComboBox.Items.AddRange(new object[] {
            "Normal",
            "Small"});
           this.QzComboBox.Location = new System.Drawing.Point(114, 217);
           this.QzComboBox.Name = "QzComboBox";
           this.QzComboBox.Size = new System.Drawing.Size(121, 21);
           this.QzComboBox.TabIndex = 17;
           this.QzComboBox.TabStop = false;
           // 
           // label29
           // 
           this.label29.AutoSize = true;
           this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.label29.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label29.Location = new System.Drawing.Point(6, 218);
           this.label29.Name = "label29";
           this.label29.Size = new System.Drawing.Size(70, 13);
           this.label29.TabIndex = 16;
           this.label29.Text = "Quiet Zone";
           // 
           // label28
           // 
           this.label28.AutoSize = true;
           this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.label28.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label28.Location = new System.Drawing.Point(6, 190);
           this.label28.Name = "label28";
           this.label28.Size = new System.Drawing.Size(35, 13);
           this.label28.TabIndex = 15;
           this.label28.Text = "Filter";
           // 
           // FilterComboBox
           // 
           this.FilterComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.FilterComboBox.FormattingEnabled = true;
           this.FilterComboBox.Items.AddRange(new object[] {
            "AUTO",
            "NON",
            "SharpMask",
            "BWR"});
           this.FilterComboBox.Location = new System.Drawing.Point(114, 189);
           this.FilterComboBox.Name = "FilterComboBox";
           this.FilterComboBox.Size = new System.Drawing.Size(121, 21);
           this.FilterComboBox.TabIndex = 14;
           this.FilterComboBox.TabStop = false;
           // 
           // label9
           // 
           this.label9.AutoSize = true;
           this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.label9.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label9.Location = new System.Drawing.Point(6, 165);
           this.label9.Name = "label9";
           this.label9.Size = new System.Drawing.Size(36, 13);
           this.label9.TabIndex = 11;
           this.label9.Text = "Color";
           // 
           // CellColorComboBox
           // 
           this.CellColorComboBox.AutoCompleteCustomSource.AddRange(new string[] {
            "Black on White",
            "White on Black",
            "Any"});
           this.CellColorComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.CellColorComboBox.FormattingEnabled = true;
           this.CellColorComboBox.Items.AddRange(new object[] {
            "Black on White",
            "White on Black",
            "Any"});
           this.CellColorComboBox.Location = new System.Drawing.Point(114, 161);
           this.CellColorComboBox.Name = "CellColorComboBox";
           this.CellColorComboBox.Size = new System.Drawing.Size(121, 21);
           this.CellColorComboBox.TabIndex = 10;
           this.CellColorComboBox.TabStop = false;
           // 
           // label8
           // 
           this.label8.AutoSize = true;
           this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.label8.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label8.Location = new System.Drawing.Point(4, 137);
           this.label8.Name = "label8";
           this.label8.Size = new System.Drawing.Size(113, 13);
           this.label8.TabIndex = 9;
           this.label8.Text = "Quality Parameters";
           // 
           // QualityComboBox
           // 
           this.QualityComboBox.AutoCompleteCustomSource.AddRange(new string[] {
            "No",
            "Yes"});
           this.QualityComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.QualityComboBox.FormattingEnabled = true;
           this.QualityComboBox.Items.AddRange(new object[] {
            "No",
            "Yes"});
           this.QualityComboBox.Location = new System.Drawing.Point(159, 133);
           this.QualityComboBox.Name = "QualityComboBox";
           this.QualityComboBox.Size = new System.Drawing.Size(76, 21);
           this.QualityComboBox.TabIndex = 8;
           this.QualityComboBox.TabStop = false;
           // 
           // label7
           // 
           this.label7.AutoSize = true;
           this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.label7.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label7.Location = new System.Drawing.Point(6, 109);
           this.label7.Name = "label7";
           this.label7.Size = new System.Drawing.Size(73, 13);
           this.label7.TabIndex = 7;
           this.label7.Text = "Label Mode";
           // 
           // LabelComboBox
           // 
           this.LabelComboBox.AutoCompleteCustomSource.AddRange(new string[] {
            "Standard",
            "Dot peen",
            "Fax"});
           this.LabelComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.LabelComboBox.FormattingEnabled = true;
           this.LabelComboBox.Items.AddRange(new object[] {
            "Standard",
            "Dot peen",
            "St+Dot"});
           this.LabelComboBox.Location = new System.Drawing.Point(114, 105);
           this.LabelComboBox.Name = "LabelComboBox";
           this.LabelComboBox.Size = new System.Drawing.Size(121, 21);
           this.LabelComboBox.TabIndex = 6;
           this.LabelComboBox.TabStop = false;
           // 
           // label6
           // 
           this.label6.AutoSize = true;
           this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.label6.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label6.Location = new System.Drawing.Point(6, 82);
           this.label6.Name = "label6";
           this.label6.Size = new System.Drawing.Size(86, 13);
           this.label6.TabIndex = 5;
           this.label6.Text = "Decode Mode";
           // 
           // SpeedComboBox
           // 
           this.SpeedComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.SpeedComboBox.FormattingEnabled = true;
           this.SpeedComboBox.Items.AddRange(new object[] {
            "Ultimate+",
            "Ultimate",
            "Regular"});
           this.SpeedComboBox.Location = new System.Drawing.Point(114, 78);
           this.SpeedComboBox.Name = "SpeedComboBox";
           this.SpeedComboBox.Size = new System.Drawing.Size(121, 21);
           this.SpeedComboBox.TabIndex = 4;
           this.SpeedComboBox.TabStop = false;
           // 
           // label5
           // 
           this.label5.AutoSize = true;
           this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.label5.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label5.Location = new System.Drawing.Point(6, 55);
           this.label5.Name = "label5";
           this.label5.Size = new System.Drawing.Size(39, 13);
           this.label5.TabIndex = 3;
           this.label5.Text = "Mirror";
           // 
           // label4
           // 
           this.label4.AutoSize = true;
           this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.label4.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label4.Location = new System.Drawing.Point(6, 28);
           this.label4.Name = "label4";
           this.label4.Size = new System.Drawing.Size(89, 13);
           this.label4.TabIndex = 2;
           this.label4.Text = "max DM Count";
           // 
           // MaxDMCountEdit
           // 
           this.MaxDMCountEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.MaxDMCountEdit.Location = new System.Drawing.Point(173, 25);
           this.MaxDMCountEdit.Maximum = new decimal(new int[] {
            400,
            0,
            0,
            0});
           this.MaxDMCountEdit.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
           this.MaxDMCountEdit.Name = "MaxDMCountEdit";
           this.MaxDMCountEdit.Size = new System.Drawing.Size(62, 20);
           this.MaxDMCountEdit.TabIndex = 1;
           this.MaxDMCountEdit.TabStop = false;
           this.MaxDMCountEdit.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
           // 
           // MirrorComboBox
           // 
           this.MirrorComboBox.AutoCompleteCustomSource.AddRange(new string[] {
            "Normal",
            "Mirror",
            "Any"});
           this.MirrorComboBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.MirrorComboBox.FormattingEnabled = true;
           this.MirrorComboBox.Items.AddRange(new object[] {
            "Normal",
            "Mirror",
            "Normal & Mirror"});
           this.MirrorComboBox.Location = new System.Drawing.Point(114, 51);
           this.MirrorComboBox.Name = "MirrorComboBox";
           this.MirrorComboBox.Size = new System.Drawing.Size(121, 21);
           this.MirrorComboBox.TabIndex = 0;
           this.MirrorComboBox.TabStop = false;
           // 
           // panel3
           // 
           this.panel3.Controls.Add(this.textBox1);
           this.panel3.Controls.Add(this.panel4);
           this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
           this.panel3.Location = new System.Drawing.Point(261, 0);
           this.panel3.Name = "panel3";
           this.panel3.Size = new System.Drawing.Size(616, 278);
           this.panel3.TabIndex = 1;
           // 
           // textBox1
           // 
           this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
           this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.textBox1.Location = new System.Drawing.Point(0, 42);
           this.textBox1.Multiline = true;
           this.textBox1.Name = "textBox1";
           this.textBox1.Size = new System.Drawing.Size(616, 236);
           this.textBox1.TabIndex = 1;
           this.textBox1.TabStop = false;
           // 
           // panel4
           // 
           this.panel4.Controls.Add(this.label34);
           this.panel4.Controls.Add(this.label33);
           this.panel4.Controls.Add(this.comboBox1);
           this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
           this.panel4.Location = new System.Drawing.Point(0, 0);
           this.panel4.Name = "panel4";
           this.panel4.Size = new System.Drawing.Size(616, 42);
           this.panel4.TabIndex = 0;
           // 
           // label34
           // 
           this.label34.AutoSize = true;
           this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.label34.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label34.Location = new System.Drawing.Point(217, 21);
           this.label34.Name = "label34";
           this.label34.Size = new System.Drawing.Size(122, 13);
           this.label34.TabIndex = 23;
           this.label34.Text = "Text Representation";
           // 
           // label33
           // 
           this.label33.AutoSize = true;
           this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.label33.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label33.Location = new System.Drawing.Point(38, 21);
           this.label33.Name = "label33";
           this.label33.Size = new System.Drawing.Size(97, 13);
           this.label33.TabIndex = 22;
           this.label33.Text = "Decoded Data: ";
           // 
           // comboBox1
           // 
           this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.comboBox1.FormattingEnabled = true;
           this.comboBox1.Location = new System.Drawing.Point(345, 18);
           this.comboBox1.Name = "comboBox1";
           this.comboBox1.Size = new System.Drawing.Size(259, 21);
           this.comboBox1.TabIndex = 0;
           this.comboBox1.TabStop = false;
           this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
           // 
           // panel2
           // 
           this.panel2.Controls.Add(this.QualityGroupBox);
           this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
           this.panel2.Location = new System.Drawing.Point(0, 0);
           this.panel2.Name = "panel2";
           this.panel2.Size = new System.Drawing.Size(261, 278);
           this.panel2.TabIndex = 0;
           // 
           // QualityGroupBox
           // 
           this.QualityGroupBox.Controls.Add(this.panel5);
           this.QualityGroupBox.Controls.Add(this.label30);
           this.QualityGroupBox.Controls.Add(this.label27);
           this.QualityGroupBox.Controls.Add(this.TB_horizontal_print_growth);
           this.QualityGroupBox.Controls.Add(this.TB_vertical_print_growth);
           this.QualityGroupBox.Controls.Add(this.label26);
           this.QualityGroupBox.Controls.Add(this.label25);
           this.QualityGroupBox.Controls.Add(this.label24);
           this.QualityGroupBox.Controls.Add(this.TB_overall_grade);
           this.QualityGroupBox.Controls.Add(this.label23);
           this.QualityGroupBox.Controls.Add(this.TB_decode_grade);
           this.QualityGroupBox.Controls.Add(this.label22);
           this.QualityGroupBox.Controls.Add(this.TB_modulation_grade);
           this.QualityGroupBox.Controls.Add(this.label21);
           this.QualityGroupBox.Controls.Add(this.TB_fixed_pattern_damage_grade);
           this.QualityGroupBox.Controls.Add(this.TB_fixed_pattern_damage);
           this.QualityGroupBox.Controls.Add(this.label20);
           this.QualityGroupBox.Controls.Add(this.TB_unused_error_correction_grade);
           this.QualityGroupBox.Controls.Add(this.TB_unused_error_correction);
           this.QualityGroupBox.Controls.Add(this.label19);
           this.QualityGroupBox.Controls.Add(this.TB_symbol_contrast_grade);
           this.QualityGroupBox.Controls.Add(this.TB_symbol_contrast);
           this.QualityGroupBox.Controls.Add(this.label18);
           this.QualityGroupBox.Controls.Add(this.TB_grid_nonuniformity_grade);
           this.QualityGroupBox.Controls.Add(this.TB_grid_nonuniformity);
           this.QualityGroupBox.Controls.Add(this.label17);
           this.QualityGroupBox.Controls.Add(this.TB_axial_nonuniformity_grade);
           this.QualityGroupBox.Controls.Add(this.TB_axial_nonuniformity);
           this.QualityGroupBox.Controls.Add(this.label16);
           this.QualityGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
           this.QualityGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.QualityGroupBox.ForeColor = System.Drawing.SystemColors.Desktop;
           this.QualityGroupBox.Location = new System.Drawing.Point(0, 0);
           this.QualityGroupBox.Name = "QualityGroupBox";
           this.QualityGroupBox.Size = new System.Drawing.Size(261, 278);
           this.QualityGroupBox.TabIndex = 0;
           this.QualityGroupBox.TabStop = false;
           this.QualityGroupBox.Text = "Symbol Quality";
           // 
           // panel5
           // 
           this.panel5.BackColor = System.Drawing.SystemColors.ButtonShadow;
           this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
           this.panel5.Enabled = false;
           this.panel5.ForeColor = System.Drawing.SystemColors.Desktop;
           this.panel5.Location = new System.Drawing.Point(0, 234);
           this.panel5.Name = "panel5";
           this.panel5.Size = new System.Drawing.Size(260, 3);
           this.panel5.TabIndex = 28;
           // 
           // label30
           // 
           this.label30.AutoSize = true;
           this.label30.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label30.Location = new System.Drawing.Point(186, 247);
           this.label30.Name = "label30";
           this.label30.Size = new System.Drawing.Size(14, 13);
           this.label30.TabIndex = 27;
           this.label30.Text = "h";
           // 
           // label27
           // 
           this.label27.AutoSize = true;
           this.label27.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label27.Location = new System.Drawing.Point(115, 247);
           this.label27.Name = "label27";
           this.label27.Size = new System.Drawing.Size(14, 13);
           this.label27.TabIndex = 26;
           this.label27.Text = "v";
           // 
           // TB_horizontal_print_growth
           // 
           this.TB_horizontal_print_growth.BackColor = System.Drawing.SystemColors.Control;
           this.TB_horizontal_print_growth.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_horizontal_print_growth.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_horizontal_print_growth.Location = new System.Drawing.Point(200, 244);
           this.TB_horizontal_print_growth.Name = "TB_horizontal_print_growth";
           this.TB_horizontal_print_growth.ReadOnly = true;
           this.TB_horizontal_print_growth.Size = new System.Drawing.Size(49, 20);
           this.TB_horizontal_print_growth.TabIndex = 25;
           this.TB_horizontal_print_growth.TabStop = false;
           // 
           // TB_vertical_print_growth
           // 
           this.TB_vertical_print_growth.BackColor = System.Drawing.SystemColors.Control;
           this.TB_vertical_print_growth.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_vertical_print_growth.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_vertical_print_growth.Location = new System.Drawing.Point(132, 244);
           this.TB_vertical_print_growth.Name = "TB_vertical_print_growth";
           this.TB_vertical_print_growth.ReadOnly = true;
           this.TB_vertical_print_growth.Size = new System.Drawing.Size(49, 20);
           this.TB_vertical_print_growth.TabIndex = 24;
           this.TB_vertical_print_growth.TabStop = false;
           // 
           // label26
           // 
           this.label26.AutoSize = true;
           this.label26.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label26.Location = new System.Drawing.Point(6, 247);
           this.label26.Name = "label26";
           this.label26.Size = new System.Drawing.Size(77, 13);
           this.label26.TabIndex = 23;
           this.label26.Text = "Print Growth";
           // 
           // label25
           // 
           this.label25.AutoSize = true;
           this.label25.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label25.Location = new System.Drawing.Point(158, 21);
           this.label25.Name = "label25";
           this.label25.Size = new System.Drawing.Size(39, 13);
           this.label25.TabIndex = 22;
           this.label25.Text = "Value";
           // 
           // label24
           // 
           this.label24.AutoSize = true;
           this.label24.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label24.Location = new System.Drawing.Point(216, 21);
           this.label24.Name = "label24";
           this.label24.Size = new System.Drawing.Size(41, 13);
           this.label24.TabIndex = 21;
           this.label24.Text = "Grade";
           // 
           // TB_overall_grade
           // 
           this.TB_overall_grade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_overall_grade.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_overall_grade.Location = new System.Drawing.Point(219, 210);
           this.TB_overall_grade.Name = "TB_overall_grade";
           this.TB_overall_grade.ReadOnly = true;
           this.TB_overall_grade.Size = new System.Drawing.Size(34, 20);
           this.TB_overall_grade.TabIndex = 20;
           this.TB_overall_grade.TabStop = false;
           // 
           // label23
           // 
           this.label23.AutoSize = true;
           this.label23.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label23.Location = new System.Drawing.Point(6, 213);
           this.label23.Name = "label23";
           this.label23.Size = new System.Drawing.Size(85, 13);
           this.label23.TabIndex = 19;
           this.label23.Text = "Overall Grade";
           // 
           // TB_decode_grade
           // 
           this.TB_decode_grade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_decode_grade.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_decode_grade.Location = new System.Drawing.Point(219, 186);
           this.TB_decode_grade.Name = "TB_decode_grade";
           this.TB_decode_grade.ReadOnly = true;
           this.TB_decode_grade.Size = new System.Drawing.Size(34, 20);
           this.TB_decode_grade.TabIndex = 18;
           this.TB_decode_grade.TabStop = false;
           // 
           // label22
           // 
           this.label22.AutoSize = true;
           this.label22.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label22.Location = new System.Drawing.Point(6, 189);
           this.label22.Name = "label22";
           this.label22.Size = new System.Drawing.Size(89, 13);
           this.label22.TabIndex = 17;
           this.label22.Text = "Decode Grade";
           // 
           // TB_modulation_grade
           // 
           this.TB_modulation_grade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_modulation_grade.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_modulation_grade.Location = new System.Drawing.Point(219, 162);
           this.TB_modulation_grade.Name = "TB_modulation_grade";
           this.TB_modulation_grade.ReadOnly = true;
           this.TB_modulation_grade.Size = new System.Drawing.Size(34, 20);
           this.TB_modulation_grade.TabIndex = 16;
           this.TB_modulation_grade.TabStop = false;
           // 
           // label21
           // 
           this.label21.AutoSize = true;
           this.label21.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label21.Location = new System.Drawing.Point(6, 165);
           this.label21.Name = "label21";
           this.label21.Size = new System.Drawing.Size(69, 13);
           this.label21.TabIndex = 15;
           this.label21.Text = "Modulation";
           // 
           // TB_fixed_pattern_damage_grade
           // 
           this.TB_fixed_pattern_damage_grade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_fixed_pattern_damage_grade.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_fixed_pattern_damage_grade.Location = new System.Drawing.Point(219, 138);
           this.TB_fixed_pattern_damage_grade.Name = "TB_fixed_pattern_damage_grade";
           this.TB_fixed_pattern_damage_grade.ReadOnly = true;
           this.TB_fixed_pattern_damage_grade.Size = new System.Drawing.Size(34, 20);
           this.TB_fixed_pattern_damage_grade.TabIndex = 14;
           this.TB_fixed_pattern_damage_grade.TabStop = false;
           // 
           // TB_fixed_pattern_damage
           // 
           this.TB_fixed_pattern_damage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_fixed_pattern_damage.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_fixed_pattern_damage.Location = new System.Drawing.Point(152, 138);
           this.TB_fixed_pattern_damage.Name = "TB_fixed_pattern_damage";
           this.TB_fixed_pattern_damage.ReadOnly = true;
           this.TB_fixed_pattern_damage.Size = new System.Drawing.Size(53, 20);
           this.TB_fixed_pattern_damage.TabIndex = 13;
           this.TB_fixed_pattern_damage.TabStop = false;
           // 
           // label20
           // 
           this.label20.AutoSize = true;
           this.label20.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label20.Location = new System.Drawing.Point(6, 141);
           this.label20.Name = "label20";
           this.label20.Size = new System.Drawing.Size(132, 13);
           this.label20.TabIndex = 12;
           this.label20.Text = "Fixed Pattern Damage";
           // 
           // TB_unused_error_correction_grade
           // 
           this.TB_unused_error_correction_grade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_unused_error_correction_grade.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_unused_error_correction_grade.Location = new System.Drawing.Point(219, 114);
           this.TB_unused_error_correction_grade.Name = "TB_unused_error_correction_grade";
           this.TB_unused_error_correction_grade.ReadOnly = true;
           this.TB_unused_error_correction_grade.Size = new System.Drawing.Size(34, 20);
           this.TB_unused_error_correction_grade.TabIndex = 11;
           this.TB_unused_error_correction_grade.TabStop = false;
           // 
           // TB_unused_error_correction
           // 
           this.TB_unused_error_correction.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_unused_error_correction.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_unused_error_correction.Location = new System.Drawing.Point(152, 114);
           this.TB_unused_error_correction.Name = "TB_unused_error_correction";
           this.TB_unused_error_correction.ReadOnly = true;
           this.TB_unused_error_correction.Size = new System.Drawing.Size(53, 20);
           this.TB_unused_error_correction.TabIndex = 10;
           this.TB_unused_error_correction.TabStop = false;
           // 
           // label19
           // 
           this.label19.AutoSize = true;
           this.label19.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label19.Location = new System.Drawing.Point(6, 117);
           this.label19.Name = "label19";
           this.label19.Size = new System.Drawing.Size(139, 13);
           this.label19.TabIndex = 9;
           this.label19.Text = "Unused Error Corection";
           // 
           // TB_symbol_contrast_grade
           // 
           this.TB_symbol_contrast_grade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_symbol_contrast_grade.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_symbol_contrast_grade.Location = new System.Drawing.Point(219, 90);
           this.TB_symbol_contrast_grade.Name = "TB_symbol_contrast_grade";
           this.TB_symbol_contrast_grade.ReadOnly = true;
           this.TB_symbol_contrast_grade.Size = new System.Drawing.Size(34, 20);
           this.TB_symbol_contrast_grade.TabIndex = 8;
           this.TB_symbol_contrast_grade.TabStop = false;
           // 
           // TB_symbol_contrast
           // 
           this.TB_symbol_contrast.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_symbol_contrast.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_symbol_contrast.Location = new System.Drawing.Point(152, 90);
           this.TB_symbol_contrast.Name = "TB_symbol_contrast";
           this.TB_symbol_contrast.ReadOnly = true;
           this.TB_symbol_contrast.Size = new System.Drawing.Size(53, 20);
           this.TB_symbol_contrast.TabIndex = 7;
           this.TB_symbol_contrast.TabStop = false;
           // 
           // label18
           // 
           this.label18.AutoSize = true;
           this.label18.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label18.Location = new System.Drawing.Point(6, 93);
           this.label18.Name = "label18";
           this.label18.Size = new System.Drawing.Size(98, 13);
           this.label18.TabIndex = 6;
           this.label18.Text = "Symbol Contrast";
           // 
           // TB_grid_nonuniformity_grade
           // 
           this.TB_grid_nonuniformity_grade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_grid_nonuniformity_grade.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_grid_nonuniformity_grade.Location = new System.Drawing.Point(219, 66);
           this.TB_grid_nonuniformity_grade.Name = "TB_grid_nonuniformity_grade";
           this.TB_grid_nonuniformity_grade.ReadOnly = true;
           this.TB_grid_nonuniformity_grade.Size = new System.Drawing.Size(34, 20);
           this.TB_grid_nonuniformity_grade.TabIndex = 5;
           this.TB_grid_nonuniformity_grade.TabStop = false;
           // 
           // TB_grid_nonuniformity
           // 
           this.TB_grid_nonuniformity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_grid_nonuniformity.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_grid_nonuniformity.Location = new System.Drawing.Point(152, 66);
           this.TB_grid_nonuniformity.Name = "TB_grid_nonuniformity";
           this.TB_grid_nonuniformity.ReadOnly = true;
           this.TB_grid_nonuniformity.Size = new System.Drawing.Size(53, 20);
           this.TB_grid_nonuniformity.TabIndex = 4;
           this.TB_grid_nonuniformity.TabStop = false;
           // 
           // label17
           // 
           this.label17.AutoSize = true;
           this.label17.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label17.Location = new System.Drawing.Point(6, 69);
           this.label17.Name = "label17";
           this.label17.Size = new System.Drawing.Size(114, 13);
           this.label17.TabIndex = 3;
           this.label17.Text = "Grid Non-Unformity";
           // 
           // TB_axial_nonuniformity_grade
           // 
           this.TB_axial_nonuniformity_grade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_axial_nonuniformity_grade.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_axial_nonuniformity_grade.Location = new System.Drawing.Point(219, 42);
           this.TB_axial_nonuniformity_grade.Name = "TB_axial_nonuniformity_grade";
           this.TB_axial_nonuniformity_grade.ReadOnly = true;
           this.TB_axial_nonuniformity_grade.Size = new System.Drawing.Size(34, 20);
           this.TB_axial_nonuniformity_grade.TabIndex = 2;
           this.TB_axial_nonuniformity_grade.TabStop = false;
           // 
           // TB_axial_nonuniformity
           // 
           this.TB_axial_nonuniformity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
           this.TB_axial_nonuniformity.ForeColor = System.Drawing.SystemColors.WindowText;
           this.TB_axial_nonuniformity.Location = new System.Drawing.Point(152, 42);
           this.TB_axial_nonuniformity.Name = "TB_axial_nonuniformity";
           this.TB_axial_nonuniformity.ReadOnly = true;
           this.TB_axial_nonuniformity.Size = new System.Drawing.Size(53, 20);
           this.TB_axial_nonuniformity.TabIndex = 1;
           this.TB_axial_nonuniformity.TabStop = false;
           // 
           // label16
           // 
           this.label16.AutoSize = true;
           this.label16.ForeColor = System.Drawing.SystemColors.Desktop;
           this.label16.Location = new System.Drawing.Point(6, 45);
           this.label16.Name = "label16";
           this.label16.Size = new System.Drawing.Size(118, 13);
           this.label16.TabIndex = 0;
           this.label16.Text = "Axial Non-Unformity";
           // 
           // Form1
           // 
           this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
           this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
           this.ClientSize = new System.Drawing.Size(877, 631);
           this.Controls.Add(this.splitContainer1);
           this.Controls.Add(this.panel1);
           this.Name = "Form1";
           this.Text = "Demo Data Matrix Enterprise";
           this.panel1.ResumeLayout(false);
           this.panel1.PerformLayout();
           this.splitContainer1.Panel1.ResumeLayout(false);
           this.splitContainer1.Panel2.ResumeLayout(false);
           this.splitContainer1.ResumeLayout(false);
           ((System.ComponentModel.ISupportInitialize)(this.Img)).EndInit();
           this.SymbolsInfoGroupBox.ResumeLayout(false);
           this.SymbolsInfoGroupBox.PerformLayout();
           ((System.ComponentModel.ISupportInitialize)(this.SymbolNumber)).EndInit();
           this.OptionsGroupBox.ResumeLayout(false);
           this.OptionsGroupBox.PerformLayout();
           ((System.ComponentModel.ISupportInitialize)(this.MaxDMCountEdit)).EndInit();
           this.panel3.ResumeLayout(false);
           this.panel3.PerformLayout();
           this.panel4.ResumeLayout(false);
           this.panel4.PerformLayout();
           this.panel2.ResumeLayout(false);
           this.QualityGroupBox.ResumeLayout(false);
           this.QualityGroupBox.PerformLayout();
           this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog OpenDialog;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox TimeEdit;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox CountEdit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox rrEdit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.GroupBox SymbolsInfoGroupBox;
        private System.Windows.Forms.GroupBox OptionsGroupBox;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox Img;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown MaxDMCountEdit;
        private System.Windows.Forms.ComboBox MirrorComboBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox QualityComboBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox LabelComboBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox SpeedComboBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox CellColorComboBox;
        private System.Windows.Forms.NumericUpDown SymbolNumber;
        private System.Windows.Forms.TextBox MirroredTextBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox DotPeenTextBox;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox RSErrTextBox;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox HDimTextBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox VDimTextBox;
        //private System.Windows.Forms.TextBox TB_QZ_damage_grade;
        //private System.Windows.Forms.TextBox TB_QZ_damage;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ComboBox FilterComboBox;
        private System.Windows.Forms.ComboBox QzComboBox;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox TB_SymbologyID;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox TB_ActColor;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox QualityGroupBox;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox TB_horizontal_print_growth;
        private System.Windows.Forms.TextBox TB_vertical_print_growth;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox TB_overall_grade;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox TB_decode_grade;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox TB_modulation_grade;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox TB_fixed_pattern_damage_grade;
        private System.Windows.Forms.TextBox TB_fixed_pattern_damage;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox TB_unused_error_correction_grade;
        private System.Windows.Forms.TextBox TB_unused_error_correction;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox TB_symbol_contrast_grade;
        private System.Windows.Forms.TextBox TB_symbol_contrast;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox TB_grid_nonuniformity_grade;
        private System.Windows.Forms.TextBox TB_grid_nonuniformity;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox TB_axial_nonuniformity_grade;
        private System.Windows.Forms.TextBox TB_axial_nonuniformity;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label LabelFileName;
    }
}

