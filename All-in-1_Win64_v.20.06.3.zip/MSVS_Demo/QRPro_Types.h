
#ifndef QRPro_Types
#define QRPro_Types

enum QRCELL_COLOR{
 QRCL_BLACKONWHITE = 1
,QRCL_WHITEONBLACK = 2
,QRCL_ANY          = 3
};

enum QRMIRROR_MODE{
 QRMM_NORMAL   = 1
,QRMM_MIRROR   = 2
,QRMM_ANY      = 3
};

enum QRDECODER_SPEED{
 QRSP_ROBUST   = 0
};

enum QRLABEL_MODE{
 QRLM_STANDARD = 0     //!<-ISO 18004 with restrictions
};

/// \enum QUALITY_MASK bits of mask:
enum QRQUALITY_MASK{
 QR_QM_NO       = 0X0000
,QR_QM_ALL      = 0x7FFF
};

enum QRFILTER_MODE{
 QRFM_NON         = 0  //!< no filter
,QRFM_AUTO        = 1  //!< filter with digital auto-focus
,QRFM_DOT_PEEN    = 2 // dot peen sample to standard
};

enum QRSYMBOL_MODE{
 QRC_NORMAL = 0     //!<- Ordinary QR Code (with 3 finder patterns)
,QRC_MICRO  = 1     //!<- Micro QR Code (1 finder pattern)
,QRC_ANY    = 2     //!<- Symbols of both type will be decoded simultaneously
};

enum QRQZ_MODE{
 QRQZ_STANDARD = 0 //!< allows QZ>= 3 module sizes, decoder in average more fast and robust
,QRQZ_SMALL    = 1 //!< allows QZ>= 1 module size, affects speed and robustness
};

enum QR_BREAK_REASON{
//----------------------
 QR_ALL_INSPECTED    = 0 //!< no breaks occurred
,QR_TIMEOUT          = 1 //!< termination by time out
,QR_TERMINATED       = 2 //!< termination by user break
};
//=========================================

// QR_REJECTION_REASON
enum QR_REJECTION_REASON
{
 QR_SUCCESSFUL         = 0,
 QR_NO_IMAGE_FOUND     = 2,
 QR_POOR_IMAGE_QUALITY = 3,
 QR_ERROR_OF_RS_CODE   = 4,
 QR_ERR_DECODE         = 5,
 QR_ERR_MODE           = 6,
 QR_LICENSE_EXPIRED    = 7,

 QR_MODE_STRUCTURED_APPEND = 10,
 QR_MODE_ECI_BASIC         = 11,
 QR_MODE_ECI_BEGIN         = 12,
 QR_MODE_ECI_END           = 13
};

typedef struct
{
  int QRCount;        //!< number of well decoded symbols within image
  int RejectionReason;//!< not QR_SUCCESSFUL if no one QR Code was decoded
  int BreakReason;    //!< 0 - normal termination, 1 - termination by time-out

// D E B U G
  int maxtime, maxpoint, timercall;
// D E B U G

 } TQR_ImageInfo;

typedef struct {
  float sc;    //!< Symbol Contrast
  float an;    //!< Axial Non uniformity
  float gn;    //!< Grid  Non uniformity
  float uec;   //!< Unused Error Correction
/// Grades:
  float scG;   //!< Symbol Contrast Grade
  float anG;   //!< Axial Non uniformity Grade
  float gnG;   //!< Grid  Non uniformity Grade
  float uecG;  //!< Unused Error Correction Grade
  float modG;  //!< Modulation Grade
  float fpdG;  //!< Fixed Pattern Damage Grade
  float frmG;  //!< Format Grade
  float verG;  //!< Version Grade
  float deG;   //!< Decode Grade
  float scanG; //!< Scan Grade (minimum of Grades)
} TQR_Quality;

typedef struct
{
  int maxQRCount;   //!< 1..10
  int cellColor;    //!< CL_BLACKONWHITE | QRCL_WHITEONBLACK | QRCL_ANY
  int mirrorMode;   //!< MM_NORMAL, ...
  int speedMode;    //!< Always SP_ROBUST
  int qualityMask;  //!< 0 � no QP, 1 � estimate QP, (0 by default)
  int labelMode;    //!< Always LM_NORMAL
  int timeOut;      //!< timeOut in mls.
  int filterMode;   //!< QRFM_NON | QRFM_AUTO
  int symbology;    //!< QRC_NORMAL | QRC_MICRO | QRC_ANY
  int qzMode;       //!< QRQZ_STANDARD | QRQZ_SMALL
} TQR_OptMode;

/// result of decoding of each QRCode symbol in image
typedef struct
{
  float    rowcols[8];  //!< symbol corner coordinates
  int      pchlen;	    //!< length of decoded byte array
  unsigned short* pch2; //!< pointer to 2-byte array (Unicode characters)
  int      RSErr;	    //!< number of Reed Solomon errors
  int      Dim;	        //!< dimension of QR Code
  int      Version;     //!< 1..40
  int      level;       //!< ' ', 'L', 'M', 'Q', 'H'
  int      Mask;        //!< 1..9
  int      Micro_QRC;   //!< ==0 for QRC,  ==1 for Micro QRC
  int      Color;       //!< 1 - black, 2 - white
  int      Mirrored;
  TQR_Quality quality;  //!< symbol Quality Parameters
} TQR_Info;

//=========================================
typedef void*           PQR_Decoder;   //!< handler of QR Code Decoder
typedef void*           PQR_Options;   //!< handler of Decoder Options
typedef TQR_ImageInfo*  PQR_ImageInfo; //!< pointer to Image Info
typedef TQR_OptMode*    PQR_OptMode;   //!< pointer to Options mode
typedef TQR_Quality*    PQR_Quality;   //!< pointer to symbol Quality
typedef TQR_Info*       PQR_Info;      //!< pointer to symbol Info
typedef unsigned char*  TRow;          //!< pointer to bitmap line

//=============================================================================
//  Interface of Library (Professional)
//

#ifdef __cplusplus
#define EXTERN_C extern "C"
#endif
#if (defined WIN32) || (defined _WIN64)
#define CALL_TYPE __stdcall
#elif defined __ANDROID__
#define CALL_TYPE
#else
#define CALL_TYPE
#endif

// Connect Decoder
EXTERN_C PQR_Decoder CALL_TYPE Connect_QR_Decoder(int maxrowcount, int maxcolcount);

// DisConnect Decoder
EXTERN_C void        CALL_TYPE Disconnect_QR_Decoder(PQR_Decoder pDecoder);

/// The function creates Decoder Options and returns Options handler
EXTERN_C PQR_Options CALL_TYPE Create_QR_Options(PQR_Decoder pDecoder, TQR_OptMode optmode);

/// The function destroys Decoder Options
EXTERN_C void        CALL_TYPE Delete_QR_Options(PQR_Options pOptions);

/// The function decodes array ppbits with given Options
EXTERN_C int         CALL_TYPE DecodeQR_Bits(PQR_Options pOptions, int rowcount, int colcount, TRow* ppbits);

/// The function returns the ImageInfo of last decoded Image
EXTERN_C PQR_ImageInfo CALL_TYPE GetQR_ImageInfo(PQR_Options pOptions);

/// The function returns the QR_Info[qrNum]
EXTERN_C PQR_Info      CALL_TYPE GetQR_Info(PQR_Options pOptions, int qrNum);

/// The function returns OptMode of current Options
EXTERN_C PQR_OptMode   CALL_TYPE GetQR_OptMode(PQR_Options pOptions);


EXTERN_C const char* CALL_TYPE  GetVersionDate_QR(void);
EXTERN_C const char* CALL_TYPE  GetVersionTime_QR(void);
EXTERN_C const char* CALL_TYPE Get_QR_Version(void);

//------------------------------------------------------------------------------------------------
//        Pointer types to DLL functions. NOT using for static library or .so library
//------------------------------------------------------------------------------------------------
// Connect Decoder
typedef PQR_Decoder (CALL_TYPE *TConnect_QR_Decoder)(int maxrowcount, int maxcolcount);

// DisConnect Decoder
typedef void        (CALL_TYPE *TDisconnect_QR_Decoder)(PQR_Decoder pDecoder);

/// The function creates Decoder Options and returns Options handler
typedef PQR_Options (CALL_TYPE *TCreate_QR_Options)(PQR_Decoder pDecoder, TQR_OptMode optmode);

/// The function creates Decoder Options and returns Options handler
typedef PQR_Options (CALL_TYPE *TCreate_QR_OptionsP)
 ( PQR_Decoder pDecoder
  ,int maxQRCount   //!< 1..10
  ,int cellColor    //!< CL_BLACKONWHITE | QRCL_WHITEONBLACK | QRCL_ANY
  ,int mirrorMode   //!< MM_NORMAL, ...
  ,int speedMode    //!< Always SP_ROBUST
  ,int qualityMask  //!< 0 � no QP, 1 � estimate QP, (0 by default)
  ,int labelMode    //!< Always LM_NORMAL
  ,int timeOut      //!< timeOut in mls (N/A).
  ,int filterMode   //!< QRFM_NON | QRFM_AUTO
  ,int symbology    //!< QRC_NORMAL | QRC_MICRO | QRC_ANY
  ,int qzMode       //!< QRQZ_STANDARD | QRQZ_SMALL
 );

/// The function destroys Decoder Options
typedef void        (CALL_TYPE *TDelete_QR_Options)(PQR_Options pOptions);

/// The function decodes array ppbits with given Options
typedef int         (CALL_TYPE *TDecodeQR_Bits)(PQR_Options pOptions, int rowcount, int colcount, TRow* ppbits);

/// The function returns the ImageInfo of last decoded Image
typedef PQR_ImageInfo (CALL_TYPE *TGetQR_ImageInfo)(PQR_Options pOptions);

/// The function returns the QR_Info[qrNum]
typedef PQR_Info      (CALL_TYPE *TGetQR_Info)(PQR_Options pOptions, int qrNum);

typedef PQR_OptMode   (CALL_TYPE *TGetQR_OptMode)(PQR_Options pOptions);

#endif
