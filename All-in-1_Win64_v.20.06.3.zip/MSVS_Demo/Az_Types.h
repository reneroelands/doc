#ifndef Include_Az_Tupes_h
#define Include_Az_Tupes_h

enum AZ_DECODER_SPEED{
 AZ_SP_ROBUST   = 0
};

/// \enum QUALITY_MASK bits of mask:
enum AZ_QUALITY_MASK{
 AZ_QM_NO       = 0X0000
,AZ_QM_ALL      = 0x7FFF
};

enum AZ_FILTER_MODE{
 AZ_FM_NON         = 0  //!< no filter
,AZ_FM_AUTO        = 1  //!< filter with digital auto-focus
};

enum AZ_SYMBOL_MODE{
 AZ_S_NORMAL = 0     //!<- Ordinary Aztec Code
,AZ_S_RUNES  = 1     //!<- Runes Aztec Code
};

enum AZ_QZ_MODE{
 AZ_QZ_STANDARD = 0 //!< allows QZ>= 3 module sizes, decoder in average more fast and robust
,AZ_QZ_SMALL    = 1 //!< allows QZ>= 1 module size, affects speed and robustness
};

enum AZ_BREAK_REASON{
//----------------------
 AZ_ALL_INSPECTED    = 0 //!< no breaks occurred
,AZ_TIMEOUT          = 1 //!< termination by time out
,AZ_TERMINATED       = 2 //!< termination by user break
};
//=========================================

struct TAZ_ImageInfo
{
  int AZCount;        //!< number of well decoded symbols within image
  int RejectionReason;//!< not AZ_SUCCESSFUL if no one AZ Code was decoded
  int BreakReason;    //!< 0 - normal termination, 1 - termination by time-out

// D E B U G
  int maxtime, maxpoint, timercall;
// D E B U G

 };
//=========================================

struct TAZ_OptMode
{
  int maxAZCount;   //!< 1..10
  int speedMode;    //!< Always SP_ROBUST
  int qualityMask;  //!< 0 � no QP, 1 � estimate QP, (0 by default)
  int labelMode;    //!< Always LM_NORMAL
  int cellColor;
  int timeOut;      //!< timeOut in mls.
  int filterMode;   //!< AZFM_NON | AZFM_AUTO
  int symbology;    //!< AZ_S_NORMAL | AZ_S_RUNES
  int qzMode;       //!< AZ_QZ_STANDARD | AZ_QZ_SMALL
};
//=========================================
struct TAZ_Quality{
  float sc;    //!< Symbol Contrast
  float an;    //!< Axial Non uniformity
  float gn;    //!< Grid  Non uniformity
  float uec;   //!< Unused Error Correction
/// Grades:
  float scG;   //!< Symbol Contrast Grade
  float anG;   //!< Axial Non uniformity Grade
  float gnG;   //!< Grid  Non uniformity Grade
  float uecG;  //!< Unused Error Correction Grade
  float modG;  //!< Modulation Grade
  float fpdG;  //!< Fixed Pattern Damage Grade
  float deG;   //!< Decode Grade
  float scanG; //!< Scan Grade (minimum of Grades)
};

//=========================================
/// result of decoding of each AZCode symbol in image
struct TAZ_Info
{
  float    rowcols[8];  //!< symbol corner coordinates
  int      pchlen;	    //!< length of decoded byte array
  char*    pch;         //!< pointer to 2-byte array (Unicode characters)
  int      RSErr;	      //!< number of Reed Solomon errors
  int      Dim;	        //!< dimension of AZ Code
  int      Rune_AZS;    //!< ==0 for AZC,  ==1 for compact,  ==2 for Rune
  int      Layers;
  int      MSGLen;
  TAZ_Quality quality;  //!< symbol Quality Parameters
};

//=========================================
typedef void*           PAZ_Decoder;   //!< handler of AZ Code Decoder
typedef void*           PAZ_Options;   //!< handler of Decoder Options
typedef TAZ_ImageInfo*  PAZ_ImageInfo; //!< pointer to Image Info
typedef TAZ_OptMode*    PAZ_OptMode;   //!< pointer to Options mode
typedef TAZ_Quality*    PAZ_Quality;   //!< pointer to symbol Quality
typedef TAZ_Info*       PAZ_Info;      //!< pointer to symbol Info

typedef unsigned char*  TRow;          //!< pointer to bitmap line

//=============================================================================
//  Interface of Library (Professional)
//

#if (defined WIN32) || (defined _WIN64)
#define CALL_TYPE __stdcall
#elif defined(__linux__)
#define CALL_TYPE
#endif 

extern "C"
{
// Connect Decoder
PAZ_Decoder CALL_TYPE Connect_AZ_Decoder(int maxrowcount, int maxcolcount);

// DisConnect Decoder
void        CALL_TYPE Disconnect_AZ_Decoder(PAZ_Decoder& pDecoder);

/// The function creates Decoder Options and returns Options handler
PAZ_Options CALL_TYPE Create_AZ_Options(PAZ_Decoder pDecoder, TAZ_OptMode optmode);

/// The function destroys Decoder Options
void        CALL_TYPE Delete_AZ_Options(PAZ_Options pOptions);

/// The function decodes array ppbits with given Options
int CALL_TYPE Decode_AZ_Bits(PAZ_Options pOptions, int rowcount, int colcount, TRow* ppbits);

/// The function returns the ImageInfo of last decoded Image
PAZ_ImageInfo CALL_TYPE Get_AZ_ImageInfo(PAZ_Options pOptions);

/// The function returns the AZ_Info[qrNum]
PAZ_Info      CALL_TYPE Get_AZ_Info(PAZ_Options pOptions, int qrNum);

/// The function returns OptMode of current Options
PAZ_OptMode   CALL_TYPE GetAZ_OptMode(PAZ_Options pOptions);
};

#ifdef __linux__
#define __stdcall
#endif

// Connect Decoder
typedef PAZ_Decoder (__stdcall *TConnect_AZ_Decoder)(int maxrowcount, int maxcolcount);

// DisConnect Decoder
typedef void        (__stdcall *TDisconnect_AZ_Decoder)(PAZ_Decoder &pDecoder);

/// The function creates Decoder Options and returns Options handler
typedef PAZ_Options (__stdcall *TCreate_AZ_Options)(PAZ_Decoder pDecoder, TAZ_OptMode optmode);

/// The function destroys Decoder Options
typedef void        (__stdcall *TDelete_AZ_Options)(PAZ_Options pOptions);

/// The function decodes array ppbits with given Options
typedef int (__stdcall *TDecode_AZ_Bits)(PAZ_Options pOptions, int rowcount, int colcount, TRow* ppbits);

/// The function returns the ImageInfo of last decoded Image
typedef PAZ_ImageInfo (__stdcall *TGet_AZ_ImageInfo)(PAZ_Options pOptions);

/// The function returns the AZ_Info[qrNum]
typedef PAZ_Info      (__stdcall *TGet_AZ_Info)(PAZ_Options pOptions, int qrNum);

/// The function returns OptMode of current Options
typedef PAZ_OptMode   (__stdcall *TGetAZ_OptMode)(PAZ_Options pOptions);

#endif
