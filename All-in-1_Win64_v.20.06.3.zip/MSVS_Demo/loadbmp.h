//---------------------------------------------------------------------------

#if !defined(INCLUDED_LoadBMP_H)
#define INCLUDED_LoadBMP_H

int  LoadBMP ( char* lpFileName, unsigned char**  A, int & He, int & Wi);
char* LoadBMPResult(int res);

#endif
