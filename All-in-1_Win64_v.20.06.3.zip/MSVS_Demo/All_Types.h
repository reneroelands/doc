
#ifndef AllH
#define AllH

#ifdef __linux__
extern "C" {
int Connect_Total_Decoder();
};
#else
extern int __stdcall Connect_Total_Decoder();
#endif

#ifdef __linux__
#define __stdcall
#endif

typedef int (__stdcall *TConnect_Total_Decoder) ();
#endif
