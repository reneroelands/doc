//PDF417PRO_Types.h
//---------------------------------------------------------------------------

#ifndef PDF417PRO_Types_H
#define PDF417PRO_Types_H

typedef unsigned char icByte;
typedef icByte* icPByte;

#ifndef ErrorCodes_Consts
#define ErrorCodes_Consts
const int// error codes

// ############################################################################
  PDF417_OK                   =   0,
  PDF417_Rectangle_Error      =  -1, // no Start and Stop Patterns were found
  PDF417_ColCount_Error       =  -4,
  PDF417_RowCount_Error       =  -5,
  PDF417_ECCodeword_Error     =  -6,
  PDF417_ErasuresLimit_Error  =  -7, // too many codewords with improper clasters
  PDF417_RS_Error             =  -8, // too many errors in Reed Solomon code
  PDF417_CharEncodation_Error =  -9, // unexpected encodation scheme
  PDF417_StartPattern_Error   = -10, // Stop pattern is not found
  PDF417_StopPattern_Error    = -11, // Stop pattern is not found
  PDF417_Indicators_Error     = -12, // incorrect data in row indicators
  PDF417_Geometry_Error       = -13; // unallowed module size

const int// error codes
  PDF417_NOMEMORY             = -99,
  PDF417_UNKNOWN              = -100,
  PDF417_DISCONNECTED         = -200;

const int// Break Codes
  ALL_INSPECTED               = 0,
  TIMEOUT                     = 1,
  TERMINATED                  = 2;

#endif


typedef void* PPDF417_Decoder;
typedef void* PPDF417_Options;


typedef int TPDF417_SpeedMode;
const TPDF417_SpeedMode
  SP_Fast   = 1,
  SP_Robust = 0,
  SP_Smart  = 2;

typedef int TPDF417_CalcGrade;
const TPDF417_CalcGrade
  CG_No  = 0,
  CG_Yes = 1;

typedef int TPDF417_DirectMode;
const TPDF417_DirectMode
  DM_LeftRight  = 0,
  DM_Horizontal = 1,
  DM_All        = 2,
  DM_Vertical   = 3;

typedef struct
{
  int MaxSymbolCount;            // maximum number of decoded PDF417 labels
  TPDF417_SpeedMode  SpeedMode;  //  SP_Fast,  SP_Robust
  TPDF417_CalcGrade  CalcGrade;  //  CG_No , CG_Yes ;
  TPDF417_DirectMode DirectMode; //  DM_LeftRight, DM_Horizontal, DM_All
  int BWFilter;                  // 0: none, +1 => BW+1,  -1 => BW-1
  int TimeOut;                   // in milliseconds, zero - not timeout
  int ScanStep;
} TPDF417_OptMode;

typedef struct
{
    int SymbolCount;       // count of decoded PDF417 symbols
    int RejectionReason;   // Result
    char* RejectionString; // pointer to error string
    int BreakReason;       //
    char* BreakString;     // pointer to error string
} TPDF417_ImageInfo;

typedef struct
{
  // 0..100                    , -1 = have not been calculated
  float symbol_contrast;            // symbol contrast(SC)  = Rmax-Rmin
  float min_reflectance;            // Rmin
  float max_reflectance;            // Rmax
  float global_threshold;           // global_threshold(GT) = (Rmax+Rmin)/2
  float min_edge_contrast;          // ECmin
  float modulation;                 // modulation (MOD)     = ECmin/SC
  float defects;                    //
  float decodability;               // V
  float width_height_proportion;
  float unused_error_correction;    // UEC

  // grades
  // 0..4,  0 = Worst , 4 = Best, -1 = have not been calculated
  float decode_grade;
  float symbol_contrast_grade;
  float min_reflectance_grade;
  float min_edge_contrast_grade;
  float modulation_grade;
  float defects_grade;
  float decodability_grade;
  float unused_error_correction_grade;

  float overall_grade;
} TPDF417_Quality;

typedef struct  // //result of decoding per each PDF417 symbol
{
  int RejectionReason;     // Result
  int rowcols[8];    // symbol corners
  int rcFlag;        // true if a qudrangle symbol was found
  int RSErrorCount;  // number of Reed Solomon errors
  int ColCount;      // horizontal dimension (from 1 to 30)
  int RowCount;      // vertical dimension   (from 4 to 90)
  char* RejectionString; // pointer to error string
  int ECLevel;       // Error Correction Level (from 0 to 8)
  int pchlen;        // length of decoded byte array
  unsigned char* pch;// decoded byte array
  char* c_str;       // decoded char array (points to the same allocation in memory)
  TPDF417_Quality Quality;
} TPDF417_Info;

typedef unsigned char*  TRow;  // pointer to bitmap line

#if (defined WIN32) || (defined _WIN64)
#define CALL_TYPE __stdcall
#else
#define CALL_TYPE
#endif

extern "C" PPDF417_Decoder  CALL_TYPE Connect_PDF417_Decoder(int maxrowcount, int maxcolcount);
extern "C" void             CALL_TYPE Disconnect_PDF417_Decoder(PPDF417_Decoder& decoder);

extern "C" PPDF417_Options  CALL_TYPE Create_PDF417_Options(PPDF417_Decoder O, TPDF417_OptMode OptMode);
extern "C" void             CALL_TYPE Delete_PDF417_Options(PPDF417_Options& options);

extern "C" int              CALL_TYPE Decode_PDF417_Bits(PPDF417_Options options, int rowcount, int colcount, unsigned char** pbits);
extern "C" int              CALL_TYPE DecodePDF417_Bits(PPDF417_Options options, int rowcount, int colcount, unsigned char** pbits);

/*
  Description
This function decodes a PDF417 symbol in the scanned grayscale
image and calculates the symbol's parameters that can be inspected
by another DLL functions.

  Parameters.
rowcount - Specifies the number of rows in the image.
colcount - Specifies the number of columns.
pbits    - Points to an array pbits[0], pbits[1], ..., of pointers to bitmap lines.
           The lines are to be obtained by ScanLine function (see Borland VCL),
           or by GetDIBits function (Windows API) if the image has been loaded
           from the BMP file.
           The image must be scanned in a grayscale palette.

  Return Value
-1         Error4
 0         PDF417 symbol has not been found in the bitmap
 1         PDF417 symbol has been found in the bitmap
*/
extern "C" TPDF417_ImageInfo* CALL_TYPE GetPDF417_ImageInfo(PPDF417_Options);

extern "C" TPDF417_Info*      CALL_TYPE GetPDF417_Info(PPDF417_Options, int);

#ifndef __stdcall
#define __stdcall 
#endif
typedef   PPDF417_Decoder(__stdcall *TConnect_PDF417_Decoder)(int, int);
typedef   void           (__stdcall *TDisconnect_PDF417_Decoder)(PPDF417_Decoder&);
typedef   PPDF417_Options(__stdcall *TCreate_PDF417_Options)(PPDF417_Decoder, TPDF417_OptMode);
typedef   void           (__stdcall *TDelete_PDF417_Options)(PPDF417_Options&);
typedef   int            (__stdcall *TDecodePDF417_Bits)(PPDF417_Options, int, int, unsigned char **);
typedef   TPDF417_ImageInfo*(__stdcall *TGetPDF417_ImageInfo)(PPDF417_Options);
typedef   TPDF417_Info*  (__stdcall *TGetPDF417_Info)(PPDF417_Options, int);

#endif

