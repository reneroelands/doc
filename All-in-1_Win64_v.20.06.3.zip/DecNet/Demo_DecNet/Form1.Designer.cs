﻿namespace DecNet
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
          this.checkedLB = new System.Windows.Forms.CheckedListBox();
          this.BnLoad = new System.Windows.Forms.Button();
          this.BnDecode = new System.Windows.Forms.Button();
          this.OpenDialog = new System.Windows.Forms.OpenFileDialog();
          this.panel1 = new System.Windows.Forms.Panel();
          this.label34 = new System.Windows.Forms.Label();
          this.comboBox1 = new System.Windows.Forms.ComboBox();
          this.TypeCodeL = new System.Windows.Forms.Label();
          this.label1 = new System.Windows.Forms.Label();
          this.TimeEdit = new System.Windows.Forms.TextBox();
          this.LabelFileName = new System.Windows.Forms.Label();
          this.panel2 = new System.Windows.Forms.Panel();
          this.panel3 = new System.Windows.Forms.Panel();
          this.panel4 = new System.Windows.Forms.Panel();
          this.richTB = new System.Windows.Forms.RichTextBox();
          this.panel5 = new System.Windows.Forms.Panel();
          this.Img = new System.Windows.Forms.PictureBox();
          this.panel1.SuspendLayout();
          this.panel3.SuspendLayout();
          this.panel4.SuspendLayout();
          this.panel5.SuspendLayout();
          ((System.ComponentModel.ISupportInitialize)(this.Img)).BeginInit();
          this.SuspendLayout();
          // 
          // checkedLB
          // 
          this.checkedLB.FormattingEnabled = true;
          this.checkedLB.Items.AddRange(new object[] {
            "1D regular",
            "GS1 Databar",
            "PostNet",
            "IMB",
            "NZPost (neg)",
            "SwissPost (neg)",
            "Data Matrix",
            "QR Code",
            "PDF417",
            "Aztec"});
          this.checkedLB.Location = new System.Drawing.Point(12, 6);
          this.checkedLB.Name = "checkedLB";
          this.checkedLB.Size = new System.Drawing.Size(118, 154);
          this.checkedLB.TabIndex = 0;
          this.checkedLB.SelectedIndexChanged += new System.EventHandler(this.checkedLB_SelectedIndexChanged);
          // 
          // BnLoad
          // 
          this.BnLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
          this.BnLoad.Location = new System.Drawing.Point(26, 3);
          this.BnLoad.Name = "BnLoad";
          this.BnLoad.Size = new System.Drawing.Size(93, 23);
          this.BnLoad.TabIndex = 1;
          this.BnLoad.Text = "Load Image";
          this.BnLoad.UseVisualStyleBackColor = true;
          this.BnLoad.Click += new System.EventHandler(this.BnLoad_Click);
          // 
          // BnDecode
          // 
          this.BnDecode.Enabled = false;
          this.BnDecode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
          this.BnDecode.Location = new System.Drawing.Point(144, 3);
          this.BnDecode.Name = "BnDecode";
          this.BnDecode.Size = new System.Drawing.Size(98, 23);
          this.BnDecode.TabIndex = 2;
          this.BnDecode.Text = "Decode Image";
          this.BnDecode.UseVisualStyleBackColor = true;
          this.BnDecode.Click += new System.EventHandler(this.BnDecode_Click);
          // 
          // OpenDialog
          // 
          this.OpenDialog.Filter = "All (*.jpg;*.jpeg;*.gif;*.bmp;*.tif)|*.jpg;*.jpeg;*.gif;*.bmp;*.tif;*.tiff|JPEG I" +
              "mage File (*.jpg)|*.jpg|JPEG Image File (*.jpeg)|*.jpeg|Bitmaps (*.bmp)|*.bmp|Ti" +
              "f Image File (*.tif)|*.tif;*.tiff";
          // 
          // panel1
          // 
          this.panel1.Controls.Add(this.label34);
          this.panel1.Controls.Add(this.comboBox1);
          this.panel1.Controls.Add(this.TypeCodeL);
          this.panel1.Controls.Add(this.label1);
          this.panel1.Controls.Add(this.TimeEdit);
          this.panel1.Controls.Add(this.LabelFileName);
          this.panel1.Controls.Add(this.BnLoad);
          this.panel1.Controls.Add(this.BnDecode);
          this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
          this.panel1.Location = new System.Drawing.Point(0, 0);
          this.panel1.Name = "panel1";
          this.panel1.Size = new System.Drawing.Size(904, 65);
          this.panel1.TabIndex = 3;
          // 
          // label34
          // 
          this.label34.AutoSize = true;
          this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
          this.label34.ForeColor = System.Drawing.SystemColors.Desktop;
          this.label34.Location = new System.Drawing.Point(508, 41);
          this.label34.Name = "label34";
          this.label34.Size = new System.Drawing.Size(122, 13);
          this.label34.TabIndex = 25;
          this.label34.Text = "Text Representation";
          // 
          // comboBox1
          // 
          this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
          this.comboBox1.FormattingEnabled = true;
          this.comboBox1.Location = new System.Drawing.Point(636, 38);
          this.comboBox1.Name = "comboBox1";
          this.comboBox1.Size = new System.Drawing.Size(259, 21);
          this.comboBox1.TabIndex = 24;
          this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
          // 
          // TypeCodeL
          // 
          this.TypeCodeL.AutoSize = true;
          this.TypeCodeL.Location = new System.Drawing.Point(701, 13);
          this.TypeCodeL.Name = "TypeCodeL";
          this.TypeCodeL.Size = new System.Drawing.Size(10, 13);
          this.TypeCodeL.TabIndex = 6;
          this.TypeCodeL.Text = "-";
          // 
          // label1
          // 
          this.label1.AutoSize = true;
          this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
          this.label1.ForeColor = System.Drawing.SystemColors.Desktop;
          this.label1.Location = new System.Drawing.Point(545, 6);
          this.label1.Name = "label1";
          this.label1.Size = new System.Drawing.Size(53, 13);
          this.label1.TabIndex = 5;
          this.label1.Text = "Time ms";
          // 
          // TimeEdit
          // 
          this.TimeEdit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
          this.TimeEdit.Location = new System.Drawing.Point(604, 6);
          this.TimeEdit.Name = "TimeEdit";
          this.TimeEdit.ReadOnly = true;
          this.TimeEdit.Size = new System.Drawing.Size(57, 20);
          this.TimeEdit.TabIndex = 4;
          this.TimeEdit.TabStop = false;
          // 
          // LabelFileName
          // 
          this.LabelFileName.AutoSize = true;
          this.LabelFileName.Location = new System.Drawing.Point(30, 40);
          this.LabelFileName.Name = "LabelFileName";
          this.LabelFileName.Size = new System.Drawing.Size(10, 13);
          this.LabelFileName.TabIndex = 3;
          this.LabelFileName.Text = "-";
          // 
          // panel2
          // 
          this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
          this.panel2.Location = new System.Drawing.Point(0, 383);
          this.panel2.Name = "panel2";
          this.panel2.Size = new System.Drawing.Size(904, 83);
          this.panel2.TabIndex = 4;
          // 
          // panel3
          // 
          this.panel3.Controls.Add(this.checkedLB);
          this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
          this.panel3.Location = new System.Drawing.Point(0, 65);
          this.panel3.Name = "panel3";
          this.panel3.Size = new System.Drawing.Size(149, 318);
          this.panel3.TabIndex = 5;
          // 
          // panel4
          // 
          this.panel4.Controls.Add(this.richTB);
          this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
          this.panel4.Location = new System.Drawing.Point(627, 65);
          this.panel4.Name = "panel4";
          this.panel4.Size = new System.Drawing.Size(277, 318);
          this.panel4.TabIndex = 6;
          // 
          // richTB
          // 
          this.richTB.Dock = System.Windows.Forms.DockStyle.Fill;
          this.richTB.Location = new System.Drawing.Point(0, 0);
          this.richTB.Name = "richTB";
          this.richTB.Size = new System.Drawing.Size(277, 318);
          this.richTB.TabIndex = 0;
          this.richTB.Text = "";
          // 
          // panel5
          // 
          this.panel5.Controls.Add(this.Img);
          this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
          this.panel5.Location = new System.Drawing.Point(149, 65);
          this.panel5.Name = "panel5";
          this.panel5.Size = new System.Drawing.Size(478, 318);
          this.panel5.TabIndex = 7;
          // 
          // Img
          // 
          this.Img.Dock = System.Windows.Forms.DockStyle.Fill;
          this.Img.Location = new System.Drawing.Point(0, 0);
          this.Img.Margin = new System.Windows.Forms.Padding(0);
          this.Img.Name = "Img";
          this.Img.Size = new System.Drawing.Size(478, 318);
          this.Img.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
          this.Img.TabIndex = 3;
          this.Img.TabStop = false;
          // 
          // Form1
          // 
          this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
          this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
          this.ClientSize = new System.Drawing.Size(904, 466);
          this.Controls.Add(this.panel5);
          this.Controls.Add(this.panel4);
          this.Controls.Add(this.panel3);
          this.Controls.Add(this.panel2);
          this.Controls.Add(this.panel1);
          this.Name = "Form1";
          this.Text = "Form1";
          this.panel1.ResumeLayout(false);
          this.panel1.PerformLayout();
          this.panel3.ResumeLayout(false);
          this.panel4.ResumeLayout(false);
          this.panel5.ResumeLayout(false);
          ((System.ComponentModel.ISupportInitialize)(this.Img)).EndInit();
          this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckedListBox checkedLB;
        private System.Windows.Forms.Button BnLoad;
        private System.Windows.Forms.Button BnDecode;
        private System.Windows.Forms.OpenFileDialog OpenDialog;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.PictureBox Img;
        private System.Windows.Forms.RichTextBox richTB;
        private System.Windows.Forms.Label LabelFileName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TimeEdit;
        private System.Windows.Forms.Label TypeCodeL;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}

